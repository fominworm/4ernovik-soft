package com.example.haybot

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Что меню может попросить у службы. */
interface MenuHost {
    fun run()
    fun setup()
    fun close()
    fun advanced(page: Int)
    fun debug()
    fun openLink(url: String)
    fun share(text: String)
    fun clip(): String?
    fun toast(m: String)
}

/**
 * Большое меню поверх игры в неоновой рамке: главная, настройки, скорость, хранилище, магазин, конфиги, помощь.
 * Работает без полей ввода (окно не берёт фокус), всё нажимается кнопками.
 */
class MenuUi(ctx: Context, private val cfg: Cfg, private val host: MenuHost, private val pw: Int, private val ph: Int) : FrameLayout(ctx) {
    private val dens = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens).toInt()

    private val cText = 0xFFEAF0FF.toInt()
    private val cMuted = 0xFF9AA6C7.toInt()
    private val cCyan = 0xFF35D6FF.toInt()
    private val cViolet = 0xFF7B3DFF.toInt()
    private val cPink = 0xFFFF3DD6.toInt()
    private val cGreen = 0xFF2ECC71.toInt()
    private val cRed = 0xFFFF5C7A.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())
    private val stack = ArrayList<String>()
    private var screen = "home"
    private var speedTab = 0
    private var storTab = 0
    private val armedKeys = HashSet<String>()

    private val titleTv = TextView(ctx)
    private val subTv = TextView(ctx)
    private val backBtn = TextView(ctx)
    private val body = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)

    init {
        val frame = ImageView(ctx)
        frame.setImageResource(R.drawable.panel_frame)
        frame.scaleType = ImageView.ScaleType.FIT_XY
        addView(frame, LayoutParams(MATCH, MATCH))

        // кнопка «Назад» лежит на выступе рамки слева сверху
        backBtn.text = "‹ Назад"
        backBtn.textSize = 13f
        backBtn.setTextColor(cText)
        backBtn.typeface = Typeface.DEFAULT_BOLD
        backBtn.gravity = Gravity.CENTER
        press(backBtn)
        backBtn.setOnClickListener { back() }
        val bl = LayoutParams((pw * 0.15f).toInt(), (ph * 0.12f).toInt(), Gravity.TOP or Gravity.START)
        bl.setMargins((pw * 0.03f).toInt(), (ph * 0.045f).toInt(), 0, 0)
        addView(backBtn, bl)

        val tbox = LinearLayout(ctx)
        tbox.orientation = LinearLayout.VERTICAL
        titleTv.textSize = 18f
        titleTv.setTextColor(cText)
        titleTv.typeface = Typeface.DEFAULT_BOLD
        subTv.textSize = 11f
        subTv.setTextColor(cMuted)
        tbox.addView(titleTv)
        tbox.addView(subTv)
        val tl = LayoutParams((pw * 0.55f).toInt(), WRAP, Gravity.TOP or Gravity.START)
        tl.setMargins((pw * 0.2f).toInt(), (ph * 0.045f).toInt(), 0, 0)
        addView(tbox, tl)

        val logo = ImageView(ctx)
        logo.setImageResource(R.drawable.logo)
        val ll = LayoutParams((ph * 0.13f).toInt(), (ph * 0.13f).toInt(), Gravity.TOP or Gravity.END)
        ll.setMargins(0, (ph * 0.04f).toInt(), (pw * 0.13f).toInt(), 0)
        addView(logo, ll)

        val closeBtn = TextView(ctx)
        closeBtn.text = "✕"
        closeBtn.textSize = 18f
        closeBtn.setTextColor(cText)
        closeBtn.typeface = Typeface.DEFAULT_BOLD
        closeBtn.gravity = Gravity.CENTER
        closeBtn.background = glass(12)
        press(closeBtn)
        closeBtn.setOnClickListener { host.close() }
        val cl = LayoutParams((ph * 0.11f).toInt(), (ph * 0.11f).toInt(), Gravity.TOP or Gravity.END)
        cl.setMargins(0, (ph * 0.045f).toInt(), (pw * 0.06f).toInt(), 0)
        addView(closeBtn, cl)

        body.orientation = LinearLayout.VERTICAL
        scroll.addView(body)
        val sl = LayoutParams(MATCH, MATCH)
        sl.setMargins((pw * 0.06f).toInt(), (ph * 0.2f).toInt(), (pw * 0.06f).toInt(), (ph * 0.09f).toInt())
        addView(scroll, sl)
        render()
    }

    // ---------- навигация ----------

    private fun go(s: String) {
        stack.add(screen)
        screen = s
        render()
    }

    private fun back() {
        if (stack.isNotEmpty()) {
            screen = stack.removeAt(stack.size - 1)
            render()
        }
    }

    private fun render() {
        body.removeAllViews()
        armedKeys.clear()
        backBtn.visibility = if (screen == "home") View.INVISIBLE else View.VISIBLE
        backBtn.background = if (screen == "home") null else glass(12)
        scroll.scrollTo(0, 0)
        when (screen) {
            "settings" -> settings()
            "speed" -> speed()
            "storage" -> storage()
            "shop" -> shop()
            "configs" -> configs()
            "help" -> help()
            else -> home()
        }
    }

    private fun head(t: String, s: String) {
        titleTv.text = t
        subTv.text = s
    }

    // ---------- элементы ----------

    private fun withA(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    private fun glass(r: Int, active: Boolean = false): LayerDrawable {
        val a = if (active) 0xFF else 0x99
        val outer = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(withA(cCyan, a), withA(cViolet, a), withA(cPink, a)))
        outer.cornerRadius = dp(r).toFloat()
        val inner = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            if (active) intArrayOf(0xF0143A9A.toInt(), 0xF0230E6A.toInt()) else intArrayOf(0xF00B1040.toInt(), 0xF0140B3A.toInt())
        )
        inner.cornerRadius = dp(r - 2).toFloat()
        val ld = LayerDrawable(arrayOf(outer, inner))
        ld.setLayerInset(1, dp(2), dp(2), dp(2), dp(2))
        return ld
    }

    private fun press(v: View) {
        v.isClickable = true
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.alpha = 0.7f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.alpha = 1f
            }
            false
        }
    }

    private fun text(t: String, size: Float, color: Int = cText, bold: Boolean = false): TextView {
        val v = TextView(context)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(0, dp(1), 0, dp(1))
        return v
    }

    private fun centered(t: String, size: Float, color: Int = cText, bold: Boolean = false): TextView {
        val v = text(t, size, color, bold)
        v.gravity = Gravity.CENTER
        return v
    }

    private fun space(h: Int): View {
        val v = View(context)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, dp(h))
        return v
    }

    private fun panel(): LinearLayout {
        val c = LinearLayout(context)
        c.orientation = LinearLayout.VERTICAL
        c.background = glass(14)
        c.setPadding(dp(12), dp(10), dp(12), dp(10))
        return c
    }

    private fun tile(icon: String, title: String, sub: String = "", active: Boolean = false, onClick: () -> Unit): LinearLayout {
        val t = LinearLayout(context)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.background = glass(14, active)
        t.setPadding(dp(6), dp(12), dp(6), dp(12))
        t.addView(centered(icon, 28f), lp(MATCH, WRAP))
        t.addView(centered(title, 13f, cText, true), lp(MATCH, WRAP, 0f, 0, 3))
        if (sub.isNotEmpty()) t.addView(centered(sub, 10f, cMuted), lp(MATCH, WRAP))
        press(t)
        t.setOnClickListener { onClick() }
        t.layoutParams = lp(0, WRAP, 1f, 3, 3, 3, 3)
        return t
    }

    private fun tileRow(vararg tiles: View) {
        val r = LinearLayout(context)
        r.orientation = LinearLayout.HORIZONTAL
        for (t in tiles) r.addView(t)
        body.addView(r, lp(MATCH, WRAP, 0f, 0, 4, 0, 4))
    }

    private fun styledSwitch(on: Boolean, onChange: (Boolean) -> Unit): Switch {
        val sw = Switch(context)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(cCyan, 0xFF3A3F6B.toInt()))
        sw.thumbTintList = ColorStateList(states, intArrayOf(0xFFFFFFFF.toInt(), 0xFFCCD3F0.toInt()))
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        return sw
    }

    private fun toggleCard(icon: String, title: String, desc: String, on: Boolean, onChange: (Boolean) -> Unit) {
        val c = LinearLayout(context)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.background = glass(14)
        c.setPadding(dp(12), dp(10), dp(12), dp(10))
        c.addView(text(icon, 30f), lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(title, 14f, cText, true))
        col.addView(text(desc, 11f, cMuted))
        c.addView(col, lp(0, WRAP, 1f))
        val sw = styledSwitch(on, onChange)
        c.addView(sw, lp(WRAP, WRAP, 0f, 8, 0, 0, 0))
        press(c)
        c.setOnClickListener { sw.toggle() }
        body.addView(c, lp(MATCH, WRAP, 0f, 0, 4, 0, 4))
    }

    private fun sliderRow(value: Int, min: Int, max: Int, step: Int, show: (Int) -> String, onChange: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(12)
        row.setPadding(dp(10), dp(8), dp(8), dp(8))
        var cur = value.coerceIn(min, max)
        val sb = SeekBar(context)
        sb.max = (max - min) / step
        sb.progress = (cur - min) / step
        sb.progressTintList = ColorStateList.valueOf(cCyan)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0x773D6BFF)
        sb.thumbTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        val valueTv = centered(show(cur), 18f, cText, true)
        valueTv.minWidth = dp(84)
        fun setV(v: Int) {
            cur = v.coerceIn(min, max)
            valueTv.text = show(cur)
            sb.progress = (cur - min) / step
            onChange(cur)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    cur = min + p * step
                    valueTv.text = show(cur)
                    onChange(cur)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(sb, lp(0, dp(36), 1f))
        row.addView(valueTv, lp(WRAP, WRAP, 0f, 6, 0, 4, 0))
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.background = glass(10)
        val up = centered("▲", 13f, cText, true)
        up.setPadding(dp(12), dp(6), dp(12), dp(6))
        press(up)
        up.setOnClickListener { setV(cur + step) }
        val dn = centered("▼", 13f, cText, true)
        dn.setPadding(dp(12), dp(6), dp(12), dp(6))
        press(dn)
        dn.setOnClickListener { setV(cur - step) }
        col.addView(up)
        col.addView(dn)
        row.addView(col, lp(WRAP, WRAP))
        return row
    }

    private fun infoRow(msg: String): LinearLayout {
        val r = LinearLayout(context)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = glass(12)
        r.setPadding(dp(10), dp(8), dp(10), dp(8))
        r.addView(text("ⓘ", 18f, cCyan, true), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        r.addView(text(msg, 11f, cText), lp(0, WRAP, 1f))
        return r
    }

    /** Строка «подпись, − значение +»: для чисел без поля ввода. */
    private fun stepRow(label: String, get: () -> Int, set: (Int) -> Unit, steps: IntArray) {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(12)
        row.setPadding(dp(10), dp(6), dp(8), dp(6))
        row.addView(text(label, 12f, cText), lp(0, WRAP, 1f))
        val valueTv = centered(get().toString(), 16f, cText, true)
        valueTv.minWidth = dp(64)
        fun btn(d: Int): TextView {
            val b = centered((if (d > 0) "+" else "−") + Math.abs(d), 12f, cText, true)
            b.background = glass(10)
            b.setPadding(dp(8), dp(7), dp(8), dp(7))
            press(b)
            b.setOnClickListener {
                set(get() + d)
                valueTv.text = get().toString()
            }
            return b
        }
        for (s in steps.sortedDescending()) row.addView(btn(-s), lp(WRAP, WRAP, 0f, 2, 0, 2, 0))
        row.addView(valueTv)
        for (s in steps.sorted()) row.addView(btn(s), lp(WRAP, WRAP, 0f, 2, 0, 2, 0))
        body.addView(row, lp(MATCH, WRAP, 0f, 0, 3, 0, 3))
    }

    /** Опасная кнопка в два нажатия: первое только просит подтвердить. */
    private fun twoStep(key: String, label: String, onYes: () -> Unit): TextView {
        val b = centered(label, 12f, cText, true)
        b.background = glass(12)
        b.setPadding(dp(10), dp(9), dp(10), dp(9))
        press(b)
        b.setOnClickListener {
            if (armedKeys.contains(key)) {
                armedKeys.remove(key)
                onYes()
            } else {
                armedKeys.add(key)
                b.text = "Точно? Нажми ещё раз"
                b.setTextColor(cRed)
                handler.postDelayed({
                    if (armedKeys.remove(key)) {
                        b.text = label
                        b.setTextColor(cText)
                    }
                }, 3000)
            }
        }
        return b
    }

    // ---------- главная ----------

    private fun home() {
        head("TapTapBot's", "Hay Day · выбери действие")
        body.addView(space(8))
        tileRow(
            tile("▶", "Запустить", "бот начнёт работу", true) { host.run() },
            tile("🔄", "Настроить заново", "мастер настройки") { host.setup() },
            tile("⚙", "Настройки", "скорость, склад, лавка") { go("settings") },
            tile("📁", "Конфиги", "сохранить и загрузить") { go("configs") },
            tile("❓", "Помощь", "поддержка") { go("help") }
        )
        val st = LinearLayout(context)
        st.orientation = LinearLayout.HORIZONTAL
        st.background = glass(12)
        st.setPadding(dp(10), dp(8), dp(10), dp(8))
        val ready = cfg.missingPair() == null
        st.addView(text(if (ready) "● Настройка завершена" else "⚠ Настройка не завершена: нажми «Настроить заново»", 11f, if (ready) cGreen else cRed, true), lp(0, WRAP, 1f))
        st.addView(text("🔑 " + License.shortStatus(context), 11f, cMuted))
        body.addView(st, lp(MATCH, WRAP, 0f, 0, 8, 0, 0))
    }

    private fun settings() {
        head("⚙ Настройки", "Выбери раздел")
        body.addView(space(4))
        tileRow(
            tile("⚡", "Скорость", "посев, сбор, лавка") { go("speed") },
            tile("📦", "Хранилище", "силос и подсчёт") { go("storage") },
            tile("🏪", "Магазин", "продажа и реклама") { go("shop") }
        )
        tileRow(
            tile("🧩", "Свои задачи", "макросы по таймеру") { host.advanced(2) },
            tile("🛠", "Расширенные", "поля, режимы, 📷 🎯") { host.advanced(1) },
            tile("🧪", "Тесты и эталон", "🌱 🔪 📸 👻") { host.advanced(0) }
        )
    }

    // ---------- скорость ----------

    private class SpeedItem(
        val icon: String, val title: String, val sub: String, val tip: String, val rec: String,
        val min: Int, val max: Int, val step: Int,
        val get: () -> Int, val set: (Int) -> Unit, val show: (Int) -> String
    )

    private fun speed() {
        head("⚡ Скорость", "Регулируйте скорость действий бота")
        val pct = { v: Int -> "$v %" }
        val ms = { v: Int -> "$v мс" }
        val items = listOf(
            SpeedItem("🌱", "Посадка культуры", "Скорость посадки на поле", "Чем больше значение, тем быстрее палец ведёт по полю.",
                "500 %", 50, 600, 10, { cfg.speedPlant }, { cfg.speedPlant = it }, pct),
            SpeedItem("🌾", "Сбор культуры", "Скорость сбора серпом", "Чем больше значение, тем быстрее палец ведёт по полю.",
                "500 %", 50, 600, 10, { cfg.speedHarvest }, { cfg.speedHarvest = it }, pct),
            SpeedItem("⏱", "Задержка между посадками и сбором", "Пауза после каждой посадки и сбора", "Если камера сдвигается или игра не успевает, увеличь паузу. 0 — без добавочной паузы.",
                "0 мс", 0, 10000, 100, { cfg.delayAct }, { cfg.delayAct = it }, ms),
            SpeedItem("🏪", "Выставление предметов", "Скорость работы в лавке", "Чем больше значение, тем быстрее бот нажимает в лавке. Если окна не успевают открываться, уменьши.",
                "200 %", 50, 400, 10, { cfg.speedShop }, { cfg.speedShop = it }, pct),
            SpeedItem("🛒", "Задержка между выставлением в магазин", "Пауза после каждого слота", "Увеличь, если игра пропускает нажатия. 0 — без добавочной паузы.",
                "0 мс", 0, 10000, 100, { cfg.delayShop }, { cfg.delayShop = it }, ms),
            SpeedItem("🟫", "Прижим земли", "Сколько держать палец на пустой земле в конце", "В конце посева и сбора палец уходит на точку «пустая земля», держится там и отпускается. Так камера не уезжает. Меньше 0,6 с — выключено.",
                "1000 мс", 500, 4000, 100, { cfg.groundMs.let { if (it <= 0) 500 else it } }, { cfg.groundMs = it },
                { v -> if (v < 600) "выкл" else "$v мс" }),
            SpeedItem("✋", "Удержание иконки", "Сколько держать иконку перед посевом", "Игре нужно время, чтобы «взять» иконку. Если посев не начинается, увеличь.",
                "600 мс", 100, 2000, 50, { cfg.holdMs }, { cfg.holdMs = it }, ms)
        )
        if (speedTab >= items.size) speedTab = 0
        val wrap = LinearLayout(context)
        wrap.orientation = LinearLayout.HORIZONTAL
        val side = LinearLayout(context)
        side.orientation = LinearLayout.VERTICAL
        for ((i, si) in items.withIndex()) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = glass(10, i == speedTab)
            row.setPadding(dp(8), dp(7), dp(8), dp(7))
            row.addView(text(si.icon, 16f), lp(WRAP, WRAP, 0f, 0, 0, 6, 0))
            row.addView(text(si.title, 11f, cText, i == speedTab), lp(0, WRAP, 1f))
            press(row)
            row.setOnClickListener {
                speedTab = i
                render()
            }
            side.addView(row, lp(MATCH, WRAP, 0f, 0, 2, 0, 2))
        }
        wrap.addView(side, lp((pw * 0.27f).toInt(), WRAP, 0f, 0, 0, 8, 0))
        val cur = items[speedTab]
        val main = panel()
        val h = LinearLayout(context)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.addView(text(cur.icon, 32f), lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(cur.title, 15f, cText, true))
        col.addView(text(cur.sub, 11f, cMuted))
        h.addView(col, lp(0, WRAP, 1f))
        val rec = text("⚡ Рекомендуемое: " + cur.rec, 10f, cText)
        rec.background = glass(10)
        rec.setPadding(dp(8), dp(4), dp(8), dp(4))
        h.addView(rec)
        main.addView(h)
        main.addView(space(8))
        main.addView(sliderRow(cur.get(), cur.min, cur.max, cur.step, cur.show) { v -> cur.set(v) })
        main.addView(space(8))
        main.addView(infoRow(cur.tip))
        wrap.addView(main, lp(0, WRAP, 1f))
        body.addView(wrap)
    }

    // ---------- хранилище ----------

    private fun storage() {
        head("📦 Хранилище", "Настройте параметры хранилища")
        val tabs = LinearLayout(context)
        tabs.orientation = LinearLayout.HORIZONTAL
        for ((i, n) in listOf("🌾  Информация о хранилище", "📦  Лимит хранилища").withIndex()) {
            val t = centered(n, 13f, cText, i == storTab)
            t.background = glass(12, i == storTab)
            t.setPadding(dp(6), dp(10), dp(6), dp(10))
            press(t)
            t.setOnClickListener {
                storTab = i
                render()
            }
            tabs.addView(t, lp(0, WRAP, 1f, 2, 0, 2, 0))
        }
        body.addView(tabs, lp(MATCH, WRAP, 0f, 0, 0, 0, 6))
        if (storTab == 0) {
            val used = cfg.barnUsed
            val cap = cfg.barnCap
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            for ((label, v) in listOf("Сейчас в хранилище:" to used, "Лимит хранилища:" to cap)) {
                val box = LinearLayout(context)
                box.orientation = LinearLayout.VERTICAL
                box.background = glass(12)
                box.setPadding(dp(12), dp(8), dp(12), dp(8))
                box.addView(text(label, 11f, cMuted))
                box.addView(text("$v шт.", 24f, cText, true))
                row.addView(box, lp(0, WRAP, 1f, 2, 0, 2, 0))
            }
            body.addView(row)
            val pc = if (cap > 0) (used * 100 / cap).coerceIn(0, 100) else 0
            val pr = LinearLayout(context)
            pr.orientation = LinearLayout.HORIZONTAL
            pr.gravity = Gravity.CENTER_VERTICAL
            val bar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = 100
            bar.progress = pc
            bar.progressTintList = ColorStateList.valueOf(cCyan)
            bar.progressBackgroundTintList = ColorStateList.valueOf(0x773D6BFF)
            pr.addView(bar, lp(0, dp(12), 1f))
            pr.addView(text("$pc%", 18f, cCyan, true), lp(WRAP, WRAP, 0f, 10, 0, 0, 0))
            body.addView(pr, lp(MATCH, WRAP, 0f, 0, 8, 0, 8))
            toggleCard("⚙", "Автоматический подсчёт", "Бот сам считает пшеницу в хранилище: плюс при сборе, минус на посев и при продаже", cfg.autoCount) { cfg.autoCount = it }
        } else {
            body.addView(infoRow("Вместимость 0 = расчёт выключен. «Занято» поправь, если бот сбился."))
            stepRow("Занято сейчас", { cfg.barnUsed }, { cfg.barnUsed = it }, intArrayOf(10, 100))
            stepRow("Вместимость хранилища", { cfg.barnCap }, { cfg.barnCap = it }, intArrayOf(25, 100))
            stepRow("Клеток на первом поле", { cfg.cellsOf(0) }, { cfg.setCells(0, it.coerceAtLeast(0)) }, intArrayOf(1, 5))
            stepRow("Урожай с одной клетки", { cfg.perCell }, { cfg.perCell = it }, intArrayOf(1))
            stepRow("Пшеницы в одном слоте", { cfg.perSlot }, { cfg.perSlot = it }, intArrayOf(1, 5))
        }
    }

    // ---------- магазин ----------

    private fun shop() {
        head("🏪 Магазин", "Настройте параметры магазина")
        toggleCard("🏪", "Автоматическое выставление на продажу при заполнении хранилища",
            "Когда места на следующий сбор не хватает, бот выставит пшеницу на продажу.", cfg.sellOnFull) {
            cfg.sellOnFull = it
            render()
        }
        toggleCard("📢", "Автоматическое выставление товара в рекламу",
            "Реклама на последнем слоте, не чаще раза в 5 минут.", cfg.adOn) { cfg.adOn = it }
        if (!cfg.sellOnFull) {
            val p = panel()
            p.addView(text("Продажа по заполнению выключена: бот продаёт раз в N посадок.", 11f, cMuted))
            p.addView(text("Продавать каждые N посадок", 13f, cText, true))
            p.addView(sliderRow(cfg.sellEvery, 1, 9, 1, { "$it" }) { cfg.sellEvery = it })
            body.addView(p, lp(MATCH, WRAP, 0f, 0, 4, 0, 4))
        }
        if (cfg.first(T.SHOP, 0) == null) {
            body.addView(infoRow("Лавка ещё не настроена в мастере (шаг «Лавка»): без этого продажа не работает."), lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        }
    }

    // ---------- конфиги ----------

    private fun fmtTime(t: Long): String =
        if (t <= 0L) "—" else SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(t))

    private fun configs() {
        head("📁 Конфиг настроек", "Управляйте своими конфигурациями")
        val top = LinearLayout(context)
        top.orientation = LinearLayout.HORIZONTAL
        top.addView(tile("💾", "Сохранить конфиг", "текущие настройки", true) {
            val name = "Конфиг " + SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date())
            cfg.saveProfile(name)
            host.toast("Сохранено: $name")
            render()
        })
        top.addView(tile("📥", "Загрузить из буфера", "скопированный текст конфига") {
            val t = host.clip()
            if (t.isNullOrBlank()) host.toast("Буфер пуст или недоступен")
            else if (cfg.importJson(t)) host.toast("Загружено. Сохрани конфиг, если нужно")
            else host.toast("Не получилось: текст повреждён")
        })
        body.addView(top)

        val names = cfg.profileNames()
        val list = panel()
        val hr = LinearLayout(context)
        hr.orientation = LinearLayout.HORIZONTAL
        hr.addView(text("☰  Ваши конфигурации", 14f, cText, true), lp(0, WRAP, 1f))
        hr.addView(text("Всего: " + names.size, 12f, cCyan, true))
        list.addView(hr)
        if (names.isEmpty()) list.addView(text("Конфигов пока нет. Нажми «Сохранить конфиг».", 11f, cMuted))
        for (name in names) {
            val act = name == cfg.activeProfile
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = glass(12, act)
            row.setPadding(dp(8), dp(6), dp(8), dp(6))
            row.addView(text(if (act) "⭐" else "📄", 20f), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
            val col = LinearLayout(context)
            col.orientation = LinearLayout.VERTICAL
            col.addView(text(name, 13f, cText, true))
            col.addView(text("Последнее изменение: " + fmtTime(cfg.profileTime(name)), 10f, cMuted))
            row.addView(col, lp(0, WRAP, 1f))
            val chip = centered(if (act) "Активный" else "Сделать активным", 10f, cText, true)
            chip.background = glass(10, act)
            chip.setPadding(dp(8), dp(6), dp(8), dp(6))
            press(chip)
            chip.setOnClickListener {
                host.toast(if (cfg.loadProfile(name)) "Активен: $name" else "Не удалось загрузить")
                render()
            }
            row.addView(chip, lp(WRAP, WRAP, 0f, 2, 0, 2, 0))
            fun icon(t: String, f: () -> Unit) {
                val v = centered(t, 14f)
                v.background = glass(10)
                v.setPadding(dp(8), dp(6), dp(8), dp(6))
                press(v)
                v.setOnClickListener { f() }
                row.addView(v, lp(WRAP, WRAP, 0f, 2, 0, 2, 0))
            }
            icon("📤") {
                val json = cfg.profileJson(name)
                if (json != null) host.share(json)
            }
            val del = twoStep("del_$name", "🗑") {
                cfg.deleteProfile(name)
                render()
            }
            row.addView(del, lp(WRAP, WRAP, 0f, 2, 0, 0, 0))
            list.addView(row, lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        }
        body.addView(list, lp(MATCH, WRAP, 0f, 0, 6, 0, 6))

        val bottom = LinearLayout(context)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.addView(twoStep("reset", "↺ Сбросить настройки") {
            cfg.resetDefaults()
            host.toast("Настройки сброшены (поля и точки остались)")
            render()
        }, lp(0, WRAP, 1f, 2, 0, 2, 0))
        bottom.addView(twoStep("delall", "🗑 Удалить все конфиги") {
            cfg.deleteAllProfiles()
            render()
        }, lp(0, WRAP, 1f, 2, 0, 2, 0))
        body.addView(bottom)
    }

    // ---------- помощь ----------

    private fun help() {
        head("❓ Помощь", "Нужна помощь? Мы рядом!")
        val p = panel()
        p.gravity = Gravity.CENTER_HORIZONTAL
        p.addView(centered("🤖", 40f))
        p.addView(centered("Для технической поддержки переходите в Telegram:", 14f, cText, true))
        val tg = centered("✈  @flomaster6", 20f, cText, true)
        tg.background = glass(18, true)
        tg.setPadding(dp(16), dp(10), dp(16), dp(10))
        press(tg)
        tg.setOnClickListener { host.openLink(LicenseConfig.SUPPORT_URL) }
        p.addView(tg, lp(WRAP, WRAP, 0f, 0, 8, 0, 8))
        body.addView(p, lp(MATCH, WRAP, 0f, 0, 0, 0, 4))
        tileRow(
            tile("🐞", "Скопировать debug", "вставь его в чат") { host.debug() },
            tile("📢", "Канал", "новости и обновления") { host.openLink(LicenseConfig.CHANNEL_URL) }
        )
    }
}
