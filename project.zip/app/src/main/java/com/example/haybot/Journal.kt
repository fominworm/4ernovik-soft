package com.example.haybot

import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Журнал событий бота: короткие строки со временем, хранится в файле на телефоне. */
object Journal {
    private val lock = Any()

    private fun file(ctx: Context) = File(ctx.filesDir, "log.txt")

    fun log(ctx: Context, msg: String) {
        synchronized(lock) {
            try {
                val f = file(ctx)
                val t = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(Date())
                f.appendText("$t  $msg\n")
                if (f.length() > 120_000) {
                    val s = f.readText()
                    f.writeText(s.takeLast(60_000))
                }
            } catch (_: Exception) {
            }
        }
    }

    fun read(ctx: Context): String = synchronized(lock) {
        try {
            file(ctx).readText()
        } catch (_: Exception) {
            ""
        }
    }

    fun clear(ctx: Context) {
        synchronized(lock) {
            try {
                file(ctx).writeText("")
            } catch (_: Exception) {
            }
        }
    }
}

/** Счётчики за всё время: посадки, сборы, продажи, сбои, запуски, время работы. */
class Stats(ctx: Context) {
    private val sp = ctx.getSharedPreferences("stats", Context.MODE_PRIVATE)

    fun get(k: String): Long = sp.getLong(k, 0L)

    @Synchronized
    fun add(k: String, v: Long = 1L) {
        sp.edit().putLong(k, get(k) + v).apply()
    }

    fun reset() {
        sp.edit().clear().apply()
    }
}

/** Сводка для отладки: устройство, настройки и журнал последних трёх кругов. */
object Debug {
    fun build(ctx: Context, cfg: Cfg, screen: String): String {
        val sb = StringBuilder()
        sb.append("TapTapBot debug\n")
        sb.append("Android ").append(Build.VERSION.SDK_INT).append(", ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n")
        sb.append("Лицензия: ").append(License.shortStatus(ctx)).append("\n")
        sb.append("Экран: ").append(screen).append("\n\n=== НАСТРОЙКИ ===\n").append(cfg.dump())
        sb.append("\n=== ЖУРНАЛ (последние 3 круга) ===\n").append(lastRounds(Journal.read(ctx)))
        return sb.toString()
    }

    fun lastRounds(log: String): String {
        val lines = log.lines().filter { it.isNotBlank() }
        val idx = lines.indices.filter { lines[it].contains("🌾 Посадка") }
        val from = if (idx.size >= 3) idx[idx.size - 3] else maxOf(0, lines.size - 150)
        return lines.subList(from, lines.size).takeLast(220).joinToString("\n")
    }
}
