package com.example.haybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.text.TextUtils
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.random.Random

class BotService : AccessibilityService() {
    private enum class Mode { MENU, SETUP, RUN }

    private class Act(val t: String, val c: Int, val f: () -> Unit)

    private val gamePkg = "com.supercell.hayday"

    private val ui = Handler(Looper.getMainLooper())
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val shotExec: Executor = Executors.newSingleThreadExecutor()
    private lateinit var cfg: Cfg

    private var mode = Mode.MENU
    private var step = 0
    private var expanded = true
    private var note = ""
    private var inGame = false              // сейчас на экране Hay Day
    @Volatile private var busy = false      // идёт повтор нажатия, снятие эталона или задача бота
    @Volatile private var active = false    // работает фоновый поток
    private var plantedAt = 0L
    @Volatile private var lastAd = 0L
    @Volatile private var stopReason: String? = null
    private var fails = 0
    private var worker: Thread? = null

    private val botMode: Boolean get() = mode == Mode.RUN
    private val growMs: Long get() = cfg.growSec * 1000L

    private var root: LinearLayout? = null
    private var body: LinearLayout? = null
    private var cap: MarkView? = null
    private lateinit var capLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var titleTv: TextView
    private lateinit var promptTv: TextView
    private lateinit var subTv: TextView
    private lateinit var primaryBtn: TextView
    private lateinit var foldBtn: TextView
    private lateinit var stopBtn: TextView
    private lateinit var menuBtn: TextView
    private lateinit var rowA: LinearLayout
    private lateinit var rowB: LinearLayout
    private lateinit var rowC: LinearLayout

    private val adCooldownMs = 305_000L    // реклама не чаще раза в 5 минут

    private val cGray = 0xFF4A4F57.toInt()
    private val cGreen = 0xFF2E9E4F.toInt()
    private val cRed = 0xFFD64545.toInt()
    private val cBlue = 0xFF2F6FDE.toInt()

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val panelFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    private val ticker = object : Runnable {
        override fun run() {
            if (mode != Mode.SETUP || FLOW[step].kind != Kind.WAIT) return
            val left = ((plantedAt + growMs - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
            note = if (left > 0) {
                "⏳ Осталось примерно " + fmt(left.toInt()) + "\nКак только созреет, жми кнопку: я замерю время."
            } else {
                "✅ Должна быть готова. Жми, когда увидишь, что созрела."
            }
            subTv.text = note
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- жизненный цикл ----------

    override fun onServiceConnected() {
        cfg = Cfg(this)
        cfg.onExternalChange = { enterMenu("Настройки обновлены") }
        val mv = MarkView(this, cfg)
        mv.onTap = { x, y -> onTapped(x, y) }
        capLp = overlayParams()
        wm.addView(mv, capLp)
        cap = mv
        showPanel()   // панель добавляется после слоя, значит лежит выше него
        mode = Mode.MENU
        inGame = false
        updateUi()
        applyGameState()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val cls = event.className?.toString() ?: ""
        if (cls.contains("InputMethod") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        val g = pkg == gamePkg
        if (g != inGame) {
            inGame = g
            applyGameState()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        active = false
        worker?.interrupt()
        ui.removeCallbacks(ticker)
        removeView(cap)
        removeView(root)
        super.onDestroy()
    }

    /** Панель и перехват касаний живут только внутри Hay Day. При входе в игру всегда меню: ничего само не запускается. */
    private fun applyGameState() {
        val v = if (inGame) View.VISIBLE else View.GONE
        root?.visibility = v
        cap?.visibility = v
        if (!inGame) {
            if (botMode) {
                stopBot("Игра свёрнута")
            } else {
                mode = Mode.MENU
                note = ""
            }
            setArmed(false)
        } else {
            updateUi()
        }
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun overlayParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    /** armed = слой ловит касание пользователя; иначе касания проходят в игру. */
    private fun setArmed(on: Boolean) {
        val mv = cap ?: return
        val want = on && inGame
        if (mv.armed == want) return
        mv.armed = want
        capLp.flags = if (want) baseFlags else (baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        try { wm.updateViewLayout(mv, capLp) } catch (_: Exception) {}
        mv.invalidate()
    }

    private fun keepAwake(on: Boolean) {
        val r = root ?: return
        panelLp.flags = if (on) (panelFlags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else panelFlags
        try { wm.updateViewLayout(r, panelLp) } catch (_: Exception) {}
    }

    private fun toast(m: String) {
        ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    private fun fmt(sec: Int): String = (sec / 60).toString() + ":" + (sec % 60).toString().padStart(2, '0')

    private fun arrow(d: Int): String = when (d) {
        0 -> "↖"
        1 -> "↗"
        2 -> "↙"
        else -> "↘"
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun vis(show: Boolean): Int = if (show) View.VISIBLE else View.GONE

    private fun btn(t: String, color: Int, weight: Float = 0f, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.WHITE)
        v.textSize = 13f
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(8), dp(8), dp(8), dp(8))
        v.background = bg(color, 10)
        v.setOnClickListener { onClick() }
        val w = if (weight > 0f) 0 else ViewGroup.LayoutParams.WRAP_CONTENT
        val lp = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        v.layoutParams = lp
        return v
    }

    private fun big(t: String, color: Int, onClick: () -> Unit): TextView {
        val v = btn(t, color, 0f, onClick)
        v.textSize = 16f
        v.setPadding(dp(10), dp(12), dp(10), dp(12))
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(dp(2), dp(6), dp(2), dp(4))
        v.layoutParams = lp
        return v
    }

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(4), dp(3), dp(4), dp(3))
        return v
    }

    private fun newRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun fillRow(row: LinearLayout, items: List<Act>) {
        row.removeAllViews()
        for (a in items) row.addView(btn(a.t, a.c, 1f, a.f))
        row.visibility = vis(items.isNotEmpty())
    }

    private fun showPanel() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = bg(0xEE101820.toInt(), 14)
        box.setPadding(dp(6), dp(6), dp(6), dp(6))

        // шапка: перетащить, заголовок, в меню, стоп, показать точки, свернуть
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val drag = btn("≡", cGray) {}
        titleTv = label(12f, 0xFFB0BEC5.toInt())
        titleTv.maxWidth = dp(150)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        menuBtn = btn("🏠", cGray) { if (!busy) enterMenu() }
        stopBtn = btn("■", cRed) { stopBot("Остановлено кнопкой") }
        val eye = btn("👁", cGray) { toggleMarks() }
        foldBtn = btn("⌄", cGray) { expanded = !expanded; applyFold() }
        head.addView(drag)
        head.addView(titleTv)
        head.addView(menuBtn)
        head.addView(stopBtn)
        head.addView(eye)
        head.addView(foldBtn)

        // тело: текущее задание, одна главная кнопка, мелкие кнопки
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        promptTv = label(16f, Color.WHITE, true)
        subTv = label(12.5f, 0xFFCFD8DC.toInt())
        primaryBtn = big("", cGreen) { onPrimary() }
        rowA = newRow()
        rowB = newRow()
        rowC = newRow()
        b.addView(promptTv)
        b.addView(subTv)
        b.addView(primaryBtn)
        b.addView(rowA)
        b.addView(rowB)
        b.addView(rowC)

        box.addView(head)
        box.addView(b, LinearLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            panelFlags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(8)
        panelLp = lp

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }

        wm.addView(box, lp)
        root = box
        body = b
        applyFold()
    }

    private fun applyFold() {
        body?.visibility = if (expanded) View.VISIBLE else View.GONE
        foldBtn.text = if (expanded) "⌄" else "⌃"
    }

    private fun toggleMarks() {
        val mv = cap ?: return
        mv.showAll = !mv.showAll
        mv.invalidate()
    }

    private fun updateUi() {
        ui.removeCallbacks(ticker)
        stopBtn.visibility = vis(mode == Mode.RUN)
        menuBtn.visibility = vis(mode == Mode.SETUP && !busy)

        if (mode == Mode.RUN) {
            titleTv.text = "🤖 Бот работает"
            promptTv.text = "Бот работает. Не трогай экран."
            subTv.text = note
            showPrimary("■ Стоп", cRed, true)
            fillRow(rowA, emptyList())
            fillRow(rowB, emptyList())
            fillRow(rowC, emptyList())
            setArmed(false)
            return
        }
        if (busy) {
            titleTv.text = "HayBot"
            promptTv.text = "⏳ Выполняю…"
            subTv.text = note
            primaryBtn.visibility = View.GONE
            fillRow(rowA, emptyList())
            fillRow(rowB, emptyList())
            fillRow(rowC, emptyList())
            setArmed(false)
            return
        }
        if (mode == Mode.MENU) drawMenu() else drawStep()
        cap?.invalidate()
    }

    private fun showPrimary(t: String, color: Int, enabled: Boolean) {
        primaryBtn.visibility = View.VISIBLE
        primaryBtn.text = t
        primaryBtn.background = bg(color, 10)
        primaryBtn.alpha = if (enabled) 1f else 0.45f
    }

    private fun drawMenu() {
        val ready = cfg.missing() == null
        titleTv.text = "HayBot · меню"
        promptTv.text = if (ready) "Готов к работе" else "Настройка не завершена"
        val sale = if (cfg.first(T.SHOP) != null) "каждые " + cfg.sellEvery + " круга" else "выключена"
        val rec = when {
            Build.VERSION.SDK_INT < 30 -> "недоступно (нужен Android 11+)"
            !cfg.useRec -> "выкл"
            else -> "вкл, эталонов " + listOf(T.HFIELD, T.CLOSE, T.PUT).count { cfg.getRef(it) != null }
        }
        subTv.text = (if (note.isNotEmpty()) note + "\n\n" else "") +
            "⏱ Созревание: " + fmt(cfg.growSec) + "\n" +
            "🏪 Продажа: " + sale + "\n" +
            "🎥 Камера: угол " + arrow(cfg.camDir) + ", автовозврат " + (if (cfg.camAuto) "вкл" else "выкл") + "\n" +
            "🎯 Распознавание: " + rec + "\n" +
            "⚓ Якорей: " + cfg.list(T.ANCHOR).size

        showPrimary(if (ready) "▶ Запустить" else "⚙ Настроить", if (ready) cGreen else cBlue, true)

        val a = ArrayList<Act>()
        if (ready) a.add(Act("⚙ Заново", cGray) { startSetup() })
        a.add(Act("🎥 Вернуть камеру", cGray) { cameraNow() })
        fillRow(rowA, a)

        val b = ArrayList<Act>()
        b.add(Act("⏱ −", cGray) { cfg.growSec = cfg.growSec - 5; updateUi() })
        b.add(Act("⏱ +", cGray) { cfg.growSec = cfg.growSec + 5; updateUi() })
        if (cfg.first(T.SHOP) != null) {
            b.add(Act("🏪 −", cGray) { cfg.sellEvery = cfg.sellEvery - 1; updateUi() })
            b.add(Act("🏪 +", cGray) { cfg.sellEvery = cfg.sellEvery + 1; updateUi() })
        }
        fillRow(rowB, b)

        val c = ArrayList<Act>()
        c.add(Act("🎥 " + arrow(cfg.camDir), cGray) { cfg.camDir = cfg.camDir + 1; updateUi() })
        c.add(Act("🎥 авто", if (cfg.camAuto) cGreen else cGray) { cfg.camAuto = !cfg.camAuto; updateUi() })
        if (Build.VERSION.SDK_INT >= 30) {
            c.add(Act("🎯", if (cfg.useRec) cGreen else cGray) { cfg.useRec = !cfg.useRec; updateUi() })
        }
        fillRow(rowC, c)
        setArmed(false)
    }

    private fun drawStep() {
        val s = FLOW[step]
        val r = s.role
        val n = if (r != null) cfg.list(r).size else 0
        val keep = if (s.fresh) 0 else 1

        titleTv.text = "HayBot · шаг ${step + 1} из ${FLOW.size}"
        promptTv.text = s.text
        val base = if (note.isNotEmpty()) note else s.hint
        subTv.text = when {
            r == T.AREA ->
                "Точек: $n из 4\n$base\nШаг строк: " + cfg.rowGap + " px (➖ чаще · ➕ реже)"
            s.kind == Kind.MULTI && s.max > 0 -> "Точек: $n из " + s.max + "\n$base"
            s.kind == Kind.MULTI -> "Точек: $n\n$base"
            else -> base
        }

        if (s.btn != null) {
            showPrimary(s.btn, if (s.kind == Kind.DO) cBlue else cGreen, !(s.kind == Kind.MULTI && n < s.min))
        } else {
            primaryBtn.visibility = View.GONE
        }

        val canErase = s.kind == Kind.MULTI && n > keep
        val a = ArrayList<Act>()
        if (canErase || step > 0) a.add(Act("↩ Назад", cGray) { back() })
        if (canErase) a.add(Act("🗑 Всё", cGray) { clearAll() })
        if (s.skip != null) a.add(Act(s.skip, cGray) { onSkip() })
        fillRow(rowA, a)

        val b = ArrayList<Act>()
        if (r == T.AREA) {
            b.add(Act("➖ чаще", cGray) { adjustGap(-5) })
            b.add(Act("➕ реже", cGray) { adjustGap(5) })
        }
        fillRow(rowB, b)
        fillRow(rowC, emptyList())

        setArmed(s.kind == Kind.TAP || s.kind == Kind.MULTI)
        if (s.kind == Kind.WAIT) ui.post(ticker)
    }

    private fun say(m: String) {
        ui.post {
            note = m
            if (botMode) titleTv.text = "🤖 $m"
            subTv.text = m
        }
    }

    // ---------- переходы ----------

    private fun enterMenu(msg: String = "") {
        mode = Mode.MENU
        note = msg
        updateUi()
    }

    private fun startSetup() {
        go(nextIndex(0))
    }

    private fun skipped(i: Int): Boolean =
        FLOW[i].role == T.ANCHOR && (Build.VERSION.SDK_INT < 30 || !cfg.useRec)

    private fun nextIndex(from: Int): Int {
        var k = from
        while (k < FLOW.size && skipped(k)) k++
        return k
    }

    private fun prevIndex(): Int {
        var k = step - 1
        while (k > 0 && skipped(k)) k--
        return k
    }

    private fun go(n: Int) {
        mode = Mode.SETUP
        step = n.coerceIn(0, FLOW.size - 1)
        note = ""
        val s = FLOW[step]
        val r = s.role
        if (r != null && s.fresh) cfg.clear(r)
        updateUi()
    }

    private fun advance() {
        val n = nextIndex(step + 1)
        if (n >= FLOW.size) {
            enterMenu("✅ Настройка завершена. Жми «▶ Запустить».")
        } else {
            go(n)
        }
    }

    private fun back() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role
        if (s.kind == Kind.MULTI && r != null) {
            val keep = if (s.fresh) 0 else 1
            if (cfg.list(r).size > keep) {
                cfg.removeLast(r)
                note = "↩ Последняя точка стёрта"
                updateUi()
                return
            }
        }
        if (step > 0) go(prevIndex()) else enterMenu()
    }

    private fun clearAll() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role ?: return
        if (s.kind == Kind.MULTI) {
            cfg.truncate(r, if (s.fresh) 0 else 1)
            note = "🗑 Точки стёрты"
            updateUi()
        }
    }

    private fun adjustGap(d: Int) {
        if (busy || botMode) return
        cfg.rowGap = cfg.rowGap + d
        updateUi()
    }

    private fun onPrimary() {
        if (mode == Mode.RUN) {
            stopBot("Остановлено кнопкой")
            return
        }
        if (busy) return
        if (mode == Mode.MENU) {
            if (cfg.missing() == null) startBot() else startSetup()
            return
        }
        val s = FLOW[step]
        when (s.kind) {
            Kind.MULTI -> {
                val r = s.role
                val n = if (r != null) cfg.list(r).size else 0
                if (n < s.min) {
                    note = "⚠ Нужно минимум " + s.min + " точки"
                    updateUi()
                } else {
                    advance()
                }
            }
            Kind.WAIT -> {
                if (plantedAt > 0) {
                    val sec = ((System.currentTimeMillis() - plantedAt) / 1000).toInt() + 3
                    cfg.growSec = sec
                    toast("⏱ Время созревания: " + fmt(cfg.growSec))
                }
                advance()
            }
            Kind.ASK -> advance()
            Kind.DO -> doAction(s.act ?: "")
            else -> {}
        }
    }

    private fun onSkip() {
        if (busy || botMode) return
        when (FLOW[step].kind) {
            Kind.ASK -> {
                cfg.clear(T.SHOP)
                enterMenu("✅ Настройка завершена (без продажи). Жми «▶ Запустить».")
            }
            else -> advance()
        }
    }

    // ---------- мастер: нажатия пользователя ----------

    private fun onTapped(x: Float, y: Float) {
        if (busy || mode != Mode.SETUP) return
        val s = FLOW[step]
        if (s.kind != Kind.TAP && s.kind != Kind.MULTI) return
        val p = P(x, y)
        val r = s.role
        if (r != null) {
            if (s.kind == Kind.MULTI && s.max > 0 && cfg.list(r).size >= s.max) {
                note = "Уже " + s.max + " точки. Жми «Готово» или ↩"
                updateUi()
                return
            }
            cfg.add(r, p)
            if (r == T.AD) lastAd = System.currentTimeMillis()
        }
        if (s.kind == Kind.MULTI) note = "✔ Запомнил"

        if (s.sample && r != null && cfg.useRec && Build.VERSION.SDK_INT >= 30) {
            // сначала убираем жёлтую подсветку, потом снимаем эталон цвета, потом повторяем нажатие
            busy = true
            setArmed(false)
            Thread {
                try { Thread.sleep(200) } catch (_: InterruptedException) {}
                val c = colorAt(p)
                ui.post {
                    if (c != null) {
                        if (r == T.ANCHOR) cfg.addAnchorColor(c) else cfg.setRef(r, c)
                        toast("🎯 Эталон цвета записан")
                    } else {
                        if (r == T.ANCHOR) cfg.removeLast(T.ANCHOR)
                        toast("⚠ Эталон не записался, попробуй ещё раз")
                    }
                    finishTap(s, p)
                }
            }.start()
            return
        }
        finishTap(s, p)
    }

    private fun finishTap(s: Stp, p: P) {
        if (s.replay) {
            busy = true
            setArmed(false)
            replayTap(p) {
                busy = false
                if (s.kind == Kind.TAP) advance() else updateUi()
            }
        } else {
            busy = false
            if (s.kind == Kind.TAP) advance() else updateUi()
        }
    }

    /** Повторяет нажатие пользователя в игре (слой уже стал прозрачным для касаний). */
    private fun replayTap(p: P, then: () -> Unit) {
        ui.postDelayed({
            val path = Path()
            path.moveTo(p.x, p.y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            val cb = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ui.postDelayed({ then() }, 800) }
                override fun onCancelled(d: GestureDescription?) { ui.postDelayed({ then() }, 300) }
            }
            if (!dispatchGesture(g, cb, null)) ui.postDelayed({ then() }, 300)
        }, 180)
    }

    // ---------- задачи бота вне основного цикла ----------

    private fun runTask(msg: String, work: () -> Unit, done: () -> Unit) {
        if (busy || botMode) return
        busy = true
        active = true
        note = msg
        setArmed(false)
        updateUi()
        worker = Thread {
            try {
                work()
            } catch (_: InterruptedException) {
            } finally {
                active = false
                ui.post { busy = false; done() }
            }
        }.also { it.start() }
    }

    private fun doAction(act: String) {
        when (act) {
            "plant" -> runTask(
                "Сажаю пшеницу по области…",
                { plantOnce(); plantedAt = System.currentTimeMillis() },
                { advance() }
            )
            "harvest" -> runTask("Собираю урожай по области…", { harvestOnce() }, { advance() })
            "camera" -> runTask("Двигаю камеру…", { normalizeCamera() }, { advance() })
        }
    }

    private fun cameraNow() {
        runTask("Двигаю камеру…", { normalizeCamera() }, { enterMenu("🎥 Камера возвращена") })
    }

    // ---------- основной цикл ----------

    private fun startBot() {
        val m = cfg.missing()
        if (m != null) {
            val i = FLOW.indexOfFirst { it.role == m }
            go(if (i >= 0) i else 0)
            note = "⚠ Не хватает: " + m.icon + " " + m.label
            updateUi()
            return
        }
        mode = Mode.RUN
        busy = false
        active = true
        stopReason = null
        note = "Запускаю…"
        expanded = false          // панель сворачивается, чтобы не закрывать игру
        applyFold()
        keepAwake(true)
        setArmed(false)
        updateUi()
        worker = Thread {
            try {
                loop()
            } catch (_: InterruptedException) {
            } finally {
                active = false
                val why = stopReason ?: "Бот остановлен"
                stopReason = null
                ui.post {
                    keepAwake(false)
                    expanded = true
                    applyFold()
                    enterMenu("⏹ $why")
                }
            }
        }.also { it.start() }
    }

    private fun stopBot(reason: String? = null) {
        if (reason != null) stopReason = reason
        active = false
        worker?.interrupt()
    }

    private fun plantOnce() {
        tap(cfg.first(T.FIELD)!!)
        pause(900)
        drag(cfg.first(T.WHEAT)!!, cfg.path())
        pause(900)
    }

    private fun harvestOnce() {
        tap(cfg.first(T.HFIELD)!!)
        pause(900)
        drag(cfg.first(T.SICKLE)!!, cfg.path())
        pause(1500)
    }

    /** Якоря на месте? Если проверить нельзя, не блокируем. */
    private fun anchorsOk(): Boolean {
        val pts = cfg.list(T.ANCHOR)
        val cols = cfg.anchorColors()
        if (!cfg.useRec || Build.VERSION.SDK_INT < 30 || pts.size < 2 || cols.size != pts.size) return true
        val now = shot(pts) ?: return true
        var bad = 0
        for (i in pts.indices) if (!near(now[i], cols[i], 60)) bad++
        return bad <= (if (pts.size >= 3) 1 else 0)
    }

    /** Проверка вида перед кругом; при сдвиге пробует вернуть камеру. */
    private fun ensureView(): Boolean {
        if (anchorsOk()) return true
        if (cfg.camAuto) {
            say("⚓ Вид сдвинулся, возвращаю камеру 🎥")
            normalizeCamera()
            pause(800)
            if (anchorsOk()) return true
        }
        return false
    }

    private fun loop() {
        if (cfg.camAuto) {
            say("🎥 Привожу камеру в рабочий вид")
            normalizeCamera()
            pause(800)
        }
        if (!anchorsOk()) {
            stopBot("Якоря не совпали: проверь камеру (кнопка 🎥 в меню)")
            return
        }
        val sellOn = cfg.first(T.SHOP) != null
        val every = cfg.sellEvery
        var round = 0
        fails = 0
        while (active) {
            if (round > 0 && !ensureView()) {
                stopBot("Камера сдвинулась, якоря не совпали")
                return
            }
            if (round > 0) {
                say("Круг $round: сбор 🔪")
                harvestOnce()
                pause(Random.nextLong(0, 1000))
            }
            round++
            say("Круг $round: посадка 🌾")
            plantOnce()
            val tPlant = System.currentTimeMillis()
            if (sellOn && round % every == 0) {
                if (sell(round)) fails = 0 else fails++
                if (fails >= 3) {
                    stopBot("3 сбоя продажи подряд")
                    return
                }
            }
            waitRipe(round, tPlant)
        }
    }

    /** Ждёт, пока пшеница созреет: по цвету грядки, а если не видно — по таймеру. */
    private fun waitRipe(round: Int, tPlant: Long) {
        val label = "Круг $round: растёт ⏳"
        val pt = cfg.first(T.HFIELD) ?: return
        val ref = if (cfg.useRec && Build.VERSION.SDK_INT >= 30) cfg.getRef(T.HFIELD) else null
        if (ref == null) {
            val wait = growMs + Random.nextLong(0, 8000) - (System.currentTimeMillis() - tPlant)
            pause(wait, label)
            return
        }
        // раньше 80% времени роста смотреть нет смысла
        pause((growMs * 8 / 10) - (System.currentTimeMillis() - tPlant), label)
        while (active) {
            val c = colorAt(pt)
            if (c != null && near(c, ref)) {
                say("Круг $round: созрела 🌾")
                pause(400 + Random.nextLong(0, 800))
                return
            }
            if (System.currentTimeMillis() - tPlant > growMs + 45_000L) {
                say("Спелую не вижу, иду по таймеру")
                return
            }
            pause(2000, label)
        }
    }

    private fun sell(round: Int): Boolean {
        val shop = cfg.first(T.SHOP) ?: return true
        val slots = cfg.list(T.SLOT).toList()
        val item = cfg.first(T.ITEM) ?: return true
        val extra = cfg.list(T.EXTRA).toList()
        val ad = cfg.first(T.AD)
        val put = cfg.first(T.PUT) ?: return true
        val close = cfg.first(T.CLOSE) ?: return true
        val rec = cfg.useRec && Build.VERSION.SDK_INT >= 30
        val shopRef = if (rec) cfg.getRef(T.CLOSE) else null
        val lotRef = if (rec) cfg.getRef(T.PUT) else null

        say("Круг $round: открываю лавку 🏪")
        tap(shop)
        pause(1800)
        if (shopRef != null && !waitColor(close, shopRef, 6000)) {
            say("Лавка не открылась, пробую ещё раз")
            tap(shop)
            pause(1800)
            if (!waitColor(close, shopRef, 6000)) {
                say("⚠ Лавка не открылась, продажу пропускаю")
                return false
            }
        }
        for ((i, slot) in slots.withIndex()) {
            if (!active) return true
            say("Круг $round: слот ${i + 1} из ${slots.size} 🧺")
            tap(slot); pause(1300 + Random.nextLong(0, 300))   // забрать выручку
            tap(slot); pause(1300 + Random.nextLong(0, 300))   // открыть выбор лота
            tap(item); pause(900)
            for (e in extra) { tap(e); pause(700) }
            if (lotRef != null && !waitColor(put, lotRef, 4000)) {
                say("⚠ Окно лота не открылось, закрываю лавку")
                tap(close)
                pause(1200)
                return false
            }
            if (ad != null && System.currentTimeMillis() - lastAd >= adCooldownMs) {
                tap(ad)
                lastAd = System.currentTimeMillis()
                pause(900)
            }
            tap(put); pause(1500)
        }
        tap(close)
        pause(1200)
        return true
    }

    // ---------- камера: одинаковый вид перед работой ----------

    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val m = resources.displayMetrics
        return Pair(m.widthPixels, m.heightPixels)
    }

    /**
     * 1) щипок двумя пальцами: отдаляем карту до предела;
     * 2) несколько свайпов к выбранному углу: карта упирается в край.
     * Так вид получается один и тот же, где бы камера ни стояла раньше.
     */
    private fun normalizeCamera() {
        val (w, h) = screenSize()
        val cx = w / 2f
        val cy = h / 2f
        for (i in 0 until 3) {
            if (!active) return
            val g0 = 0.30f * w
            val g1 = 0.03f * w
            val a = Path()
            a.moveTo(cx - g0, cy)
            a.lineTo(cx - g1, cy)
            val b = Path()
            b.moveTo(cx + g0, cy)
            b.lineTo(cx + g1, cy)
            play(
                GestureDescription.StrokeDescription(a, 0, 450),
                GestureDescription.StrokeDescription(b, 0, 450)
            )
            pause(800)
        }
        val sx = if (cfg.camDir == 0 || cfg.camDir == 2) -1f else 1f   // 0 ↖, 1 ↗, 2 ↙, 3 ↘
        val sy = if (cfg.camDir == 0 || cfg.camDir == 1) -1f else 1f
        for (i in 0 until 4) {
            if (!active) return
            val p = Path()
            p.moveTo(cx + sx * 0.30f * w, cy + sy * 0.30f * h)
            p.lineTo(cx - sx * 0.30f * w, cy - sy * 0.30f * h)
            play(GestureDescription.StrokeDescription(p, 0, 400))
            pause(500)
        }
        pause(600)
    }

    // ---------- распознавание экрана (скриншот через службу, Android 11+) ----------

    private fun near(a: Int, b: Int, tol: Int = 48): Boolean {
        val dr = Color.red(a) - Color.red(b)
        val dg = Color.green(a) - Color.green(b)
        val db = Color.blue(a) - Color.blue(b)
        return dr * dr + dg * dg + db * db < tol * tol
    }

    /** true — цвет в точке совпал с эталоном. Если скриншот не удаётся, не блокируем бота. */
    private fun waitColor(p: P, ref: Int, timeoutMs: Long): Boolean {
        val t0 = System.currentTimeMillis()
        while (active) {
            val c = colorAt(p) ?: return true
            if (near(c, ref)) return true
            if (System.currentTimeMillis() - t0 > timeoutMs) return false
            pause(600)
        }
        return false
    }

    private fun colorAt(p: P): Int? = shot(listOf(p))?.firstOrNull()

    /** Один скриншот, цвета в нескольких точках. Вызывать не из главного потока. */
    private fun shot(points: List<P>): List<Int>? {
        if (Build.VERSION.SDK_INT < 30) return null
        for (attempt in 0..1) {
            val latch = CountDownLatch(1)
            val res = AtomicReference<List<Int>?>(null)
            ui.post {
                try {
                    takeScreenshot(
                        Display.DEFAULT_DISPLAY,
                        shotExec,
                        object : AccessibilityService.TakeScreenshotCallback {
                            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                                try { res.set(readColors(r, points)) } catch (_: Exception) {}
                                latch.countDown()
                            }

                            override fun onFailure(errorCode: Int) {
                                latch.countDown()
                            }
                        }
                    )
                } catch (_: Exception) {
                    latch.countDown()
                }
            }
            latch.await(3, TimeUnit.SECONDS)
            val out = res.get()
            if (out != null) return out
            Thread.sleep(450)   // скриншоты можно делать не чаще раза в треть секунды
        }
        return null
    }

    private fun readColors(r: AccessibilityService.ScreenshotResult, points: List<P>): List<Int>? {
        val hb = r.hardwareBuffer
        val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
        hw?.recycle()
        hb.close()
        if (soft == null) return null
        val bounds = wm.maximumWindowMetrics.bounds
        val sx = soft.width.toFloat() / bounds.width()
        val sy = soft.height.toFloat() / bounds.height()
        val out = ArrayList<Int>()
        for (p in points) {
            val cx = (p.x * sx).toInt().coerceIn(3, soft.width - 4)
            val cy = (p.y * sy).toInt().coerceIn(3, soft.height - 4)
            var rr = 0
            var gg = 0
            var bb = 0
            var n = 0
            for (dy in -3..3 step 2) {
                for (dx in -3..3 step 2) {
                    val px = soft.getPixel(cx + dx, cy + dy)
                    rr += Color.red(px)
                    gg += Color.green(px)
                    bb += Color.blue(px)
                    n++
                }
            }
            out.add(Color.rgb(rr / n, gg / n, bb / n))
        }
        soft.recycle()
        return out
    }

    // ---------- жесты ----------

    private fun pause(ms: Long, label: String? = null) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        var left = ms
        var shown = -1L
        var tick = 0
        while (left > 0 && active) {
            if (label != null) {
                val s = left / 1000
                if (s != shown) {
                    shown = s
                    say(label + " " + fmt(s.toInt()))
                }
            }
            if (botMode && ++tick % 10 == 0 && !pm.isInteractive) {
                stopBot("Экран погас")
                return
            }
            Thread.sleep(minOf(left, 200L))
            left -= 200L
        }
    }

    private fun jit(a: Float) = (Random.nextFloat() * 2f - 1f) * a
    private fun j(v: Float) = v + jit(5f)

    private fun tap(p: P) {
        val path = Path()
        path.moveTo(j(p.x), j(p.y))
        play(GestureDescription.StrokeDescription(path, 0, 40L + Random.nextLong(0, 40)))
    }

    private fun drag(start: P, pts: List<P>) {
        val path = Path()
        path.moveTo(j(start.x), j(start.y))
        for (q in pts) path.lineTo(q.x + jit(2f), q.y + jit(2f))
        val len = Geo.length(start, pts)
        val dur = (len / 0.5f).toLong().coerceIn(900L, 50_000L)   // примерно 500 px в секунду
        play(GestureDescription.StrokeDescription(path, 0, dur))
    }

    /** Несколько штрихов в одном жесте = несколько пальцев одновременно. */
    private fun play(vararg strokes: GestureDescription.StrokeDescription) {
        val latch = CountDownLatch(1)
        val gb = GestureDescription.Builder()
        for (s in strokes) gb.addStroke(s)
        val g = gb.build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }
        ui.post { dispatchGesture(g, cb, null) }
        latch.await(70, TimeUnit.SECONDS)
    }
}
