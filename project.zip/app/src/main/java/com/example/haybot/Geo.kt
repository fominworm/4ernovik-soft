package com.example.haybot

import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max

object Geo {
    private fun lerp(a: P, b: P, t: Float) = P(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)
    private fun dist(a: P, b: P) = hypot(b.x - a.x, b.y - a.y)

    /** Углы по часовой стрелке, первый — самый верхний (потом правый, нижний, левый). */
    fun order(c: List<P>): List<P> {
        if (c.size < 3) return c
        val cx = c.map { it.x }.average().toFloat()
        val cy = c.map { it.y }.average().toFloat()
        val sorted = c.sortedBy { atan2((it.y - cy).toDouble(), (it.x - cx).toDouble()) }
        var top = 0
        for (i in sorted.indices) if (sorted[i].y < sorted[top].y) top = i
        return sorted.subList(top, sorted.size) + sorted.subList(0, top)
    }

    /** Змейка строками внутри четырёхугольника. gap — расстояние между строками в пикселях. */
    fun zigzag(c: List<P>, gap: Float): List<P> {
        if (c.size < 4) return c
        val q = order(c)
        val p0 = q[0]
        val p1 = q[1]
        val p2 = q[2]
        val p3 = q[3]
        val n = max(1, ceil(dist(p0, p3) / gap).toInt())
        val out = ArrayList<P>()
        for (k in 0..n) {
            val t = k.toFloat() / n
            val s = lerp(p0, p3, t)
            val e = lerp(p1, p2, t)
            if (k % 2 == 0) {
                out.add(s)
                out.add(e)
            } else {
                out.add(e)
                out.add(s)
            }
        }
        return out
    }

    fun length(start: P, pts: List<P>): Float {
        var len = 0f
        var prev = start
        for (q in pts) {
            len += dist(prev, q)
            prev = q
        }
        return len
    }
}
