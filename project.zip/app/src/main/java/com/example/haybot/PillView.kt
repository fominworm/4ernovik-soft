package com.example.haybot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Статус-капсула бота в стиле плавающей панели: тёмно-синее стекло, неоновая рамка от циана к фиолетовому,
 * робот слева, слева направо: статус | круги, монеты, пшеница, силос. Низкая и широкая, одна строка.
 */
class PillView(ctx: Context) : LinearLayout(ctx) {
    private val robot = ImageView(ctx)
    private val status = TextView(ctx)
    private val divider = View(ctx)
    private val stats = TextView(ctx)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    /** Текст до первого перевода строки идёт в статус, остальное в строку цифр. */
    var text: CharSequence
        get() = status.text
        set(v) {
            val s = v.toString()
            val i = s.indexOf('\n')
            // время ⏳ в капсуле не показываем: оно есть на основной панели
            val clean = { x: String -> x.replace(Regex("\\s*⏳\\s*[0-9:]+"), "").trim() }
            if (i < 0) {
                status.text = clean(s)
                stats.text = ""
                stats.visibility = View.GONE
                divider.visibility = View.GONE
            } else {
                status.text = clean(s.substring(0, i))
                stats.text = s.substring(i + 1)
                stats.visibility = View.VISIBLE
                divider.visibility = View.VISIBLE
            }
        }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(5), dp(16), dp(5))
        background = frame()

        // голова робота в круглой рамке с циановым кольцом
        robot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFF0B1A4A.toInt())
            setStroke(dp(1).coerceAtLeast(1), 0xFF35D6FF.toInt())
        }
        robot.clipToOutline = true
        robot.outlineProvider = ViewOutlineProvider.BACKGROUND
        robot.scaleType = ImageView.ScaleType.CENTER_CROP
        val rb = robotBitmap()
        if (rb != null) robot.setImageBitmap(rb)
        addView(robot, LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(8) })

        status.setTextColor(Color.WHITE)
        status.textSize = 12.5f
        status.setTypeface(status.typeface, android.graphics.Typeface.BOLD)
        status.maxLines = 1
        status.ellipsize = TextUtils.TruncateAt.END
        status.maxWidth = dp(250)
        status.setShadowLayer(dp(3).toFloat(), 0f, 0f, 0xFF35D6FF.toInt())
        addView(status)

        divider.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x0035D6FF, 0xCC35D6FF.toInt(), 0x0035D6FF)
        )
        addView(divider, LayoutParams(dp(1), dp(20)).apply { leftMargin = dp(10); rightMargin = dp(10) })

        stats.setTextColor(0xFFCDEBFF.toInt())
        stats.textSize = 12f
        stats.maxLines = 1
        addView(stats)
    }

    private fun frame(): LayerDrawable {
        val r = dp(22).toFloat()
        val glow = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0x4435D6FF, 0x44D13BFF)).apply { cornerRadius = r }
        val border = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF2BD4FF.toInt(), 0xFF6C5CFF.toInt(), 0xFFD13BFF.toInt())).apply { cornerRadius = r - dp(2) }
        val inner = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xF20A1538.toInt(), 0xF2140F44.toInt())).apply { cornerRadius = r - dp(4) }
        return LayerDrawable(arrayOf(glow, border, inner)).apply {
            setLayerInset(1, dp(2), dp(2), dp(2), dp(2))
            setLayerInset(2, dp(4), dp(4), dp(4), dp(4))
        }
    }

    /** Робот с плавающей панели (вырезаем из картинки панели). */
    private fun robotBitmap(): Bitmap? = try {
        val src = BitmapFactory.decodeResource(resources, R.drawable.hud)
        if (src != null && src.width >= 414 && src.height >= 168) Bitmap.createBitmap(src, 290, 44, 124, 124) else null
    } catch (_: Throwable) {
        null
    }
}
