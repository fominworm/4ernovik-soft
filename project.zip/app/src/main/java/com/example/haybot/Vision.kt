package com.example.haybot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Распознавание по картинке. Все размеры выверены на экране шириной 2400 px и пересчитываются по ширине снимка. */
object Vision {
    const val S_UNK = 0
    const val S_EMPTY = 1
    const val S_SOLD = 2
    const val S_LOT = 3

    /** Шаблон «ПРОДАНО»: сетка 8x6 цветов по щиту с петухом (у проданных слотов он всегда один). */
    private val SOLD = intArrayOf(
        0xCFC490,0xDCC37B,0xDAB453,0xCDA051,0xCF9E5F,0xC69E81,0xC99F7E,0xCBA177,
        0xECDA91,0xFBEDA5,0xEFCF68,0xD5AD53,0xD6A156,0xD0A482,0xD3A785,0xD5AB7C,
        0xECD482,0xFCF0A9,0xEFCF68,0xDFB456,0xD7A657,0xCEA27F,0xD4A987,0xD9B281,
        0xE5C46B,0xF9E390,0xECC75A,0xDDAB45,0xD5A451,0xCDA07B,0xD5A885,0xDCBA87,
        0xF0D072,0xF1CD65,0xEDC858,0xE2B148,0xD7AB58,0xD1A67E,0xD3A680,0xDBBD89,
        0xDBA739,0xD0982C,0xD29931,0xE2AD3D,0xD9AD56,0xD2A678,0xCD9E78,0xD6B884
    )

    private fun px(b: Bitmap, x: Int, y: Int): Int = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))

    private fun soldDist(b: Bitmap, cx: Int, cy: Int, k: Float): Float {
        val x0 = cx - 80f * k
        val y0 = cy - 110f * k
        val w = 160f * k
        val h = 140f * k
        var sum = 0f
        for (j in 0 until 6) {
            for (i in 0 until 8) {
                var r = 0
                var g = 0
                var bl = 0
                var n = 0
                for (sj in 0..2) {
                    for (si in 0..2) {
                        val x = (x0 + (i + (si + 0.5f) / 3f) * w / 8f).toInt()
                        val y = (y0 + (j + (sj + 0.5f) / 3f) * h / 6f).toInt()
                        val c = px(b, x, y)
                        r += Color.red(c)
                        g += Color.green(c)
                        bl += Color.blue(c)
                        n++
                    }
                }
                val t = SOLD[j * 8 + i]
                val dr = (r / n - Color.red(t)).toFloat()
                val dg = (g / n - Color.green(t)).toFloat()
                val db = (bl / n - Color.blue(t)).toFloat()
                sum += sqrt(dr * dr + dg * dg + db * db)
            }
        }
        return sum / 48f
    }

    /** Состояние слота лавки с центром (cx, cy) в пикселях снимка. */
    fun slotState(b: Bitmap, cx: Int, cy: Int): Int {
        val k = b.width / 2400f
        var best = 1e9f
        for (dx in -48..48 step 24) {
            for (dy in -32..32 step 16) {
                best = min(best, soldDist(b, cx + (dx * k).toInt(), cy + (dy * k).toInt(), k))
            }
        }
        if (best < 32f) return S_SOLD
        var gold = 0
        var cream = 0
        var n = 0
        for (dy in -90..90 step 6) {
            for (dx in -80..80 step 6) {
                val c = px(b, cx + (dx * k).toInt(), cy + (dy * k).toInt())
                val r = Color.red(c)
                val g = Color.green(c)
                val bl = Color.blue(c)
                n++
                if (r > 200 && g in 140..215 && bl < 90) gold++
                if (r > 235 && g > 205 && bl in 120..234) cream++
            }
        }
        if (gold * 100 >= n * 55 && cream * 100 < n * 3) return S_EMPTY
        return S_LOT
    }

    /** Есть ли над лавкой значок «!» (кремовая плашка). cx, cy — точка лавки в пикселях снимка. */
    fun badge(b: Bitmap, cx: Int, cy: Int): Boolean {
        val r = (200 * b.width / 2400f).toInt()
        return badgeIn(b, cx - r, cy - r, cx + r, cy + r)
    }

    /** То же по рамке (в пикселях снимка). */
    fun badgeIn(b: Bitmap, x0: Int, y0: Int, x1: Int, y1: Int): Boolean {
        val k = b.width / 2400f
        var n = 0
        var y = max(0, y0)
        while (y < min(b.height, y1)) {
            var x = max(0, x0)
            while (x < min(b.width, x1)) {
                val c = b.getPixel(x, y)
                val rr = Color.red(c)
                val gg = Color.green(c)
                val bb = Color.blue(c)
                if (rr > 245 && gg > 235 && bb in 150..215) n++
                x += 2
            }
            y += 2
        }
        return n >= max(20, (100 * k * k).toInt())
    }

    /** Красный крестик окна силоса: цвет в его центре. */
    fun redCross(c: Int): Boolean = Color.red(c) > 170 && Color.green(c) < 110 && Color.blue(c) < 110
}
