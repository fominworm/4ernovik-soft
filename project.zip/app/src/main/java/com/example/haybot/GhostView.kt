package com.example.haybot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.view.View
import java.io.File

/** Полупрозрачный эталонный снимок экрана поверх игры, чтобы совместить камеру руками. */
class GhostView(ctx: Context, private val file: File) : View(ctx) {
    private var bmp: Bitmap? = null
    private val p = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        p.alpha = 120
    }

    fun hasImage(): Boolean = file.exists()

    fun reload() {
        bmp?.recycle()
        bmp = if (file.exists()) BitmapFactory.decodeFile(file.path) else null
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        c.drawBitmap(b, null, Rect(0, 0, width, height), p)
    }
}
