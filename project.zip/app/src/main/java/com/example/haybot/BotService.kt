package com.example.haybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.text.TextUtils
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.random.Random

class BotService : AccessibilityService() {
    private val gamePkg = "com.supercell.hayday"

    private val ui = Handler(Looper.getMainLooper())
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val shotExec: Executor = Executors.newSingleThreadExecutor()
    private lateinit var cfg: Cfg

    private var step = 0
    private var expanded = true
    private var note = ""
    private var inGame = false              // сейчас на экране Hay Day
    @Volatile private var busy = false      // идёт повтор нажатия, снятие эталона или проверка
    @Volatile private var active = false    // работает фоновый поток
    private var botMode = false             // крутится основной цикл
    private var plantedAt = 0L
    @Volatile private var lastAd = 0L
    @Volatile private var stopReason: String? = null
    private var fails = 0
    private var worker: Thread? = null

    private var root: LinearLayout? = null
    private var body: LinearLayout? = null
    private var cap: MarkView? = null
    private lateinit var capLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var titleTv: TextView
    private lateinit var promptTv: TextView
    private lateinit var subTv: TextView
    private lateinit var primaryBtn: TextView
    private lateinit var foldBtn: TextView
    private lateinit var stopBtn: TextView
    private lateinit var undoBtn: TextView
    private lateinit var clearBtn: TextView
    private lateinit var minusBtn: TextView
    private lateinit var plusBtn: TextView
    private lateinit var recBtn: TextView
    private lateinit var skipBtn: TextView

    private val growMs = 121_000L          // пшеница растёт 2 мин + запас
    private val adCooldownMs = 305_000L    // реклама не чаще раза в 5 минут

    private val cGray = 0xFF4A4F57.toInt()
    private val cGreen = 0xFF2E9E4F.toInt()
    private val cRed = 0xFFD64545.toInt()
    private val cBlue = 0xFF2F6FDE.toInt()

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val panelFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    private val ticker = object : Runnable {
        override fun run() {
            if (botMode || FLOW[step].kind != Kind.WAIT) return
            val left = ((plantedAt + growMs - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
            note = if (left > 0) {
                "⏳ Осталось " + (left / 60) + ":" + (left % 60).toString().padStart(2, '0')
            } else {
                "✅ Должна быть готова"
            }
            subTv.text = note
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- жизненный цикл ----------

    override fun onServiceConnected() {
        cfg = Cfg(this)
        cfg.onExternalChange = { go(if (cfg.missing() == null) I_FINISH else 0) }
        val mv = MarkView(this, cfg)
        mv.onTap = { x, y -> onTapped(x, y) }
        capLp = overlayParams()
        wm.addView(mv, capLp)
        cap = mv
        showPanel()   // панель добавляется после слоя, значит лежит выше него
        go(if (cfg.missing() == null) I_FINISH else 0)
        inGame = false
        applyGameState()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val cls = event.className?.toString() ?: ""
        if (cls.contains("InputMethod") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        val g = pkg == gamePkg
        if (g != inGame) {
            inGame = g
            applyGameState()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        active = false
        worker?.interrupt()
        ui.removeCallbacks(ticker)
        removeView(cap)
        removeView(root)
        super.onDestroy()
    }

    /** Панель и перехват касаний живут только внутри Hay Day. */
    private fun applyGameState() {
        val v = if (inGame) View.VISIBLE else View.GONE
        root?.visibility = v
        cap?.visibility = v
        if (!inGame) {
            if (botMode) stopBot("Игра свёрнута")
            setArmed(false)
        } else {
            updateUi()
        }
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun overlayParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    /** armed = слой ловит касание пользователя; иначе касания проходят в игру. */
    private fun setArmed(on: Boolean) {
        val mv = cap ?: return
        val want = on && inGame
        if (mv.armed == want) return
        mv.armed = want
        capLp.flags = if (want) baseFlags else (baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        try { wm.updateViewLayout(mv, capLp) } catch (_: Exception) {}
        mv.invalidate()
    }

    private fun keepAwake(on: Boolean) {
        val r = root ?: return
        panelLp.flags = if (on) (panelFlags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else panelFlags
        try { wm.updateViewLayout(r, panelLp) } catch (_: Exception) {}
    }

    private fun toast(m: String) {
        ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun vis(show: Boolean): Int = if (show) View.VISIBLE else View.GONE

    private fun btn(t: String, color: Int, weight: Float = 0f, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.WHITE)
        v.textSize = 13f
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(8), dp(8), dp(8), dp(8))
        v.background = bg(color, 10)
        v.setOnClickListener { onClick() }
        val w = if (weight > 0f) 0 else ViewGroup.LayoutParams.WRAP_CONTENT
        val lp = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        v.layoutParams = lp
        return v
    }

    private fun big(t: String, color: Int, onClick: () -> Unit): TextView {
        val v = btn(t, color, 0f, onClick)
        v.textSize = 16f
        v.setPadding(dp(10), dp(12), dp(10), dp(12))
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(dp(2), dp(6), dp(2), dp(4))
        v.layoutParams = lp
        return v
    }

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(4), dp(3), dp(4), dp(3))
        return v
    }

    private fun showPanel() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = bg(0xEE101820.toInt(), 14)
        box.setPadding(dp(6), dp(6), dp(6), dp(6))

        // шапка: перетащить, заголовок, стоп, показать точки, свернуть
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val drag = btn("≡", cGray) {}
        titleTv = label(12f, 0xFFB0BEC5.toInt())
        titleTv.maxWidth = dp(170)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        stopBtn = btn("■", cRed) { stopBot("Остановлено кнопкой") }
        val eye = btn("👁", cGray) { toggleMarks() }
        foldBtn = btn("⌄", cGray) { expanded = !expanded; applyFold() }
        head.addView(drag)
        head.addView(titleTv)
        head.addView(stopBtn)
        head.addView(eye)
        head.addView(foldBtn)

        // тело: текущее задание, одна главная кнопка, мелкие кнопки
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        promptTv = label(16f, Color.WHITE, true)
        subTv = label(12.5f, 0xFFCFD8DC.toInt())
        primaryBtn = big("", cGreen) { onPrimary() }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        undoBtn = btn("↩ Назад", cGray, 1.3f) { back() }
        clearBtn = btn("🗑 Всё", cGray, 1f) { clearAll() }
        minusBtn = btn("➖", cGray, 0.6f) { adjust(-1) }
        plusBtn = btn("➕", cGray, 0.6f) { adjust(1) }
        recBtn = btn("🎯", cGray, 0.7f) { toggleRec() }
        skipBtn = btn("", cGray, 1.5f) { onSkip() }
        row.addView(undoBtn)
        row.addView(clearBtn)
        row.addView(minusBtn)
        row.addView(plusBtn)
        row.addView(recBtn)
        row.addView(skipBtn)

        b.addView(promptTv)
        b.addView(subTv)
        b.addView(primaryBtn)
        b.addView(row)

        box.addView(head)
        box.addView(b, LinearLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            panelFlags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(8)
        panelLp = lp

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }

        wm.addView(box, lp)
        root = box
        body = b
        applyFold()
    }

    private fun applyFold() {
        body?.visibility = if (expanded) View.VISIBLE else View.GONE
        foldBtn.text = if (expanded) "⌄" else "⌃"
    }

    private fun toggleMarks() {
        val mv = cap ?: return
        mv.showAll = !mv.showAll
        mv.invalidate()
    }

    private fun updateUi() {
        val s = FLOW[step]
        val r = s.role
        val n = if (r != null) cfg.list(r).size else 0
        val keep = if (s.fresh) 0 else 1
        ui.removeCallbacks(ticker)
        stopBtn.visibility = vis(botMode)

        if (botMode) {
            titleTv.text = "🤖 Бот работает"
            promptTv.text = "Бот работает. Не трогай экран."
            subTv.text = note
            primaryBtn.visibility = View.VISIBLE
            primaryBtn.text = "■ Стоп"
            primaryBtn.background = bg(cRed, 10)
            primaryBtn.alpha = 1f
            undoBtn.visibility = View.GONE
            clearBtn.visibility = View.GONE
            minusBtn.visibility = View.GONE
            plusBtn.visibility = View.GONE
            recBtn.visibility = View.GONE
            skipBtn.visibility = View.GONE
            setArmed(false)
            return
        }

        titleTv.text = "HayBot · шаг ${step + 1} из ${FLOW.size}"

        if (busy) {
            promptTv.text = "⏳ Выполняю…"
            subTv.text = note
            primaryBtn.visibility = View.GONE
            undoBtn.visibility = View.GONE
            clearBtn.visibility = View.GONE
            minusBtn.visibility = View.GONE
            plusBtn.visibility = View.GONE
            recBtn.visibility = View.GONE
            skipBtn.visibility = View.GONE
            setArmed(false)
            return
        }

        promptTv.text = s.text
        val base = if (note.isNotEmpty()) note else s.hint
        subTv.text = when {
            s.kind == Kind.FINISH -> {
                val sale = if (cfg.first(T.SHOP) != null) {
                    "🏪 Продажа после посадки в каждом " + cfg.sellEvery + "-м круге (➖ ➕)"
                } else {
                    "🏪 Без продажи"
                }
                val rec = when {
                    Build.VERSION.SDK_INT < 30 -> "🎯 Распознавание недоступно (нужен Android 11+)"
                    !cfg.useRec -> "🎯 Распознавание: выкл (кнопка 🎯)"
                    else -> "🎯 Распознавание: вкл, эталонов " +
                        listOf(T.HFIELD, T.CLOSE, T.PUT).count { cfg.getRef(it) != null } + " (кнопка 🎯)"
                }
                (if (note.isNotEmpty()) note + "\n" else "") + s.hint + "\n" + sale + "\n" + rec
            }
            r == T.AREA ->
                "Точек: $n из 4\n$base\nШаг строк: " + cfg.rowGap + " px (➖ чаще · ➕ реже)"
            s.kind == Kind.MULTI -> "Точек: $n\n$base"
            else -> base
        }

        if (s.btn != null) {
            primaryBtn.visibility = View.VISIBLE
            primaryBtn.text = s.btn
            primaryBtn.background = bg(if (s.kind == Kind.DO) cBlue else cGreen, 10)
            primaryBtn.alpha = if (s.kind == Kind.MULTI && n < s.min) 0.45f else 1f
        } else {
            primaryBtn.visibility = View.GONE
        }

        val canErase = s.kind == Kind.MULTI && n > keep
        val fin = s.kind == Kind.FINISH
        undoBtn.visibility = vis(step > 0 || canErase)
        clearBtn.visibility = vis(canErase)
        minusBtn.visibility = vis((fin && cfg.first(T.SHOP) != null) || r == T.AREA)
        plusBtn.visibility = minusBtn.visibility
        recBtn.visibility = vis(fin && Build.VERSION.SDK_INT >= 30)
        recBtn.background = bg(if (cfg.useRec) cGreen else cGray, 10)
        if (s.skip != null) {
            skipBtn.visibility = View.VISIBLE
            skipBtn.text = s.skip
        } else {
            skipBtn.visibility = View.GONE
        }

        setArmed(s.kind == Kind.TAP || s.kind == Kind.MULTI)
        if (s.kind == Kind.WAIT) ui.post(ticker)
        cap?.invalidate()
    }

    private fun say(m: String) {
        ui.post {
            note = m
            if (botMode) titleTv.text = "🤖 $m"
            subTv.text = m
        }
    }

    // ---------- мастер: переходы ----------

    private fun go(n: Int) {
        step = n.coerceIn(0, FLOW.size - 1)
        note = ""
        val s = FLOW[step]
        val r = s.role
        if (r != null && s.fresh) cfg.clear(r)
        updateUi()
    }

    private fun advance() = go(step + 1)

    private fun prevIndex(): Int =
        if (step == I_FINISH && cfg.first(T.SHOP) == null) I_ASK else step - 1

    private fun back() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role
        if (s.kind == Kind.MULTI && r != null) {
            val keep = if (s.fresh) 0 else 1
            if (cfg.list(r).size > keep) {
                cfg.removeLast(r)
                note = "↩ Последняя точка стёрта"
                updateUi()
                return
            }
        }
        if (step > 0) go(prevIndex())
    }

    private fun clearAll() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role ?: return
        if (s.kind == Kind.MULTI) {
            cfg.truncate(r, if (s.fresh) 0 else 1)
            note = "🗑 Точки стёрты"
            updateUi()
        }
    }

    private fun adjust(d: Int) {
        if (busy || botMode) return
        val s = FLOW[step]
        when {
            s.kind == Kind.FINISH -> cfg.sellEvery = cfg.sellEvery + d
            s.role == T.AREA -> cfg.rowGap = cfg.rowGap + d * 5
            else -> return
        }
        updateUi()
    }

    private fun toggleRec() {
        if (busy || botMode) return
        cfg.useRec = !cfg.useRec
        updateUi()
    }

    private fun onPrimary() {
        if (botMode) {
            stopBot("Остановлено кнопкой")
            return
        }
        if (busy) return
        val s = FLOW[step]
        when (s.kind) {
            Kind.MULTI -> {
                val r = s.role
                val n = if (r != null) cfg.list(r).size else 0
                if (n < s.min) {
                    note = "⚠ Нужно минимум " + s.min + " точки"
                    updateUi()
                } else {
                    advance()
                }
            }
            Kind.WAIT, Kind.ASK -> advance()
            Kind.DO -> doAction(s.act ?: "")
            Kind.FINISH -> startBot()
            else -> {}
        }
    }

    private fun onSkip() {
        if (busy || botMode) return
        when (FLOW[step].kind) {
            Kind.ASK -> {
                cfg.clear(T.SHOP)
                go(I_FINISH)
            }
            Kind.FINISH -> go(0)
            else -> advance()
        }
    }

    // ---------- мастер: нажатия пользователя ----------

    private fun onTapped(x: Float, y: Float) {
        if (busy || botMode) return
        val s = FLOW[step]
        if (s.kind != Kind.TAP && s.kind != Kind.MULTI) return
        val p = P(x, y)
        val r = s.role
        if (r != null) {
            if (s.kind == Kind.MULTI && s.max > 0 && cfg.list(r).size >= s.max) {
                note = "Уже " + s.max + " точки. Жми «Готово» или ↩"
                updateUi()
                return
            }
            cfg.add(r, p)
            if (r == T.AD) lastAd = System.currentTimeMillis()
        }
        if (s.kind == Kind.MULTI) note = "✔ Запомнил"

        if (s.sample && r != null && cfg.useRec && Build.VERSION.SDK_INT >= 30) {
            // сначала убираем жёлтую подсветку, потом снимаем эталон цвета, потом повторяем нажатие
            busy = true
            setArmed(false)
            Thread {
                try { Thread.sleep(200) } catch (_: InterruptedException) {}
                val c = colorAt(p)
                ui.post {
                    if (c != null) {
                        cfg.setRef(r, c)
                        toast("🎯 Эталон цвета записан")
                    } else {
                        toast("⚠ Эталон не записался, для этого шага проверка выключена")
                    }
                    finishTap(s, p)
                }
            }.start()
            return
        }
        finishTap(s, p)
    }

    private fun finishTap(s: Stp, p: P) {
        if (s.replay) {
            busy = true
            setArmed(false)
            replayTap(p) {
                busy = false
                if (s.kind == Kind.TAP) advance() else updateUi()
            }
        } else {
            busy = false
            if (s.kind == Kind.TAP) advance() else updateUi()
        }
    }

    /** Повторяет нажатие пользователя в игре (слой уже стал прозрачным для касаний). */
    private fun replayTap(p: P, then: () -> Unit) {
        ui.postDelayed({
            val path = Path()
            path.moveTo(p.x, p.y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            val cb = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ui.postDelayed({ then() }, 800) }
                override fun onCancelled(d: GestureDescription?) { ui.postDelayed({ then() }, 300) }
            }
            if (!dispatchGesture(g, cb, null)) ui.postDelayed({ then() }, 300)
        }, 180)
    }

    private fun doAction(act: String) {
        if (busy || botMode) return
        busy = true
        active = true
        note = if (act == "plant") "Сажаю пшеницу по области…" else "Собираю урожай по области…"
        setArmed(false)
        updateUi()
        worker = Thread {
            try {
                if (act == "plant") {
                    plantOnce()
                    plantedAt = System.currentTimeMillis()
                } else {
                    harvestOnce()
                }
            } catch (_: InterruptedException) {
            } finally {
                active = false
                ui.post { busy = false; advance() }
            }
        }.also { it.start() }
    }

    // ---------- основной цикл ----------

    private fun startBot() {
        val m = cfg.missing()
        if (m != null) {
            val i = FLOW.indexOfFirst { it.role == m }
            go(if (i >= 0) i else 0)
            note = "⚠ Не хватает: " + m.icon + " " + m.label
            updateUi()
            return
        }
        botMode = true
        busy = false
        active = true
        stopReason = null
        note = "Запускаю…"
        expanded = false          // панель сворачивается, чтобы не закрывать игру
        applyFold()
        keepAwake(true)
        setArmed(false)
        updateUi()
        worker = Thread {
            try {
                loop()
            } catch (_: InterruptedException) {
            } finally {
                active = false
                val why = stopReason ?: "Бот остановлен"
                stopReason = null
                ui.post {
                    botMode = false
                    keepAwake(false)
                    expanded = true
                    applyFold()
                    go(I_FINISH)
                    note = "⏹ $why"
                    updateUi()
                }
            }
        }.also { it.start() }
    }

    private fun stopBot(reason: String? = null) {
        if (reason != null) stopReason = reason
        active = false
        worker?.interrupt()
    }

    private fun plantOnce() {
        tap(cfg.first(T.FIELD)!!)
        pause(900)
        drag(cfg.first(T.WHEAT)!!, cfg.path())
        pause(900)
    }

    private fun harvestOnce() {
        tap(cfg.first(T.HFIELD)!!)
        pause(900)
        drag(cfg.first(T.SICKLE)!!, cfg.path())
        pause(1500)
    }

    private fun loop() {
        val sellOn = cfg.first(T.SHOP) != null
        val every = cfg.sellEvery
        var round = 0
        fails = 0
        while (active) {
            if (round > 0) {
                say("Круг $round: сбор 🔪")
                harvestOnce()
                pause(Random.nextLong(0, 1000))
            }
            round++
            say("Круг $round: посадка 🌾")
            plantOnce()
            val tPlant = System.currentTimeMillis()
            if (sellOn && round % every == 0) {
                if (sell(round)) fails = 0 else fails++
                if (fails >= 3) {
                    stopBot("3 сбоя продажи подряд")
                    return
                }
            }
            waitRipe(round, tPlant)
        }
    }

    /** Ждёт, пока пшеница созреет: по цвету грядки, а если не видно — по таймеру. */
    private fun waitRipe(round: Int, tPlant: Long) {
        val label = "Круг $round: растёт ⏳"
        val pt = cfg.first(T.HFIELD) ?: return
        val ref = if (cfg.useRec && Build.VERSION.SDK_INT >= 30) cfg.getRef(T.HFIELD) else null
        if (ref == null) {
            val wait = growMs + Random.nextLong(0, 8000) - (System.currentTimeMillis() - tPlant)
            pause(wait, label)
            return
        }
        pause(100_000L - (System.currentTimeMillis() - tPlant), label)   // раньше смотреть нет смысла
        while (active) {
            val c = colorAt(pt)
            if (c != null && near(c, ref)) {
                say("Круг $round: созрела 🌾")
                pause(400 + Random.nextLong(0, 800))
                return
            }
            if (System.currentTimeMillis() - tPlant > growMs + 45_000L) {
                say("Спелую не вижу, иду по таймеру")
                return
            }
            pause(2000, label)
        }
    }

    private fun sell(round: Int): Boolean {
        val shop = cfg.first(T.SHOP) ?: return true
        val slots = cfg.list(T.SLOT).toList()
        val item = cfg.first(T.ITEM) ?: return true
        val extra = cfg.list(T.EXTRA).toList()
        val ad = cfg.first(T.AD)
        val put = cfg.first(T.PUT) ?: return true
        val close = cfg.first(T.CLOSE) ?: return true
        val rec = cfg.useRec && Build.VERSION.SDK_INT >= 30
        val shopRef = if (rec) cfg.getRef(T.CLOSE) else null
        val lotRef = if (rec) cfg.getRef(T.PUT) else null

        say("Круг $round: открываю лавку 🏪")
        tap(shop)
        pause(1800)
        if (shopRef != null && !waitColor(close, shopRef, 6000)) {
            say("Лавка не открылась, пробую ещё раз")
            tap(shop)
            pause(1800)
            if (!waitColor(close, shopRef, 6000)) {
                say("⚠ Лавка не открылась, продажу пропускаю")
                return false
            }
        }
        for ((i, slot) in slots.withIndex()) {
            if (!active) return true
            say("Круг $round: слот ${i + 1} из ${slots.size} 🧺")
            tap(slot); pause(1300 + Random.nextLong(0, 300))   // забрать выручку
            tap(slot); pause(1300 + Random.nextLong(0, 300))   // открыть выбор лота
            tap(item); pause(900)
            for (e in extra) { tap(e); pause(700) }
            if (lotRef != null && !waitColor(put, lotRef, 4000)) {
                say("⚠ Окно лота не открылось, закрываю лавку")
                tap(close)
                pause(1200)
                return false
            }
            if (ad != null && System.currentTimeMillis() - lastAd >= adCooldownMs) {
                tap(ad)
                lastAd = System.currentTimeMillis()
                pause(900)
            }
            tap(put); pause(1500)
        }
        tap(close)
        pause(1200)
        return true
    }

    // ---------- распознавание экрана (скриншот через службу, Android 11+) ----------

    private fun near(a: Int, b: Int, tol: Int = 48): Boolean {
        val dr = Color.red(a) - Color.red(b)
        val dg = Color.green(a) - Color.green(b)
        val db = Color.blue(a) - Color.blue(b)
        return dr * dr + dg * dg + db * db < tol * tol
    }

    /** true — цвет в точке совпал с эталоном. Если скриншот не удаётся, не блокируем бота. */
    private fun waitColor(p: P, ref: Int, timeoutMs: Long): Boolean {
        val t0 = System.currentTimeMillis()
        while (active) {
            val c = colorAt(p) ?: return true
            if (near(c, ref)) return true
            if (System.currentTimeMillis() - t0 > timeoutMs) return false
            pause(600)
        }
        return false
    }

    /** Средний цвет небольшого участка вокруг точки. Вызывать не из главного потока. */
    private fun colorAt(p: P): Int? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        val res = AtomicReference<Int?>(null)
        ui.post {
            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    shotExec,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                            try { res.set(readColor(r, p)) } catch (_: Exception) {}
                            latch.countDown()
                        }

                        override fun onFailure(errorCode: Int) {
                            latch.countDown()
                        }
                    }
                )
            } catch (_: Exception) {
                latch.countDown()
            }
        }
        latch.await(3, TimeUnit.SECONDS)
        return res.get()
    }

    private fun readColor(r: AccessibilityService.ScreenshotResult, p: P): Int? {
        val hb = r.hardwareBuffer
        val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
        hw?.recycle()
        hb.close()
        if (soft == null) return null
        val bounds = wm.maximumWindowMetrics.bounds
        val sx = soft.width.toFloat() / bounds.width()
        val sy = soft.height.toFloat() / bounds.height()
        val cx = (p.x * sx).toInt().coerceIn(3, soft.width - 4)
        val cy = (p.y * sy).toInt().coerceIn(3, soft.height - 4)
        var rr = 0
        var gg = 0
        var bb = 0
        var n = 0
        for (dy in -3..3 step 2) {
            for (dx in -3..3 step 2) {
                val px = soft.getPixel(cx + dx, cy + dy)
                rr += Color.red(px)
                gg += Color.green(px)
                bb += Color.blue(px)
                n++
            }
        }
        soft.recycle()
        return Color.rgb(rr / n, gg / n, bb / n)
    }

    // ---------- жесты ----------

    private fun pause(ms: Long, label: String? = null) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        var left = ms
        var shown = -1L
        var tick = 0
        while (left > 0 && active) {
            if (label != null) {
                val s = left / 1000
                if (s != shown) {
                    shown = s
                    say(label + " " + (s / 60) + ":" + (s % 60).toString().padStart(2, '0'))
                }
            }
            if (botMode && ++tick % 10 == 0 && !pm.isInteractive) {
                stopBot("Экран погас")
                return
            }
            Thread.sleep(minOf(left, 200L))
            left -= 200L
        }
    }

    private fun jit(a: Float) = (Random.nextFloat() * 2f - 1f) * a
    private fun j(v: Float) = v + jit(5f)

    private fun tap(p: P) {
        val path = Path()
        path.moveTo(j(p.x), j(p.y))
        play(GestureDescription.StrokeDescription(path, 0, 40L + Random.nextLong(0, 40)))
    }

    private fun drag(start: P, pts: List<P>) {
        val path = Path()
        path.moveTo(j(start.x), j(start.y))
        for (q in pts) path.lineTo(q.x + jit(2f), q.y + jit(2f))
        val len = Geo.length(start, pts)
        val dur = (len / 0.5f).toLong().coerceIn(900L, 50_000L)   // примерно 500 px в секунду
        play(GestureDescription.StrokeDescription(path, 0, dur))
    }

    private fun play(s: GestureDescription.StrokeDescription) {
        val latch = CountDownLatch(1)
        val g = GestureDescription.Builder().addStroke(s).build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }
        ui.post { dispatchGesture(g, cb, null) }
        latch.await(70, TimeUnit.SECONDS)
    }
}
