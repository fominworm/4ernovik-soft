package com.example.haybot

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Что меню может попросить у службы. */
interface MenuHost {
    fun run()
    fun setup()
    fun close()
    fun advanced(page: Int)
    fun debug()
    fun openLink(url: String)
    fun share(text: String)
    fun clip(): String?
    fun toast(m: String)
}

/** Переключатель в неоновом стиле: дорожка и круглая ручка. */
class NeonSwitch(ctx: Context, var on: Boolean, private val change: (Boolean) -> Unit) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        setOnClickListener {
            on = !on
            invalidate()
            change(on)
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        val rect = RectF(2f, 2f, w - 2f, h - 2f)
        if (on) {
            p.shader = android.graphics.LinearGradient(0f, 0f, w, 0f, 0xFF18E0FF.toInt(), 0xFF2F6BFF.toInt(), android.graphics.Shader.TileMode.CLAMP)
            p.style = Paint.Style.FILL
            c.drawRoundRect(rect, r, r, p)
        } else {
            p.shader = null
            p.style = Paint.Style.FILL
            p.color = 0xFF150B3A.toInt()
            c.drawRoundRect(rect, r, r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = h * 0.06f
            p.shader = android.graphics.LinearGradient(0f, 0f, w, 0f, 0xFF6B7CFF.toInt(), 0xFFB04BFF.toInt(), android.graphics.Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, r, r, p)
        }
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = if (on) 0xFFE8FBFF.toInt() else 0xFFE9E4FF.toInt()
        val kr = r - h * 0.12f
        val cx = if (on) w - r else r
        c.drawCircle(cx, h / 2f, kr, p)
    }
}

/**
 * Меню поверх игры по макетам: фон-картинка во весь экран и поверх неё нажимаемые области и живые значения.
 * Размеры и координаты заданы в пикселях макета 1672×941.
 */
class MenuUi(ctx: Context, private val cfg: Cfg, private val host: MenuHost, private val W: Int, private val H: Int) : FrameLayout(ctx) {
    private val dens = ctx.resources.displayMetrics.density
    private val s = W / 1672f
    private fun px(v: Int) = (v * s).toInt()

    private val cText = 0xFFEAF0FF.toInt()
    private val cMuted = 0xFF9FB2E8.toInt()
    private val cCyan = 0xFF35D6FF.toInt()
    private val cViolet = 0xFF7B3DFF.toInt()
    private val cPink = 0xFFFF3DD6.toInt()
    private val cRed = 0xFFFF5C7A.toInt()
    private val cGreen = 0xFF2ECC71.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    private val handler = Handler(Looper.getMainLooper())
    private val stack = ArrayList<String>()
    private var screen = "home"
    private var speedTab = 0
    private var storTab = 0
    private val armed = HashSet<String>()

    private val bg = ImageView(ctx)
    private val lay = FrameLayout(ctx)

    init {
        bg.scaleType = ImageView.ScaleType.FIT_XY
        addView(bg, LayoutParams(MATCH, MATCH))
        addView(lay, LayoutParams(MATCH, MATCH))
        render()
    }

    // ---------- навигация ----------

    private fun go(sc: String) {
        stack.add(screen)
        screen = sc
        render()
    }

    private fun back() {
        if (stack.isNotEmpty()) {
            screen = stack.removeAt(stack.size - 1)
            render()
        }
    }

    private fun render() {
        lay.removeAllViews()
        armed.clear()
        val res = when (screen) {
            "speed" -> R.drawable.bg_speed
            "storage" -> R.drawable.bg_storage
            "shop" -> R.drawable.bg_shop
            "configs" -> R.drawable.bg_configs
            "help" -> R.drawable.bg_help
            "home" -> R.drawable.bg_home
            else -> 0
        }
        if (res != 0) bg.setImageResource(res) else bg.setImageDrawable(null)
        when (screen) {
            "speed" -> speed()
            "storage" -> storage()
            "shop" -> shop()
            "configs" -> configs()
            "help" -> help()
            "settings" -> settings()
            "extra" -> extra()
            else -> home()
        }
    }

    // ---------- примитивы ----------

    private fun withA(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun glass(r: Int, active: Boolean = false): LayerDrawable {
        val a = if (active) 0xFF else 0xAA
        val outer = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(withA(cCyan, a), withA(cViolet, a), withA(cPink, a)))
        outer.cornerRadius = px(r).toFloat()
        val inner = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            if (active) intArrayOf(0xFF1546B8.toInt(), 0xFF2A14A0.toInt()) else intArrayOf(0xFF081460.toInt(), 0xFF140A62.toInt())
        )
        inner.cornerRadius = px(r - 3).toFloat()
        val ld = LayerDrawable(arrayOf(outer, inner))
        ld.setLayerInset(1, px(3), px(3), px(3), px(3))
        return ld
    }

    private fun place(v: View, x: Int, y: Int, w: Int, h: Int, parent: FrameLayout = lay): View {
        val lp = LayoutParams(if (w < 0) LayoutParams.WRAP_CONTENT else px(w), if (h < 0) LayoutParams.WRAP_CONTENT else px(h))
        lp.leftMargin = px(x)
        lp.topMargin = px(y)
        parent.addView(v, lp)
        return v
    }

    private fun press(v: View) {
        v.isClickable = true
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.alpha = 0.65f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.alpha = 1f
            }
            false
        }
    }

    /** Невидимая нажимаемая область поверх нарисованной на макете кнопки. */
    private fun hit(x: Int, y: Int, w: Int, h: Int, r: Int = 26, parent: FrameLayout = lay, action: () -> Unit): View {
        val v = View(context)
        v.isClickable = true
        v.setOnTouchListener { vv, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    val g = GradientDrawable()
                    g.setColor(0x33FFFFFF)
                    g.cornerRadius = px(r).toFloat()
                    vv.background = g
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> vv.background = null
            }
            false
        }
        v.setOnClickListener { action() }
        return place(v, x, y, w, h, parent)
    }

    private fun tv(t: CharSequence, size: Int, color: Int = cText, bold: Boolean = false): TextView {
        val v = TextView(context)
        v.text = t
        v.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * s)
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.includeFontPadding = false
        return v
    }

    private fun tvAt(t: CharSequence, x: Int, y: Int, w: Int, h: Int, size: Int, color: Int = cText, bold: Boolean = false,
                     gravity: Int = Gravity.START or Gravity.CENTER_VERTICAL, parent: FrameLayout = lay): TextView {
        val v = tv(t, size, color, bold)
        v.gravity = gravity
        place(v, x, y, w, h, parent)
        return v
    }

    private fun panelAt(x: Int, y: Int, w: Int, h: Int, r: Int = 28, active: Boolean = false): FrameLayout {
        val f = FrameLayout(context)
        f.background = glass(r, active)
        place(f, x, y, w, h)
        return f
    }

    private fun chip(t: String, x: Int, y: Int, w: Int, h: Int, size: Int, active: Boolean = false, parent: FrameLayout, action: () -> Unit): TextView {
        val v = tv(t, size, cText, true)
        v.gravity = Gravity.CENTER
        v.background = glass(h / 2, active)
        press(v)
        v.setOnClickListener { action() }
        place(v, x, y, w, h, parent)
        return v
    }

    /** Кнопка в два нажатия: первое только просит подтвердить, второе выполняет. */
    private fun confirmHit(key: String, x: Int, y: Int, w: Int, h: Int, onYes: () -> Unit) {
        hit(x, y, w, h) {
            if (armed.remove(key)) {
                onYes()
            } else {
                armed.add(key)
                val c = tv("Точно? Нажми ещё раз", 30, cText, true)
                c.gravity = Gravity.CENTER
                val g = GradientDrawable()
                g.setColor(0xF0B01030.toInt())
                g.setStroke(px(3), cRed)
                g.cornerRadius = px(26).toFloat()
                c.background = g
                press(c)
                place(c, x, y, w, h)
                c.setOnClickListener {
                    armed.remove(key)
                    onYes()
                }
                handler.postDelayed({
                    if (armed.remove(key)) lay.removeView(c)
                }, 3000)
            }
        }
    }

    // ---------- главная ----------

    private fun home() {
        hit(52, 487, 323, 181) { host.run() }
        hit(385, 487, 295, 181) { host.setup() }
        hit(690, 487, 300, 181) { go("settings") }
        hit(998, 487, 293, 181) { go("configs") }
        hit(1300, 487, 320, 181) { go("help") }
        hit(1517, 838, 128, 78, 39) { host.close() }
        val ready = cfg.missingPair() == null
        tvAt(
            if (ready) "● Настройка завершена: можно запускать" else "⚠ Настройка не завершена: нажми «Настроить заново»",
            52, 700, 1568, 50, 28, if (ready) cGreen else cRed, true, Gravity.CENTER
        )
    }

    // ---------- помощь ----------

    private fun help() {
        hit(45, 45, 212, 90, 28) { back() }
        hit(615, 528, 730, 152, 60) { host.openLink(LicenseConfig.SUPPORT_URL) }
        chip("🐞  Скопировать debug", 45, 866, 420, 62, 26, false, lay) { host.debug() }
        chip("📢  Канал", 485, 866, 300, 62, 26, false, lay) { host.openLink(LicenseConfig.CHANNEL_URL) }
        chip("✕  Закрыть", 1330, 866, 290, 62, 26, false, lay) { host.close() }
    }

    // ---------- разделы настроек (рамка-подложка) ----------

    private fun frameScreen(title: String, sub: String): FrameLayout {
        // рамка 2:1 по центру экрана 16:9
        val fw = W
        val fh = W / 2
        val fy = (H - fh) / 2
        val img = ImageView(context)
        img.setImageResource(R.drawable.panel_frame)
        img.scaleType = ImageView.ScaleType.FIT_XY
        val lp = LayoutParams(fw, fh)
        lp.topMargin = fy
        lay.addView(img, lp)
        val inner = FrameLayout(context)
        val ilp = LayoutParams(fw, fh)
        ilp.topMargin = fy
        lay.addView(inner, ilp)
        // координаты внутри: 1672×836 (рамка 2:1 в масштабе макета)
        val k = 1672f / 1774f
        fun m(v: Int) = (v * k).toInt()
        val backV = tv("‹ Назад", 30, cText, true)
        backV.gravity = Gravity.CENTER
        backV.background = glass(26)
        press(backV)
        backV.setOnClickListener { back() }
        place(backV, m(48), m(40), m(260), m(120), inner)
        tvAt(title, m(360), m(46), 900, 60, 46, cText, true, Gravity.START or Gravity.CENTER_VERTICAL, inner)
        tvAt(sub, m(362), m(108), 1000, 40, 26, cMuted, false, Gravity.START or Gravity.CENTER_VERTICAL, inner)
        val close = tv("✕", 40, cText, true)
        close.gravity = Gravity.CENTER
        close.background = glass(24)
        press(close)
        close.setOnClickListener { host.close() }
        place(close, m(1580), m(50), 90, 90, inner)
        return inner
    }

    private fun tile(parent: FrameLayout, icon: String, title: String, sub: String, x: Int, y: Int, w: Int, h: Int, active: Boolean = false, action: () -> Unit) {
        val f = FrameLayout(context)
        f.background = glass(30, active)
        press(f)
        f.setOnClickListener { action() }
        place(f, x, y, w, h, parent)
        tvAt(icon, 0, 24, w, h * 45 / 100, 100, cText, false, Gravity.CENTER, f)
        tvAt(title, 8, h * 55 / 100, w - 16, 44, 34, cText, true, Gravity.CENTER, f)
        tvAt(sub, 8, h * 55 / 100 + 48, w - 16, 34, 22, cMuted, false, Gravity.CENTER, f)
    }

    private fun settings() {
        val f = frameScreen("⚙ Настройки", "Выбери раздел")
        val k = 1672f / 1774f
        val x0 = (140 * k).toInt() + 30
        val cw = 440
        val gap = 36
        val y1 = (240 * k).toInt()
        val ch = 240
        tile(f, "⚡", "Скорость", "посев, сбор, лавка", x0, y1, cw, ch, true) { go("speed") }
        tile(f, "📦", "Хранилище", "силос и подсчёт", x0 + cw + gap, y1, cw, ch) { go("storage") }
        tile(f, "🏪", "Магазин", "продажа и реклама", x0 + 2 * (cw + gap), y1, cw, ch) { go("shop") }
        val y2 = y1 + ch + 30
        tile(f, "🛠", "Дополнительно", "прижим земли, режимы", x0, y2, cw, ch) { go("extra") }
        tile(f, "🧩", "Свои задачи", "макросы по таймеру", x0 + cw + gap, y2, cw, ch) { host.advanced(2) }
        tile(f, "🧪", "Тесты и эталон", "🌱 🔪 📸 👻", x0 + 2 * (cw + gap), y2, cw, ch) { host.advanced(0) }
    }

    // ---------- скорость ----------

    private class SpeedItem(
        val icon: String, val title: String, val sub: String, val tip: String, val rec: String,
        val min: Int, val max: Int, val step: Int,
        val get: () -> Int, val set: (Int) -> Unit, val show: (Int) -> String
    )

    private fun speed() {
        hit(45, 50, 212, 82, 28) { back() }
        val pct = { v: Int -> "$v %" }
        val ms = { v: Int -> "$v мс" }
        val items = listOf(
            SpeedItem("🌱", "Посадка культуры", "Скорость посадки культур на поле", "Чем больше значение, тем быстрее палец ведёт по полю при посеве.", "500 %",
                50, 600, 10, { cfg.speedPlant }, { cfg.speedPlant = it }, pct),
            SpeedItem("🌾", "Сбор культуры", "Скорость сбора урожая серпом", "Чем больше значение, тем быстрее палец ведёт по полю при сборе.", "500 %",
                50, 600, 10, { cfg.speedHarvest }, { cfg.speedHarvest = it }, pct),
            SpeedItem("⏱", "Задержка между посадками и сбором", "Пауза после каждой посадки и сбора", "Если камера сдвигается или игра не успевает, увеличь паузу. 0 — без добавочной паузы.", "0 мс",
                0, 10000, 100, { cfg.delayAct }, { cfg.delayAct = it }, ms),
            SpeedItem("🏪", "Выставление предметов", "Скорость работы бота в лавке", "Чем больше значение, тем быстрее бот нажимает в лавке. Если окна не успевают открываться, уменьши.", "200 %",
                50, 400, 10, { cfg.speedShop }, { cfg.speedShop = it }, pct),
            SpeedItem("🛒", "Задержка между выставлением в магазин", "Пауза после каждого выставленного слота", "Увеличь, если игра пропускает нажатия при выставлении. 0 — без добавочной паузы.", "0 мс",
                0, 10000, 100, { cfg.delayShop }, { cfg.delayShop = it }, ms)
        )
        if (speedTab >= items.size) speedTab = 0
        // левый список разделов
        val side = panelAt(33, 226, 344, 640, 30)
        val rowH = 118
        for ((i, si) in items.withIndex()) {
            val row = FrameLayout(context)
            row.background = glass(24, i == speedTab)
            press(row)
            row.setOnClickListener {
                speedTab = i
                render()
            }
            place(row, 10, 12 + i * (rowH + 6), 324, rowH, side)
            tvAt(si.icon, 8, 0, 80, rowH, 54, cText, false, Gravity.CENTER, row)
            tvAt(si.title, 92, 4, 226, rowH - 8, 26, cText, i == speedTab, Gravity.START or Gravity.CENTER_VERTICAL, row)
        }
        // правая панель
        val cur = items[speedTab]
        val main = panelAt(405, 224, 1236, 642, 34)
        tvAt(cur.icon, 30, 24, 190, 190, 130, cText, false, Gravity.CENTER, main)
        tvAt(cur.title, 250, 56, 600, 56, 40, cText, true, Gravity.START or Gravity.CENTER_VERTICAL, main)
        tvAt(cur.sub, 250, 114, 640, 40, 26, cMuted, false, Gravity.START or Gravity.CENTER_VERTICAL, main)
        chip("⚡ Рекомендуемое: " + cur.rec, 880, 52, 330, 66, 22, false, main) {}
        // ползунок
        val box = FrameLayout(context)
        box.background = glass(30)
        place(box, 24, 218, 1188, 130, main)
        var v = cur.get().coerceIn(cur.min, cur.max)
        val valueTv = tv(cur.show(v), 46, cText, true)
        valueTv.gravity = Gravity.CENTER
        val sb = SeekBar(context)
        sb.max = (cur.max - cur.min) / cur.step
        sb.progress = (v - cur.min) / cur.step
        sb.progressTintList = ColorStateList.valueOf(cCyan)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0xFF050A40.toInt())
        sb.thumbTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        sb.setPadding(px(24), 0, px(24), 0)
        fun setV(n: Int) {
            v = n.coerceIn(cur.min, cur.max)
            valueTv.text = cur.show(v)
            sb.progress = (v - cur.min) / cur.step
            cur.set(v)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sbar: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    v = cur.min + p * cur.step
                    valueTv.text = cur.show(v)
                    cur.set(v)
                }
            }

            override fun onStartTrackingTouch(sbar: SeekBar?) {}
            override fun onStopTrackingTouch(sbar: SeekBar?) {}
        })
        place(sb, 18, 36, 840, 58, box)
        val vb = FrameLayout(context)
        vb.background = glass(22)
        place(vb, 880, 17, 292, 96, box)
        place(valueTv, 0, 0, 220, 96, vb)
        chip("▲", 224, 6, 62, 40, 22, false, vb) { setV(v + cur.step) }
        chip("▼", 224, 50, 62, 40, 22, false, vb) { setV(v - cur.step) }
        // подсказка
        val info = FrameLayout(context)
        info.background = glass(26)
        place(info, 24, 380, 1188, 120, main)
        tvAt("ⓘ", 26, 0, 70, 120, 56, cCyan, true, Gravity.CENTER, info)
        tvAt(cur.tip, 110, 6, 1050, 108, 28, cText, false, Gravity.START or Gravity.CENTER_VERTICAL, info)
        tvAt("Если бот начал промахиваться, уменьши скорость.", 24, 520, 1188, 40, 24, cMuted, false, Gravity.START or Gravity.CENTER_VERTICAL, main)
    }

    // ---------- хранилище ----------

    private fun numText(n: Int): SpannableString {
        val t = "$n шт."
        val sp = SpannableString(t)
        val i = n.toString().length
        sp.setSpan(AbsoluteSizeSpan((86 * s).toInt(), false), 0, i, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(AbsoluteSizeSpan((34 * s).toInt(), false), i, t.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(ForegroundColorSpan(cMuted), i, t.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sp
    }

    private fun storage() {
        hit(45, 47, 205, 85, 28) { back() }
        if (storTab == 0) {
            hit(845, 208, 788, 106, 36) {
                storTab = 1
                render()
            }
            val used = cfg.barnUsed
            val cap = cfg.barnCap
            val t1 = tv(numText(used), 86, cText, true)
            t1.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            place(t1, 715, 418, 300, 90)
            val t2 = tv(numText(cap), 86, cText, true)
            t2.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            place(t2, 1282, 418, 300, 90)
            // полоса заполнения
            val pc = if (cap > 0) (used * 100 / cap).coerceIn(0, 100) else 0
            val track = View(context)
            val tg = GradientDrawable()
            tg.setColor(0xFF03072E.toInt())
            tg.setStroke(px(3), 0xFF2A3AA8.toInt())
            tg.cornerRadius = px(25).toFloat()
            track.background = tg
            place(track, 513, 553, 942, 50)
            if (pc > 0) {
                val fill = View(context)
                val fg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF1BE3FF.toInt(), 0xFF2F8BFF.toInt()))
                fg.cornerRadius = px(25).toFloat()
                fill.background = fg
                place(fill, 513, 553, (942 * pc / 100).coerceAtLeast(50), 50)
            }
            tvAt("$pc%", 1470, 548, 150, 60, 50, cCyan, true, Gravity.CENTER)
            tvAt("Нажми вкладку «Лимит хранилища», чтобы поправить числа", 513, 618, 1000, 30, 20, cMuted, false)
        } else {
            // вкладки перерисовываем сами, а содержимое показываем вместо блока с силосом
            val tabs = panelAt(40, 208, 1595, 106, 36)
            tabs.setBackgroundColor(0)
            val t1 = FrameLayout(context)
            t1.background = glass(36, false)
            press(t1)
            t1.setOnClickListener {
                storTab = 0
                render()
            }
            place(t1, 0, 0, 786, 106, tabs)
            tvAt("🌾  Информация о хранилище", 0, 0, 786, 106, 34, cText, false, Gravity.CENTER, t1)
            val t2 = FrameLayout(context)
            t2.background = glass(36, true)
            place(t2, 805, 0, 788, 106, tabs)
            tvAt("📦  Лимит хранилища", 0, 0, 788, 106, 34, cText, true, Gravity.CENTER, t2)
            val p = panelAt(40, 330, 1595, 326, 36)
            steps(p, 12, "Занято сейчас", { cfg.barnUsed }, { cfg.barnUsed = it }, intArrayOf(10, 100))
            steps(p, 76, "Вместимость хранилища", { cfg.barnCap }, { cfg.barnCap = it }, intArrayOf(25, 100))
            steps(p, 140, "Клеток на первом поле", { cfg.cellsOf(0) }, { cfg.setCells(0, it.coerceAtLeast(0)) }, intArrayOf(1, 5))
            steps(p, 204, "Урожай с одной клетки", { cfg.perCell }, { cfg.perCell = it }, intArrayOf(1))
            steps(p, 268, "Пшеницы в одном слоте лавки", { cfg.perSlot }, { cfg.perSlot = it }, intArrayOf(1, 5))
        }
        // переключатель автоподсчёта
        place(NeonSwitch(context, cfg.autoCount) { cfg.autoCount = it }, 1383, 733, 200, 92)
    }

    /** Строка «подпись  −  значение  +» для чисел без поля ввода. */
    private fun steps(parent: FrameLayout, y: Int, label: String, get: () -> Int, set: (Int) -> Unit, st: IntArray, pw: Int = 1595) {
        val valueTv = tv(get().toString(), 38, cText, true)
        valueTv.gravity = Gravity.CENTER
        val bw = 104
        val vw = 170
        var x = pw - 24 - (st.size * 2 * (bw + 8) + vw)
        tvAt(label, 30, y, x - 40, 56, 27, cText, false, Gravity.START or Gravity.CENTER_VERTICAL, parent)
        for (d in st.sortedDescending()) {
            chip("−$d", x, y + 4, bw, 48, 24, false, parent) {
                set(get() - d)
                valueTv.text = get().toString()
            }
            x += bw + 8
        }
        place(valueTv, x, y, vw, 56, parent)
        x += vw
        for (d in st.sorted()) {
            x += 8
            chip("+$d", x, y + 4, bw, 48, 24, false, parent) {
                set(get() + d)
                valueTv.text = get().toString()
            }
            x += bw
        }
    }

    // ---------- магазин ----------

    private fun shop() {
        hit(45, 47, 210, 86, 28) { back() }
        val sw1 = NeonSwitch(context, cfg.sellOnFull) { cfg.sellOnFull = it }
        place(sw1, 1368, 308, 222, 102)
        val sw2 = NeonSwitch(context, cfg.adOn) { cfg.adOn = it }
        place(sw2, 1368, 655, 222, 102)
        // вся карточка тоже переключает
        hit(37, 215, 1320, 327, 40) { sw1.performClick() }
        hit(37, 575, 1320, 287, 40) { sw2.performClick() }
        if (cfg.first(T.SHOP, 0) == null) {
            tvAt("⚠ Лавка не настроена в мастере (шаг «Лавка»): продажа не работает", 40, 880, 1590, 50, 26, cRed, true, Gravity.CENTER)
        } else if (!cfg.sellOnFull) {
            tvAt("Продажа по заполнению выключена: бот продаёт раз в " + cfg.sellEvery + " посадок (меняется в «Настройки → Дополнительно»)", 40, 880, 1590, 50, 24, cMuted, false, Gravity.CENTER)
        }
    }

    // ---------- конфиги ----------

    private fun fmtTime(t: Long): String =
        if (t <= 0L) "—" else SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(t))

    private fun configs() {
        hit(45, 47, 212, 86, 28) { back() }
        hit(415, 210, 605, 138, 36) {
            val name = "Конфиг " + SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date())
            cfg.saveProfile(name)
            host.toast("Сохранено: $name")
            render()
        }
        hit(1047, 210, 590, 138, 36) {
            val t = host.clip()
            if (t.isNullOrBlank()) host.toast("Скопируй текст конфига и нажми снова")
            else if (cfg.importJson(t)) host.toast("Загружено. Нажми «Сохранить конфиг», чтобы оставить")
            else host.toast("Не получилось: текст конфига повреждён")
        }
        confirmHit("reset", 33, 792, 822, 110) {
            cfg.resetDefaults()
            host.toast("Настройки сброшены (поля и точки остались)")
            render()
        }
        confirmHit("delall", 882, 792, 757, 110) {
            cfg.deleteAllProfiles()
            render()
        }
        val names = cfg.profileNames()
        tvAt("Всего: " + names.size, 1480, 396, 140, 50, 28, cCyan, true, Gravity.END or Gravity.CENTER_VERTICAL)
        // список закрывает нарисованные на макете строки
        val cover = FrameLayout(context)
        val cg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF07187A.toInt(), 0xFF100A74.toInt(), 0xFF22097A.toInt()))
        cg.cornerRadius = px(22).toFloat()
        cover.background = cg
        place(cover, 428, 452, 1196, 288)
        if (names.isEmpty()) {
            tvAt("Конфигов пока нет. Нажми «Сохранить конфиг».", 0, 0, 1196, 288, 30, cMuted, false, Gravity.CENTER, cover)
            return
        }
        val sc = ScrollView(context)
        sc.isVerticalScrollBarEnabled = false
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        sc.addView(col)
        place(sc, 0, 0, 1196, 288, cover)
        for (name in names) {
            val act = name == cfg.activeProfile
            val row = FrameLayout(context)
            row.background = glass(26, act)
            val lp = LinearLayout.LayoutParams(px(1184), px(88))
            lp.setMargins(px(6), px(5), px(6), px(5))
            col.addView(row, lp)
            tvAt(if (act) "⭐" else "📄", 14, 0, 80, 88, 50, cText, false, Gravity.CENTER, row)
            tvAt(name, 108, 8, 560, 42, 30, cText, true, Gravity.START or Gravity.CENTER_VERTICAL, row)
            tvAt("Последнее изменение: " + fmtTime(cfg.profileTime(name)), 108, 50, 640, 32, 21, cMuted, false, Gravity.START or Gravity.CENTER_VERTICAL, row)
            chip(if (act) "Активный" else "Сделать активным", 690, 18, 232, 52, 22, act, row) {
                host.toast(if (cfg.loadProfile(name)) "Активен: $name" else "Не удалось загрузить")
                render()
            }
            chip("▶", 946, 12, 66, 64, 30, false, row) {
                if (cfg.loadProfile(name)) {
                    host.close()
                    host.run()
                } else host.toast("Не удалось загрузить")
            }
            chip("📤", 1026, 12, 66, 64, 30, false, row) {
                val json = cfg.profileJson(name)
                if (json != null) host.share(json)
            }
            val key = "del_$name"
            val del = chip("🗑", 1106, 12, 66, 64, 30, false, row) {}
            del.setOnClickListener {
                if (armed.remove(key)) {
                    cfg.deleteProfile(name)
                    render()
                } else {
                    armed.add(key)
                    del.text = "?"
                    del.setTextColor(cRed)
                    handler.postDelayed({
                        if (armed.remove(key)) {
                            del.text = "🗑"
                            del.setTextColor(cText)
                        }
                    }, 3000)
                }
            }
        }
    }

    // ---------- дополнительно (новый раздел на рамке) ----------

    private fun extra() {
        val f = frameScreen("🛠 Дополнительно", "Тонкие настройки бота")
        val k = 1672f / 1774f
        val sc = ScrollView(context)
        sc.isVerticalScrollBarEnabled = false
        val rows = 11
        val rh = 70
        val holder = FrameLayout(context)
        sc.addView(holder, FrameLayout.LayoutParams(px(1480), px(rows * rh + 20)))
        place(sc, (110 * k).toInt(), (215 * k).toInt(), 1480, (590 * k).toInt(), f)
        var y = 6
        fun st(label: String, get: () -> Int, set: (Int) -> Unit, sts: IntArray) {
            steps(holder, y, label, get, set, sts, 1480)
            y += rh
        }
        fun tg(label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            tvAt(label, 30, y, 1100, 56, 27, cText, false, Gravity.START or Gravity.CENTER_VERTICAL, holder)
            place(NeonSwitch(context, get()) { set(it) }, 1300, y + 2, 140, 52, holder)
            y += rh
        }
        st("🟫 Прижим земли, мс (меньше 600 = выкл)", { cfg.groundMs }, { cfg.groundMs = if (it in 1..599) 600 else it }, intArrayOf(100, 500))
        st("🟫 Перехват: палец на землю раньше отпускания, мс", { cfg.groundLead }, { cfg.groundLead = it }, intArrayOf(10, 50))
        st("✋ Удержание иконки, мс", { cfg.holdMs }, { cfg.holdMs = it }, intArrayOf(50, 100))
        st("🧱 Отступ от краёв экрана, %", { cfg.edgePct }, { cfg.edgePct = it }, intArrayOf(2))
        st("🏪 Продажа раз в N посадок (если выкл. «при заполнении»)", { cfg.sellEvery }, { cfg.sellEvery = it }, intArrayOf(1))
        st("📄 Страниц лавки", { cfg.shopPages }, { cfg.shopPages = it }, intArrayOf(1))
        st("↔ Длина свайпа лавки, px", { cfg.swipeLen }, { cfg.swipeLen = it }, intArrayOf(100))
        st("🧪 Режим посадки (0–4)", { cfg.plantMode }, { cfg.plantMode = it }, intArrayOf(1))
        tg("🎯 Распознавание экрана", { cfg.useRec }, { cfg.useRec = it })
        tg("📷 Выравнивание камеры", { cfg.autoAlign }, { cfg.autoAlign = it })
        tg("✨ Радужный след на касаниях", { cfg.trail }, { cfg.trail = it })
    }
}
