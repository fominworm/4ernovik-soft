package com.example.haybot

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class P(val x: Float, val y: Float)

/** Одно нажатие в записанной задаче: куда нажать и сколько ждать перед ним. */
data class MTap(val p: P, val dtMs: Long)

/** Роли точек. multi — можно несколько точек, min — сколько нужно минимум, perField — своя у каждого поля. */
enum class T(
    val icon: String,
    val label: String,
    val multi: Boolean,
    val min: Int,
    val color: Int,
    val perField: Boolean = false
) {
    FIELD("🌱", "Грядка", false, 1, 0xFF4CAF50.toInt(), true),
    WHEAT("🌾", "Культура", false, 1, 0xFFFFC107.toInt(), true),
    AREA("🧭", "Поле", true, 4, 0xFF29B6F6.toInt(), true),
    HFIELD("🌿", "Грядка (сбор)", false, 1, 0xFF8BC34A.toInt(), true),
    SICKLE("🔪", "Серп", false, 1, 0xFFEF5350.toInt(), true),
    GROUND("🟫", "Пустая земля", false, 0, 0xFF8D6E63.toInt()),
    SHOP("🏪", "Лавка", false, 0, 0xFFAB47BC.toInt()),
    SLOT("🧺", "Слот", true, 1, 0xFFFF7043.toInt()),
    SWIPE("↔", "Листание лавки", true, 0, 0xFF7E57C2.toInt()),
    SLOT2("🧺²", "Слоты стр. 2", true, 0, 0xFFFF8A65.toInt()),
    SLOT3("🧺³", "Слоты стр. 3", true, 0, 0xFFFFAB91.toInt()),
    ITEM("📦", "Товар", false, 1, 0xFFFFCA28.toInt()),
    ITEMS("🔎", "Ячейки списка", true, 0, 0xFFFFE082.toInt()),
    EXTRA("➕", "Доп. кнопка", true, 0, 0xFF26A69A.toInt()),
    AD("📢", "Реклама", false, 0, 0xFFEC407A.toInt()),
    PUT("✅", "Выставить", false, 1, 0xFF66BB6A.toInt()),
    CLOSE("❌", "Закрыть", false, 1, 0xFFE53935.toInt()),
    SILO("🏛", "Силос", false, 0, 0xFF8D6E63.toInt()),
    SILOTXT("🔢", "Рамка «занято/всего»", true, 0, 0xFF26C6DA.toInt()),
    SILOWHEAT("🌾", "Рамка числа пшеницы", true, 0, 0xFFFFEE58.toInt()),
    SILOX("✖", "Крестик силоса", false, 0, 0xFFE53935.toInt()),
    SHOPBOX("🔲", "Рамка лавки и значка «!»", true, 0, 0xFFAB47BC.toInt())
}

class Cfg(ctx: Context) {
    companion object {
        const val MAXF = 4   // максимум полей
        const val MAXM = 5   // максимум своих задач
        const val DEFAULT_PMODE = 4
    }

    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private val prof = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)
    private val pts = HashMap<String, MutableList<P>>()

    /** Какое поле сейчас настраиваем или показываем. */
    var cur = 0

    /** Вызывается, когда настройки заменили снаружи (загрузка профиля, импорт). */
    var onExternalChange: (() -> Unit)? = null

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "rev") {
            reload()
            onExternalChange?.invoke()
        }
    }

    init {
        reload()
        sp.registerOnSharedPreferenceChangeListener(listener)
    }

    private fun key(t: T, f: Int) = if (t.perField && f > 0) t.name + "#" + f else t.name

    fun reload() {
        pts.clear()
        for (f in 0 until MAXF) {
            for (t in T.values()) {
                if (f > 0 && !t.perField) continue
                val k = key(t, f)
                pts[k] = dec(sp.getString(k, null))
            }
        }
    }

    // ---------- настройки ----------

    var sellEvery: Int
        get() = sp.getInt("every", 3)
        set(v) {
            sp.edit().putInt("every", v.coerceIn(1, 9)).apply()
        }

    /** Пауза после отпускания посева перед прижимом земли, мс. */
    var groundGap: Int
        get() = sp.getInt("ggap", 80)
        set(v) {
            sp.edit().putInt("ggap", v.coerceIn(0, 3000)).apply()
        }

    /** Пауза после каждой посадки и сбора, мс. */
    var delayAct: Int
        get() = sp.getInt("dact", 0)
        set(v) {
            sp.edit().putInt("dact", v.coerceIn(0, 10000)).apply()
        }

    /** Пауза после каждого выставленного слота лавки, мс. */
    var delayShop: Int
        get() = sp.getInt("dshop", 0)
        set(v) {
            sp.edit().putInt("dshop", v.coerceIn(0, 10000)).apply()
        }

    /** Бот сам считает, сколько пшеницы в силосе. */
    var autoCount: Boolean
        get() = sp.getBoolean("acount", true)
        set(v) {
            sp.edit().putBoolean("acount", v).apply()
        }

    /** Продавать, когда силос заполнен (иначе раз в N посадок). */
    var sellOnFull: Boolean
        get() = sp.getBoolean("sfull", true)
        set(v) {
            sp.edit().putBoolean("sfull", v).apply()
        }

    /** Ставить товар в рекламу. */
    var adOn: Boolean
        get() = sp.getBoolean("adon", true)
        set(v) {
            sp.edit().putBoolean("adon", v).apply()
        }

    var rowGap: Int
        get() = sp.getInt("gap", 45)
        set(v) {
            sp.edit().putInt("gap", v.coerceIn(15, 150)).apply()
        }

    var useRec: Boolean
        get() = sp.getBoolean("rec", true)
        set(v) {
            sp.edit().putBoolean("rec", v).apply()
        }

    /** Сколько миллисекунд держим палец на иконке (культура, серп) перед тем, как вести по грядкам. */
    var holdMs: Int
        get() = sp.getInt("hold", 600)
        set(v) {
            sp.edit().putInt("hold", v.coerceIn(100, 2000)).apply()
        }

    /** Как вести палец: 0 плавно, 1 медленно, 2 по шагам, 3 как человек (быстро туда-сюда). */
    var plantMode: Int
        get() = sp.getInt("pmode", DEFAULT_PMODE)
        set(v) {
            sp.edit().putInt("pmode", ((v % 5) + 5) % 5).apply()
        }

    /** Сколько страниц слотов в лавке (листаются по горизонтали). */
    var shopPages: Int
        get() = sp.getInt("spages", 1).coerceIn(1, 6)
        set(v) {
            sp.edit().putInt("spages", v.coerceIn(1, 6)).apply()
        }

    /** Цена одного слота лавки, монет: по ней бот считает заработанное (0 — не считать). */
    var slotPrice: Int
        get() = sp.getInt("sprice", 0).coerceIn(0, 1_000_000)
        set(v) {
            sp.edit().putInt("sprice", v.coerceIn(0, 1_000_000)).apply()
        }

    /** Положение статус-капсулы на экране (пиксели), -1 — по умолчанию сверху по центру. */
    var pillX: Int
        get() = sp.getInt("pillx", -1)
        set(v) {
            sp.edit().putInt("pillx", v).apply()
        }
    var pillY: Int
        get() = sp.getInt("pilly", -1)
        set(v) {
            sp.edit().putInt("pilly", v).apply()
        }

    /** Не продавать, если пшеницы в силосе меньше этого числа (0 — без ограничения). */
    var minSellWheat: Int
        get() = sp.getInt("minsell", 20).coerceIn(0, 5000)
        set(v) {
            sp.edit().putInt("minsell", v.coerceIn(0, 5000)).apply()
        }

    /** Поправка к длине свайпа листания лавки, px (длина считается сама: число колонок слотов × шаг между ними). */
    var swipeAdj: Int
        get() = sp.getInt("swadj", 0).coerceIn(-600, 600)
        set(v) {
            sp.edit().putInt("swadj", v.coerceIn(-600, 600)).apply()
        }

    /** Длительность записанного свайпа листания, мс. */
    var swipeMs: Int
        get() = sp.getInt("swms", 700).coerceIn(60, 2500)
        set(v) {
            sp.edit().putInt("swms", v.coerceIn(60, 2500)).apply()
        }

    /** Возвращать ли палец к исходной грядке после посадки/сбора: 0 нет, 1 да (медленно). */
    var returnHand: Int
        get() = sp.getInt("rhand", 1)
        set(v) {
            sp.edit().putInt("rhand", if (v > 0) 1 else 0).apply()
        }

    /** Проверять посев и сбор по виду грядок. */
    var verify: Boolean
        get() = sp.getBoolean("vfy", true)
        set(v) {
            sp.edit().putBoolean("vfy", v).apply()
        }

    /** Умный режим: чтение силоса, состояние слотов лавки по картинке, значок «!», ранний сбор. */
    var smart: Boolean
        get() = sp.getBoolean("smart", true)
        set(v) {
            sp.edit().putBoolean("smart", v).apply()
        }

    /** Образцы цвета грядок в точках проб. kind: e — пустая, p — засеянная, r — спелая. */
    private fun smpKey(kind: String, f: Int) = "smp_" + kind + (if (f > 0) "#$f" else "")

    fun getSmp(kind: String, f: Int = cur): IntArray? {
        val s = sp.getString(smpKey(kind, f), null) ?: return null
        val a = s.split(",").mapNotNull { it.trim().toIntOrNull() }
        return if (a.isEmpty()) null else a.toIntArray()
    }

    fun setSmp(kind: String, f: Int, v: IntArray?) {
        val e = sp.edit()
        if (v == null || v.isEmpty()) e.remove(smpKey(kind, f)) else e.putString(smpKey(kind, f), v.joinToString(","))
        e.apply()
    }

    /** Отступ от краёв экрана в процентах: палец с культурой не заходит в эту зону, чтобы игра не двигала карту. */
    var edgePct: Int
        get() = sp.getInt("edge", 12)
        set(v) {
            sp.edit().putInt("edge", v.coerceIn(0, 25)).apply()
        }

    /** Скорость в процентах: больше — быстрее (палец и паузы). */
    var speedPlant: Int
        get() = sp.getInt("spp", 500)
        set(v) {
            sp.edit().putInt("spp", v.coerceIn(50, 600)).apply()
        }

    var speedHarvest: Int
        get() = sp.getInt("sph", 500)
        set(v) {
            sp.edit().putInt("sph", v.coerceIn(50, 600)).apply()
        }

    var speedShop: Int
        get() = sp.getInt("sps", 200)
        set(v) {
            sp.edit().putInt("sps", v.coerceIn(50, 400)).apply()
        }

    /** Маленькая картинка иконки пшеницы (24x24), по ней бот находит пшеницу в списке товаров. */
    fun setWheatPatch(a: IntArray) {
        sp.edit().putString("wpat", a.joinToString(",")).apply()
    }

    fun getWheatPatch(): IntArray? {
        val s = sp.getString("wpat", "") ?: ""
        if (s.isBlank()) return null
        return try {
            s.split(",").map { it.toInt() }.toIntArray()
        } catch (_: Exception) {
            null
        }
    }

    /** Сколько миллисекунд прижимать пустую землю после посева. */
    var groundMs: Int
        get() = sp.getInt("gms", 1000)
        set(v) {
            sp.edit().putInt("gms", if (v < 600) 0 else v.coerceAtMost(4000)).apply()
        }

    // расчёт заполнения амбара
    fun cellsOf(f: Int = cur): Int = sp.getInt(if (f > 0) "cells#$f" else "cells", 0)

    fun setCells(f: Int, v: Int) {
        sp.edit().putInt(if (f > 0) "cells#$f" else "cells", v.coerceAtLeast(0)).apply()
    }
    var perCell: Int
        get() = sp.getInt("pcell", 2)
        set(v) {
            sp.edit().putInt("pcell", v.coerceAtLeast(1)).apply()
        }
    var barnCap: Int
        get() = sp.getInt("bcap", 0)
        set(v) {
            sp.edit().putInt("bcap", v.coerceAtLeast(0)).apply()
        }
    var barnUsed: Int
        get() = sp.getInt("bused", 0)
        set(v) {
            sp.edit().putInt("bused", v.coerceAtLeast(0)).apply()
        }
    var perSlot: Int
        get() = sp.getInt("pslot", 10)
        set(v) {
            sp.edit().putInt("pslot", v.coerceAtLeast(1)).apply()
        }

    /** Длина свайпа бота при листании лавки, пикселей. */
    var swipeLen: Int
        get() = sp.getInt("swlen", 1000)
        set(v) {
            sp.edit().putInt("swlen", v.coerceIn(300, 1800)).apply()
        }

    /** Неоновый радужный след на каждом нажатии и свайпе бота. */
    var trail: Boolean
        get() = sp.getBoolean("trail", true)
        set(v) {
            sp.edit().putBoolean("trail", v).apply()
        }

    var fieldCount: Int
        get() = sp.getInt("fcount", 1).coerceIn(1, MAXF)
        set(v) {
            sp.edit().putInt("fcount", v.coerceIn(1, MAXF)).apply()
        }

    /** Время созревания в секундах для поля f. */
    fun grow(f: Int = cur): Int = sp.getInt(if (f > 0) "grow#$f" else "grow", 121)

    fun setGrow(v: Int, f: Int = cur) {
        sp.edit().putInt(if (f > 0) "grow#$f" else "grow", v.coerceIn(20, 3600)).apply()
    }

    // ---------- эталоны цвета ----------

    fun getRef(t: T, f: Int = cur): Int? {
        val k = "ref_" + key(t, f)
        return if (sp.contains(k)) sp.getInt(k, 0) else null
    }

    fun setRef(t: T, c: Int, f: Int = cur) {
        sp.edit().putInt("ref_" + key(t, f), c).apply()
    }

    // ---------- точки ----------

    private fun mlist(t: T, f: Int): MutableList<P> = pts.getOrPut(key(t, f)) { mutableListOf() }

    fun list(t: T, f: Int = cur): List<P> = mlist(t, f)
    fun first(t: T, f: Int = cur): P? = mlist(t, f).firstOrNull()

    fun add(t: T, p: P) {
        val l = mlist(t, cur)
        if (!t.multi) l.clear()
        l.add(p)
        save()
    }

    fun clear(t: T) {
        mlist(t, cur).clear()
        save()
        sp.edit().remove("ref_" + key(t, cur)).apply()
        if (t == T.ITEM) sp.edit().remove("wpat").apply()
    }

    fun removeLast(t: T) {
        val l = mlist(t, cur)
        if (l.isNotEmpty()) {
            l.removeAt(l.size - 1)
            save()
        }
    }

    fun truncate(t: T, keep: Int) {
        val l = mlist(t, cur)
        while (l.size > keep) l.removeAt(l.size - 1)
        save()
    }

    /** Маршрут пальца по полю f: змейка внутри выделенной области. */
    fun path(f: Int = cur): List<P> = Geo.zigzag(list(T.AREA, f), rowGap.toFloat())

    /** Маршрут, который начинается рядом с выбранной грядкой и расходится от неё. */
    fun pathFrom(near: P, f: Int = cur): List<P> = Geo.zigzagFrom(list(T.AREA, f), rowGap.toFloat(), near)

    /** Первое поле и роль, которым не хватает точек, либо null если всё готово к запуску. */
    fun missingPair(): Pair<Int, T>? {
        for (f in 0 until fieldCount) {
            for (t in listOf(T.FIELD, T.WHEAT, T.AREA, T.HFIELD, T.SICKLE)) {
                if (list(t, f).size < t.min) return Pair(f, t)
            }
        }
        if (first(T.SHOP, 0) != null) {
            for (t in listOf(T.SLOT, T.ITEM, T.PUT, T.CLOSE)) {
                if (list(t, 0).size < t.min) return Pair(0, t)
            }
        }
        return null
    }

    fun missing(): T? = missingPair()?.second

    /** Убирает последнее добавленное поле (кроме первого). */
    fun removeField() {
        val last = fieldCount - 1
        if (last < 1) return
        val e = sp.edit()
        for (t in T.values()) {
            if (!t.perField) continue
            mlist(t, last).clear()
            e.remove("ref_" + key(t, last))
        }
        e.remove("grow#$last")
        e.remove("cells#$last")
        e.apply()
        save()
        fieldCount = last
        if (cur >= last) cur = last - 1
    }

    // ---------- свои задачи (макросы) ----------

    fun macroCount(): Int = sp.getInt("mcount", 0).coerceIn(0, MAXM)

    fun macroTaps(m: Int): List<MTap> {
        val s = sp.getString("mac$m", "") ?: ""
        if (s.isBlank()) return emptyList()
        return s.split(";").mapNotNull {
            val a = it.split(",")
            val x = a.getOrNull(0)?.toFloatOrNull()
            val y = a.getOrNull(1)?.toFloatOrNull()
            val d = a.getOrNull(2)?.toLongOrNull()
            if (a.size == 3 && x != null && y != null && d != null && d >= 0) MTap(P(x, y), d) else null
        }
    }

    /** Сохраняет новую задачу, возвращает её номер или -1 если места нет. */
    fun saveMacro(taps: List<MTap>): Int {
        val n = macroCount()
        if (n >= MAXM) return -1
        sp.edit()
            .putString("mac$n", taps.joinToString(";") { "${it.p.x},${it.p.y},${it.dtMs}" })
            .putInt("mint$n", 10)
            .putInt("mcount", n + 1)
            .apply()
        return n
    }

    /** Интервал запуска в минутах, 0 — задача выключена. */
    fun macroInterval(m: Int): Int = sp.getInt("mint$m", 10)

    fun setMacroInterval(m: Int, v: Int) {
        sp.edit().putInt("mint$m", v.coerceIn(0, 720)).apply()
    }

    fun deleteMacro(m: Int) {
        val n = macroCount()
        if (m < 0 || m >= n) return
        val e = sp.edit()
        for (i in m until n - 1) {
            e.putString("mac$i", sp.getString("mac${i + 1}", "") ?: "")
            e.putInt("mint$i", sp.getInt("mint${i + 1}", 10))
        }
        e.remove("mac${n - 1}")
        e.remove("mint${n - 1}")
        e.putInt("mcount", n - 1)
        e.apply()
    }

    // ---------- профили и экспорт ----------

    fun exportJson(): String {
        val o = JSONObject()
        o.put("v", 2)
        o.put("every", sellEvery)
        o.put("gap", rowGap)
        o.put("rec", useRec)
        o.put("hold", holdMs)
        o.put("pmode", plantMode)
        o.put("fcount", fieldCount)
        o.put("spages", shopPages)
        o.put("rhand", returnHand)
        o.put("edge", edgePct)
        o.put("spp", speedPlant)
        o.put("sph", speedHarvest)
        o.put("sps", speedShop)
        o.put("wpat", sp.getString("wpat", "") ?: "")
        o.put("swms", swipeMs)
        o.put("dact", delayAct)
        o.put("dshop", delayShop)
        o.put("acount", autoCount)
        o.put("sfull", sellOnFull)
        o.put("adon", adOn)
        o.put("gms", groundMs)
        o.put("ggap", groundGap)
        val g = JSONObject()
        for (f in 0 until MAXF) g.put("g$f", grow(f))
        o.put("grow", g)
        val p = JSONObject()
        for ((k, l) in pts) p.put(k, enc(l))
        o.put("pts", p)
        val r = JSONObject()
        for (f in 0 until MAXF) {
            for (t in T.values()) {
                if (f > 0 && !t.perField) continue
                val ref = getRef(t, f)
                if (ref != null) r.put(key(t, f), ref)
            }
        }
        o.put("ref", r)
        o.put("vfy", verify)
        o.put("smart", smart)
        val sm = JSONObject()
        for ((k, v) in sp.all) if (k.startsWith("smp_") && v is String) sm.put(k, v)
        o.put("smp", sm)
        val m = JSONArray()
        for (i in 0 until macroCount()) {
            val mo = JSONObject()
            mo.put("taps", sp.getString("mac$i", "") ?: "")
            mo.put("int", macroInterval(i))
            m.put(mo)
        }
        o.put("mac", m)
        return o.toString()
    }

    fun importJson(s: String): Boolean {
        try {
            val o = JSONObject(s.trim())
            val p = o.optJSONObject("pts") ?: return false
            val r = o.optJSONObject("ref")
            val e = sp.edit()
            e.putInt("every", o.optInt("every", 3).coerceIn(1, 9))
            e.putInt("gap", o.optInt("gap", 45).coerceIn(15, 150))
            e.putBoolean("rec", o.optBoolean("rec", true))
            e.putInt("hold", o.optInt("hold", 600).coerceIn(100, 2000))
            e.putInt("pmode", o.optInt("pmode", DEFAULT_PMODE))
            e.putInt("fcount", o.optInt("fcount", 1).coerceIn(1, MAXF))
            e.putInt("spages", o.optInt("spages", 1).coerceIn(1, 6))
            e.putInt("rhand", o.optInt("rhand", 1))
            e.putInt("edge", o.optInt("edge", 12).coerceIn(0, 25))
            e.putInt("spp", o.optInt("spp", 500).coerceIn(50, 600))
            e.putInt("sph", o.optInt("sph", 500).coerceIn(50, 600))
            e.putInt("sps", o.optInt("sps", 200).coerceIn(50, 400))
            e.putString("wpat", o.optString("wpat", ""))
            e.putInt("swms", o.optInt("swms", 700).coerceIn(400, 2000))
            e.putInt("dact", o.optInt("dact", 0).coerceIn(0, 10000))
            e.putInt("ggap", o.optInt("ggap", 80).coerceIn(0, 3000))
            e.putInt("dshop", o.optInt("dshop", 0).coerceIn(0, 10000))
            e.putBoolean("acount", o.optBoolean("acount", true))
            e.putBoolean("sfull", o.optBoolean("sfull", true))
            e.putBoolean("adon", o.optBoolean("adon", true))
            e.putInt("gms", o.optInt("gms", 1000).let { if (it < 600) 0 else it.coerceAtMost(4000) })
            val g = o.optJSONObject("grow")
            for (f in 0 until MAXF) {
                val v = if (g != null) g.optInt("g$f", 121) else (if (f == 0) o.optInt("grow", 121) else 121)
                e.putInt(if (f > 0) "grow#$f" else "grow", v.coerceIn(20, 3600))
            }
            for (f in 0 until MAXF) {
                for (t in T.values()) {
                    if (f > 0 && !t.perField) continue
                    val k = key(t, f)
                    e.putString(k, p.optString(k, ""))
                    if (r != null && r.has(k)) e.putInt("ref_$k", r.getInt(k)) else e.remove("ref_$k")
                }
            }
            for (i in 0 until MAXM) {
                e.remove("mac$i")
                e.remove("mint$i")
            }
            val m = o.optJSONArray("mac")
            var cnt = 0
            if (m != null) {
                for (i in 0 until minOf(m.length(), MAXM)) {
                    val mo = m.getJSONObject(i)
                    e.putString("mac$i", mo.optString("taps", ""))
                    e.putInt("mint$i", mo.optInt("int", 10))
                    cnt++
                }
            }
            e.putInt("mcount", cnt)
            e.putBoolean("vfy", o.optBoolean("vfy", true))
            e.putBoolean("smart", o.optBoolean("smart", true))
            for (k in sp.all.keys) if (k.startsWith("smp_")) e.remove(k)
            val sm = o.optJSONObject("smp")
            if (sm != null) {
                val it = sm.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    if (k.startsWith("smp_")) e.putString(k, sm.optString(k, ""))
                }
            }
            e.putInt("rev", sp.getInt("rev", 0) + 1)
            e.apply()
            reload()
            return true
        } catch (_: Exception) {
            return false
        }
    }

    private val meta = ctx.getSharedPreferences("profmeta", Context.MODE_PRIVATE)

    fun profileNames(): List<String> = prof.all.keys.sortedByDescending { meta.getLong("t_$it", 0L) }

    fun profileTime(name: String): Long = meta.getLong("t_$name", 0L)

    var activeProfile: String
        get() = meta.getString("active", "") ?: ""
        set(v) {
            meta.edit().putString("active", v).apply()
        }

    fun saveProfile(name: String) {
        prof.edit().putString(name, exportJson()).apply()
        meta.edit().putLong("t_$name", System.currentTimeMillis()).apply()
        activeProfile = name
    }

    fun deleteProfile(name: String) {
        prof.edit().remove(name).apply()
        meta.edit().remove("t_$name").apply()
        if (activeProfile == name) activeProfile = ""
    }

    fun deleteAllProfiles() {
        prof.edit().clear().apply()
        meta.edit().clear().apply()
    }

    fun renameProfile(old: String, new: String): Boolean {
        val n = new.trim()
        if (n.isEmpty() || n == old || prof.contains(n)) return false
        val js = prof.getString(old, null) ?: return false
        prof.edit().remove(old).putString(n, js).apply()
        meta.edit().remove("t_$old").putLong("t_$n", profileTime(old).takeIf { it > 0 } ?: System.currentTimeMillis()).apply()
        if (activeProfile == old) activeProfile = n
        return true
    }

    fun profileJson(name: String): String? = prof.getString(name, null)

    fun loadProfile(name: String): Boolean {
        val s = prof.getString(name, null) ?: return false
        val ok = importJson(s)
        if (ok) activeProfile = name
        return ok
    }

    /** Сброс числовых настроек к стандартным. Поля, точки и профили не трогает. */
    fun resetDefaults() {
        val e = sp.edit()
        for (k in listOf("every", "gap", "rec", "hold", "pmode", "spages", "rhand", "edge", "spp", "sph", "sps",
            "swms", "gms", "ggap", "dact", "dshop", "acount", "sfull", "adon", "trail", "vfy", "smart")) e.remove(k)
        e.putInt("rev", sp.getInt("rev", 0) + 1)
        e.apply()
        reload()
    }

    /** Текст всех настроек для отладки: где что отмечено. */
    fun dump(): String {
        val sb = StringBuilder()
        fun pts(l: List<P>) = l.joinToString(" ") { "(" + it.x.toInt() + "," + it.y.toInt() + ")" }
        sb.append("полей=").append(fieldCount).append(" режим=").append(plantMode).append(" шаг_строк=").append(rowGap)
            .append(" удержание=").append(holdMs).append(" край=").append(edgePct).append("%\n")
        sb.append("скорость посев/сбор/лавка=").append(speedPlant).append("/").append(speedHarvest).append("/").append(speedShop)
            .append("% земля=").append(groundMs).append("мс возврат=").append(returnHand)
            .append(" распознавание=").append(useRec)
            .append(" проверка=").append(verify).append(" умный=").append(smart).append("\n")
        sb.append("силос ").append(barnUsed).append("/").append(barnCap).append(" клеток=").append(cellsOf(0))
            .append(" x").append(perCell).append(" в_слоте=").append(perSlot).append(" продажа_каждые=").append(sellEvery)
            .append(" страниц=").append(shopPages).append(" свайп_лавки=").append(swipeLen).append("px\n")
        for (f in 0 until fieldCount) {
            sb.append("Поле ").append(f + 1).append(" созревание=").append(grow(f)).append("с клеток=").append(cellsOf(f)).append("\n")
            for (t in T.values()) if (t.perField) sb.append("  ").append(t.name).append(" ").append(pts(list(t, f))).append("\n")
            for ((kind, nm) in listOf("e" to "пустая", "p" to "засеянная", "r" to "спелая")) {
                val s = getSmp(kind, f)
                sb.append("  образец ").append(nm).append(": ")
                    .append(s?.joinToString(" ") { String.format("%06X", it and 0xFFFFFF) } ?: "нет").append("\n")
            }
        }
        for (t in T.values()) if (!t.perField) sb.append(t.name).append(" ").append(pts(list(t, 0))).append("\n")
        return sb.toString()
    }

    private fun save() {
        val e = sp.edit()
        for ((k, l) in pts) e.putString(k, enc(l))
        e.apply()
    }

    private fun enc(l: List<P>) = l.joinToString(";") { "${it.x},${it.y}" }

    private fun dec(s: String?): MutableList<P> {
        if (s.isNullOrBlank()) return mutableListOf()
        return s.split(";").mapNotNull {
            val a = it.split(",")
            val x = a.getOrNull(0)?.toFloatOrNull()
            val y = a.getOrNull(1)?.toFloatOrNull()
            if (a.size == 2 && x != null && y != null) P(x, y) else null
        }.toMutableList()
    }
}
