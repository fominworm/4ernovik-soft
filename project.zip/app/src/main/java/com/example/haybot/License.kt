package com.example.haybot

import android.content.Context
import android.provider.Settings
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Настройки лицензирования. Когда появится сервер или бот в Telegram, заполни адреса и включи ENFORCE. */
object LicenseConfig {
    const val ENFORCE = false                       // true: без активного ключа бот не запускается
    const val BOT_URL = "https://t.me/flomaster6"   // позже здесь будет ссылка на бота, который выдаёт ключи
    const val SUPPORT_URL = "https://t.me/flomaster6"
    const val FUNPAY_URL = ""                       // ссылка на лот или профиль FunPay
    const val CHANNEL_URL = ""                      // канал с обновлениями
    const val GUIDE_URL = ""                        // инструкция
    const val ACTIVATION_URL = ""                   // адрес сервера проверки ключей (пока пусто)
    const val PUBLIC_KEY_B64 = ""                   // публичный RSA-ключ (X.509, base64) для проверки подписи сервера
}

enum class LicState { NONE, PENDING, ACTIVE, EXPIRED, INVALID }

class LicInfo(val state: LicState, val key: String, val expiresAt: Long, val msg: String)

object License {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("license", Context.MODE_PRIVATE)

    fun key(ctx: Context): String = sp(ctx).getString("key", "") ?: ""

    /** Короткий отпечаток устройства: ключ привязывается к нему. */
    fun deviceId(ctx: Context): String {
        val raw = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val h = MessageDigest.getInstance("SHA-256").digest(("ttb:" + raw).toByteArray())
        return h.take(8).joinToString("") { "%02x".format(it) }
    }

    private const val ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   // без I и O

    /** Контрольный символ: ловит опечатки до обращения к серверу. Тот же алгоритм в keygen.py. */
    fun checksum(body: String): Char {
        var sum = 0
        for ((i, ch) in body.withIndex()) {
            val v = ALPHA.indexOf(ch)
            if (v < 0) return '?'
            sum += (i + 1) * v
        }
        return ALPHA[sum % 32]
    }

    fun formatOk(k: String): Boolean {
        if (!Regex("^TTB(-[A-HJ-NP-Z2-9]{4}){4}$").matches(k)) return false
        val body = k.removePrefix("TTB-").replace("-", "")
        return checksum(body.dropLast(1)) == body.last()
    }

    fun clear(ctx: Context) {
        sp(ctx).edit().clear().apply()
    }

    fun info(ctx: Context): LicInfo {
        val s = sp(ctx)
        val k = s.getString("key", "") ?: ""
        if (k.isEmpty()) return LicInfo(LicState.NONE, "", 0L, "Ключ не активирован")
        val exp = s.getLong("exp", 0L)
        val dev = s.getString("dev", "") ?: ""
        if (exp == 0L) return LicInfo(LicState.PENDING, k, 0L, s.getString("msg", "Ключ сохранён, ждёт проверки") ?: "")
        if (dev.isNotEmpty() && dev != deviceId(ctx)) return LicInfo(LicState.INVALID, k, exp, "Ключ привязан к другому устройству")
        return if (System.currentTimeMillis() > exp) {
            LicInfo(LicState.EXPIRED, k, exp, "Срок действия истёк")
        } else {
            LicInfo(LicState.ACTIVE, k, exp, "Ключ активен")
        }
    }

    fun isValid(ctx: Context): Boolean = info(ctx).state == LicState.ACTIVE

    fun left(ms: Long): String {
        val m = ms / 60000
        val d = m / 1440
        val h = (m % 1440) / 60
        val mm = m % 60
        return if (d > 0) "$d д $h ч" else if (h > 0) "$h ч $mm мин" else "$mm мин"
    }

    fun expiresText(ms: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(ms))

    fun shortStatus(ctx: Context): String {
        val i = info(ctx)
        return when (i.state) {
            LicState.NONE -> "ключ не активирован"
            LicState.PENDING -> "ключ ждёт проверки"
            LicState.EXPIRED -> "срок истёк"
            LicState.INVALID -> i.msg.lowercase()
            LicState.ACTIVE -> "осталось " + left(i.expiresAt - System.currentTimeMillis())
        }
    }

    /** Проверяет подпись ответа сервера публичным ключом из приложения. Без ключа всегда false. */
    fun verify(payload: String, sigB64: String): Boolean {
        if (LicenseConfig.PUBLIC_KEY_B64.isEmpty()) return false
        return try {
            val pub = KeyFactory.getInstance("RSA")
                .generatePublic(X509EncodedKeySpec(Base64.decode(LicenseConfig.PUBLIC_KEY_B64, Base64.DEFAULT)))
            val sg = Signature.getInstance("SHA256withRSA")
            sg.initVerify(pub)
            sg.update(payload.toByteArray())
            sg.verify(Base64.decode(sigB64, Base64.DEFAULT))
        } catch (_: Exception) {
            false
        }
    }

    /** Активация. Пока сервер не подключён, ключ только сохраняется. Колбэк вызывается не в главном потоке. */
    fun activate(ctx: Context, raw: String, done: (LicInfo) -> Unit) {
        val k = raw.trim().uppercase()
        if (!formatOk(k)) {
            done(LicInfo(LicState.INVALID, k, 0L, "Ключ введён неверно. Проверь символы: в ключах нет букв I, O и цифр 0, 1"))
            return
        }
        sp(ctx).edit().putString("key", k).remove("exp").remove("dev").apply()
        if (LicenseConfig.ACTIVATION_URL.isEmpty()) {
            sp(ctx).edit().putString("msg", "Сервер активации ещё не подключён: ключ сохранён и будет проверен позже").apply()
            done(info(ctx))
            return
        }
        Thread {
            val res = try {
                requestServer(ctx, k)
            } catch (e: Exception) {
                LicInfo(LicState.PENDING, k, 0L, "Нет связи с сервером: " + (e.message ?: ""))
            }
            done(res)
        }.start()
    }

    private fun requestServer(ctx: Context, k: String): LicInfo {
        val c = URL(LicenseConfig.ACTIVATION_URL).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        val body = JSONObject().put("key", k).put("device", deviceId(ctx)).toString()
        c.outputStream.use { it.write(body.toByteArray()) }
        val text = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        val o = JSONObject(text)
        if (!o.optBoolean("ok", false)) return LicInfo(LicState.INVALID, k, 0L, o.optString("error", "Ключ отклонён сервером"))
        val payload = o.optString("payload", "")
        if (!verify(payload, o.optString("sig", ""))) return LicInfo(LicState.INVALID, k, 0L, "Подпись ответа не прошла проверку")
        val p = JSONObject(payload)
        if (p.optString("device") != deviceId(ctx) || p.optString("key") != k) {
            return LicInfo(LicState.INVALID, k, 0L, "Ответ сервера не для этого ключа или устройства")
        }
        sp(ctx).edit().putLong("exp", p.getLong("exp")).putString("dev", p.optString("device")).apply()
        return info(ctx)
    }
}
