package com.example.haybot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Распознавание по картинке. Слоты лавки распознаются по размеру самих слотов, значок «!» пересчитывается по ширине снимка. */
object Vision {
    const val S_UNK = 0
    const val S_EMPTY = 1
    const val S_SOLD = 2
    const val S_LOT = 3

    // Шаблоны слотов лавки: сетка 6x5 средних цветов по верхней части слота (щит с петухом и печать «ПРОДАНО»).
    // Размер окна задаётся шагом между слотами, а не пикселями: работает при любом разрешении и пропорциях экрана.
    private const val GX = 6
    private const val GY = 5
    private const val WX0 = -0.34f
    private const val WX1 = 0.34f
    private const val WY0 = -0.42f
    private const val WY1 = 0.10f

    private val TPL_SOLD = intArrayOf(
        0x997734,0xBCAB7F,0xD0CEC2,0x8C8364,0xC9AE66,0xD2A645,
        0xBC9747,0xD9C883,0xFFF9BC,0xD8B15C,0xFDF2AE,0xE4BA57,
        0xE3B143,0xF3D97E,0xE6C572,0xD19F3E,0xFCEFA7,0xE5B94B,
        0xE7B641,0xF0CB5E,0xECCC72,0xD6A546,0xF3D371,0xE7BB44,
        0xE3AE3D,0xCF9B35,0xD8A735,0xD8A73C,0xD59F2B,0xDCA63A
    )

    private val TPL_EMPTY = intArrayOf(
        0xD49337,0xD99A34,0xDDA532,0xDDA733,0xD99A33,0xD39035,
        0xDCA23A,0xDAA931,0xE2B83C,0xE0B537,0xE0B03C,0xDBA33A,
        0xE6B13D,0xEAC33B,0xEED443,0xEDD23D,0xEBC540,0xE5B03E,
        0xE3B340,0xDAB93E,0xE6D248,0xEFDD43,0xD7B73E,0xE1B03E,
        0xE6B33E,0xD3AD3B,0xD9BF41,0xC9AC39,0xD6B137,0xD09F3A
    )

    /** Расстояния последнего распознанного слота до шаблонов (для журнала): [проданный, пустой]. */
    val lastDist = FloatArray(2)

    private fun px(b: Bitmap, x: Int, y: Int): Int = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))

    private fun cdist(r: Int, g: Int, bl: Int, t: Int): Float {
        val dr = (r - Color.red(t)).toFloat()
        val dg = (g - Color.green(t)).toFloat()
        val db = (bl - Color.blue(t)).toFloat()
        return sqrt(dr * dr + dg * dg + db * db)
    }

    /** Среднее расстояние окна слота с центром (cx, cy) и шагом (pw, ph) до шаблона. which: 0 — проданный, 1 — пустой. */
    private fun winDist(b: Bitmap, cx: Float, cy: Float, pw: Float, ph: Float, which: Int): Float {
        val tpl = if (which == 0) TPL_SOLD else TPL_EMPTY
        var sum = 0f
        for (j in 0 until GY) {
            for (i in 0 until GX) {
                var r = 0
                var g = 0
                var bl = 0
                for (sj in 0..2) {
                    for (si in 0..2) {
                        val x = (cx + (WX0 + (i + (si + 0.5f) / 3f) / GX * (WX1 - WX0)) * pw).toInt()
                        val y = (cy + (WY0 + (j + (sj + 0.5f) / 3f) / GY * (WY1 - WY0)) * ph).toInt()
                        val c = px(b, x, y)
                        r += Color.red(c)
                        g += Color.green(c)
                        bl += Color.blue(c)
                    }
                }
                sum += cdist(r / 9, g / 9, bl / 9, tpl[j * GX + i])
            }
        }
        return sum / (GX * GY)
    }

    /** Лучшее совпадение с шаблоном при сдвиге окна (±0.3 шага, затем уточнение) и небольшом изменении масштаба. */
    private fun bestDist(b: Bitmap, cx: Int, cy: Int, pw: Float, ph: Float, which: Int): Float {
        var best = 1e9f
        for (f in floatArrayOf(0.88f, 1f, 1.12f)) {
            val w = pw * f
            val h = ph * f
            var bd = 1e9f
            var bx = 0f
            var by = 0f
            for (oi in -3..3) {
                for (oj in -3..3) {
                    val d = winDist(b, cx + oi * 0.1f * w, cy + oj * 0.1f * h, w, h, which)
                    if (d < bd) {
                        bd = d
                        bx = oi * 0.1f
                        by = oj * 0.1f
                    }
                }
            }
            for (oi in -1..1) {
                for (oj in -1..1) {
                    if (oi == 0 && oj == 0) continue
                    val d = winDist(b, cx + (bx + oi * 0.05f) * w, cy + (by + oj * 0.05f) * h, w, h, which)
                    if (d < bd) bd = d
                }
            }
            if (bd < best) best = bd
        }
        return best
    }

    /**
     * Шаг между соседними слотами по их центрам: [по горизонтали, по вертикали]. height — высота экрана для запасного значения.
     * В Hay Day внешний вид слотов одинаков, меняется только масштаб, поэтому размер берём из расстановки точек.
     */
    fun pitch(xs: FloatArray, ys: FloatArray, height: Float): FloatArray {
        var px = Float.MAX_VALUE
        var py = Float.MAX_VALUE
        for (i in xs.indices) {
            for (j in i + 1 until xs.size) {
                val dx = kotlin.math.abs(xs[i] - xs[j])
                val dy = kotlin.math.abs(ys[i] - ys[j])
                if (dx > 40f && dy < dx * 0.35f) px = min(px, dx)
                if (dy > 40f && dx < dy * 0.35f) py = min(py, dy)
            }
        }
        if (px < 0.15f * height || px > 0.42f * height) px = 0.264f * height
        if (py < 0.17f * height || py > 0.45f * height) py = 0.287f * height
        return floatArrayOf(px, py)
    }

    /** Состояние слота лавки с центром нажатия (cx, cy) и шагом слотов (pw, ph), всё в пикселях снимка. */
    fun slotState(b: Bitmap, cx: Int, cy: Int, pw: Float, ph: Float): Int {
        val ds = bestDist(b, cx, cy, pw, ph, 0)
        val de = if (ds < 22f) 99f else bestDist(b, cx, cy, pw, ph, 1)
        lastDist[0] = ds
        lastDist[1] = de
        return when {
            ds < 36f && ds < de - 10f -> S_SOLD
            de < 36f && de < ds - 10f -> S_EMPTY
            else -> S_LOT
        }
    }

    /** Есть ли над лавкой значок «!» (кремовая плашка). cx, cy — точка лавки в пикселях снимка. */
    fun badge(b: Bitmap, cx: Int, cy: Int): Boolean {
        val r = (200 * b.width / 2400f).toInt()
        return badgeIn(b, cx - r, cy - r, cx + r, cy + r)
    }

    /** То же по рамке (в пикселях снимка). */
    fun badgeIn(b: Bitmap, x0: Int, y0: Int, x1: Int, y1: Int): Boolean {
        val k = b.width / 2400f
        var n = 0
        var y = max(0, y0)
        while (y < min(b.height, y1)) {
            var x = max(0, x0)
            while (x < min(b.width, x1)) {
                val c = b.getPixel(x, y)
                val rr = Color.red(c)
                val gg = Color.green(c)
                val bb = Color.blue(c)
                if (rr > 245 && gg > 235 && bb in 150..215) n++
                x += 2
            }
            y += 2
        }
        return n >= max(20, (100 * k * k).toInt())
    }

    /** Красный крестик окна силоса: цвет в его центре. */
    fun redCross(c: Int): Boolean = Color.red(c) > 170 && Color.green(c) < 110 && Color.blue(c) < 110
}
