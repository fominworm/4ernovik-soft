package com.example.haybot

import android.content.Context

data class P(val x: Float, val y: Float)

enum class T(val title: String, val multi: Boolean) {
    FIELD("1 Поле: центр грядок", false),
    WHEAT("2 Иконка пшеницы в меню", false),
    SICKLE("3 Иконка серпа (у спелого поля)", false),
    PATH("4 Путь по грядкам (точки)", true),
    SELL("5 Тапы продажи по порядку", true)
}

class Cfg(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private val pts = HashMap<T, MutableList<P>>()

    init {
        for (t in T.values()) pts[t] = dec(sp.getString(t.name, null))
    }

    fun add(t: T, p: P) {
        val l = pts[t]!!
        if (!t.multi) l.clear()
        l.add(p)
        save()
    }

    fun clear(t: T) {
        pts[t]!!.clear()
        save()
    }

    fun list(t: T): List<P> = pts[t]!!
    fun first(t: T): P? = pts[t]!!.firstOrNull()

    private fun save() {
        val e = sp.edit()
        for ((t, l) in pts) e.putString(t.name, l.joinToString(";") { "${it.x},${it.y}" })
        e.apply()
    }

    private fun dec(s: String?): MutableList<P> {
        if (s.isNullOrBlank()) return mutableListOf()
        return s.split(";").mapNotNull {
            val a = it.split(",")
            if (a.size == 2) P(a[0].toFloat(), a[1].toFloat()) else null
        }.toMutableList()
    }
}
