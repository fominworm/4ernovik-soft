package com.example.haybot

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit

/** Чтение текста с картинки (ML Kit, модель внутри приложения). Вызывать не с главного потока. */
object Ocr {
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    fun read(bmp: Bitmap): String? = try {
        Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)), 8, TimeUnit.SECONDS).text
    } catch (e: Exception) {
        null
    }
}
