package com.example.haybot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

/**
 * Слой на весь экран. Когда armed=true — ловит одно нажатие (onTap сработает при отпускании пальца)
 * и рисует записанные точки. Когда armed=false — окно прозрачно для касаний (задаётся флагами окна).
 */
class MarkView(ctx: Context, private val cfg: Cfg) : View(ctx) {
    var armed = false
    var showAll = false
    var onTap: ((Float, Float) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var down = false
    private var dx = 0f
    private var dy = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!armed) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                dx = e.rawX
                dy = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                if (down) {
                    down = false
                    onTap?.invoke(dx, dy)
                }
            }
            MotionEvent.ACTION_CANCEL -> down = false
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        if (!armed && !showAll) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        if (armed) c.drawColor(0x30FFEB3B)

        val path = cfg.list(T.PATH)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = T.PATH.color
        for (i in 1 until path.size) {
            c.drawLine(path[i - 1].x - ox, path[i - 1].y - oy, path[i].x - ox, path[i].y - oy, p)
        }

        p.style = Paint.Style.FILL
        for (t in T.values()) {
            for ((i, pt) in cfg.list(t).withIndex()) {
                p.color = t.color
                c.drawCircle(pt.x - ox, pt.y - oy, 20f, p)
                p.color = Color.WHITE
                p.textSize = 30f
                p.textAlign = Paint.Align.LEFT
                val label = t.icon + (if (t.multi) (i + 1).toString() else "")
                c.drawText(label, pt.x - ox + 24f, pt.y - oy + 10f, p)
            }
        }
    }
}
