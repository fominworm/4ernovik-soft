package com.example.haybot

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Switch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var stats: Stats
    private lateinit var content: LinearLayout
    private val backStack = ArrayList<String>()
    private var screen = "home"

    private lateinit var nameEt: EditText
    private lateinit var importEt: EditText
    private lateinit var keyEt: EditText

    private val cBg1 = 0xFF0B1020.toInt()
    private val cBg2 = 0xFF1A1245.toInt()
    private val cCard = 0xCC0E1236.toInt()
    private val cLine = 0xFF3D6BFF.toInt()
    private val cText = 0xFFEAF0FF.toInt()
    private val cMuted = 0xFF9AA6C7.toInt()
    private val cAccent = 0xFF7C5CFF.toInt()
    private val cBlue = 0xFF4F8CFF.toInt()
    private val cGreen = 0xFF2ECC71.toInt()
    private val cRed = 0xFFFF5C7A.toInt()

    private val tgUrl = LicenseConfig.SUPPORT_URL
    private val gamePkg = "com.supercell.hayday"

    // ---------- каркас ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        stats = Stats(this)
        window.statusBarColor = cBg1
        val frame = FrameLayout(this)
        frame.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(cBg1, cBg2, cBg1))
        val bgIv = ImageView(this)
        bgIv.setImageResource(R.drawable.bg)
        bgIv.scaleType = ImageView.ScaleType.CENTER_CROP
        frame.addView(bgIv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18), dp(30), dp(18), dp(30))
        scroll.addView(content)
        frame.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(frame)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        content.removeAllViews()
        if (welcome) {
            welcomeScreen()
            return
        }
        when (screen) {
            "settings" -> settingsScreen()
            "speed" -> speedScreen()
            "storage" -> storageScreen()
            "shop" -> shopScreen()
            "configs" -> configsScreen()
            "stats" -> statsScreen()
            "log" -> logScreen()
            "tasks" -> tasksScreen()
            "key" -> keyScreen()
            "help" -> helpScreen()
            "guide" -> guideScreen()
            else -> homeScreen()
        }
    }

    private fun go(s: String) {
        backStack.add(screen)
        screen = s
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (backStack.isNotEmpty()) {
            screen = backStack.removeAt(backStack.size - 1)
            render()
        } else {
            super.onBackPressed()
        }
    }

    // ---------- элементы интерфейса ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun text(t: String, size: Float, color: Int = cText, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(0, dp(2), 0, dp(2))
        return v
    }

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
        return v
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = shape(cCard, 18, cLine)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        c.layoutParams = lp
        return c
    }

    /** kind: 0 обычная, 1 главная (градиент), 2 опасная. */
    private fun button(t: String, kind: Int = 0, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = t
        b.textSize = 15f
        b.gravity = Gravity.CENTER
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.setTextColor(cText)
        b.setPadding(dp(14), dp(14), dp(14), dp(14))
        b.background = when (kind) {
            1 -> {
                val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF2F6BFF.toInt(), 0xFFC13DFF.toInt()))
                g.cornerRadius = dp(14).toFloat()
                g
            }
            2 -> shape(0xFF3A1F2B.toInt(), 14, cRed)
            else -> shape(0xCC141B52.toInt(), 14, 0xFF35D6FF.toInt())
        }
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        b.layoutParams = lp
        return b
    }

    private fun smallButton(t: String, onClick: () -> Unit): TextView {
        val b = button(t, 0, onClick)
        b.textSize = 13f
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        b.layoutParams = lp
        return b
    }

    private fun inputBox(hint: String, lines: Int = 1): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setTextColor(cText)
        e.setHintTextColor(cMuted)
        e.background = shape(0xFF111833.toInt(), 12, cLine)
        e.setPadding(dp(12), dp(12), dp(12), dp(12))
        e.minLines = lines
        if (lines == 1) e.setSingleLine()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        e.layoutParams = lp
        return e
    }

    private fun backBar(title: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val back = text("‹", 34f, cText, true)
        back.setPadding(0, 0, dp(16), dp(4))
        back.setOnClickListener { onBackPressed() }
        row.addView(back)
        row.addView(text(title, 24f, cText, true))
        content.addView(row)
        content.addView(space(10))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun openLink(url: String) {
        if (url.isBlank()) {
            toast("Ссылка появится позже")
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            toast("Не удалось открыть ссылку")
        }
    }

    private fun openTg() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(tgUrl)))
        } catch (_: Exception) {
            toast("Не удалось открыть Telegram")
        }
    }

    private fun openGame() {
        val i = packageManager.getLaunchIntentForPackage(gamePkg)
        if (i != null) startActivity(i) else toast("Hay Day не найден на телефоне")
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName + "/" + BotService::class.java.name) || s.contains(packageName + "/.BotService")
    }

    private fun keyPrefs() = getSharedPreferences("license", MODE_PRIVATE)

    // ---------- приветствие при входе ----------

    private var welcome = true

    private fun colored(vararg parts: Pair<String, Int>): CharSequence {
        val sb = SpannableStringBuilder()
        for ((t, col) in parts) {
            val st = sb.length
            sb.append(t)
            sb.setSpan(ForegroundColorSpan(col), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    private fun neonBox(r: Int): LayerDrawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF35D6FF.toInt(), 0xFF7B3DFF.toInt(), 0xFFFF3DD6.toInt()))
        outer.cornerRadius = dp(r).toFloat()
        val inner = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xF2070A26.toInt(), 0xF2120A36.toInt()))
        inner.cornerRadius = dp(r - 2).toFloat()
        val ld = LayerDrawable(arrayOf(outer, inner))
        ld.setLayerInset(1, dp(2), dp(2), dp(2), dp(2))
        return ld
    }

    private fun welcomeScreen() {
        content.addView(space(24))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.background = neonBox(22)
        box.setPadding(dp(20), dp(14), dp(20), dp(22))

        val x = text("✕", 20f, cText, true)
        x.setPadding(dp(10), dp(4), dp(10), dp(4))
        x.setOnClickListener {
            welcome = false
            render()
        }
        val xl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        xl.gravity = Gravity.END
        box.addView(x, xl)

        val i = text("i", 34f, cText, true)
        i.gravity = Gravity.CENTER
        val ring = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF1B2A8A.toInt(), 0xFF7B3DFF.toInt()))
        ring.shape = GradientDrawable.OVAL
        ring.setStroke(dp(2), 0xFF35D6FF.toInt())
        i.background = ring
        box.addView(i, LinearLayout.LayoutParams(dp(64), dp(64)).also { it.setMargins(0, 0, 0, dp(10)) })

        val title = TextView(this)
        title.text = colored(
            Pair("Здравствуйте,\n", cText),
            Pair("дорогой ", 0xFF35D6FF.toInt()),
            Pair("пользователь!", 0xFFFF6BE0.toInt())
        )
        title.textSize = 24f
        title.gravity = Gravity.CENTER
        title.setTypeface(title.typeface, Typeface.BOLD)
        box.addView(title)

        val line = View(this)
        line.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0x0035D6FF, 0xFF35D6FF.toInt(), 0xFFC13DFF.toInt(), 0x00C13DFF))
        box.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)).also { it.setMargins(0, dp(14), 0, dp(14)) })

        val body = TextView(this)
        body.text = colored(
            Pair("Данное приложение находится на ", cText),
            Pair("этапе разработки.\n\n", 0xFF35D6FF.toInt()),
            Pair("Могут присутствовать ", cText),
            Pair("ошибки ", 0xFFC13DFF.toInt()),
            Pair("и недоработки, но мы стараемся ", cText),
            Pair("улучшать ", 0xFF35D6FF.toInt()),
            Pair("его как можно чаще.", cText)
        )
        body.textSize = 16f
        body.gravity = Gravity.CENTER
        box.addView(body)

        val thanks = text("🚀   Спасибо за понимание и поддержку! 💜", 14f, cText)
        thanks.gravity = Gravity.CENTER
        thanks.background = shape(0x66141B52, 16, 0xFF7B3DFF.toInt())
        thanks.setPadding(dp(12), dp(14), dp(12), dp(14))
        box.addView(thanks, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, dp(16), 0, dp(6)) })

        box.addView(button("Понятно  ›", 1) {
            welcome = false
            render()
        })
        content.addView(box)
    }

    // ---------- главная: выбор бота ----------

    // ---------- Hay Day ----------

    private fun fmtMs(ms: Long): String {
        val m = ms / 60_000
        return (m / 60).toString() + " ч " + (m % 60) + " мин"
    }

    // ---------- журнал ----------

    private fun logScreen() {
        backBar("📜 Журнал")
        val full = Journal.read(this)
        val c = card()
        val tv = text(if (full.isBlank()) "Журнал пока пуст. Он наполнится, когда бот поработает." else full.takeLast(12_000), 11f, cText)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextIsSelectable(true)
        c.addView(tv)
        content.addView(c)
        content.addView(button("📋 Скопировать debug", 1) {
            val txt = Debug.build(this, cfg, resources.displayMetrics.widthPixels.toString() + "x" + resources.displayMetrics.heightPixels)
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TapTapBot debug", txt))
            toast("Debug скопирован: вставь его в чат")
        })
        content.addView(button("Поделиться журналом") {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, full)
            startActivity(Intent.createChooser(i, "Поделиться журналом"))
        })
        content.addView(button("Очистить журнал", 2) {
            Journal.clear(this)
            render()
        })
    }

    // ---------- профили ----------

    // ---------- свои задачи ----------

    private fun tasksScreen() {
        backBar("🧩 Свои задачи")
        val info = card()
        info.addView(text(
            "Запиши любую последовательность нажатий в игре (яйца, молоко, пекарня), и бот будет повторять её по таймеру между делами. " +
                "Запись: панель в игре → ⋯ Ещё → 🧩 Задачи → 🔴 Записать. В конце верни игру в исходный вид: закрой окна и меню.",
            13f, cMuted
        ))
        content.addView(info)

        val n = cfg.macroCount()
        if (n == 0) content.addView(text("Задач пока нет", 13f, cMuted))
        for (m in 0 until n) {
            val iv = cfg.macroInterval(m)
            val c = card()
            c.addView(text("🧩 Задача " + (m + 1), 17f, cText, true))
            c.addView(text(
                cfg.macroTaps(m).size.toString() + " нажатий · " + (if (iv <= 0) "выключена" else "каждые $iv мин"),
                13f, cMuted
            ))
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(smallButton("− 5 мин") {
                cfg.setMacroInterval(m, cfg.macroInterval(m) - 5)
                render()
            })
            row.addView(smallButton("+ 5 мин") {
                cfg.setMacroInterval(m, cfg.macroInterval(m) + 5)
                render()
            })
            row.addView(smallButton("🗑") {
                cfg.deleteMacro(m)
                render()
            })
            c.addView(row)
            content.addView(c)
        }
    }

    // ---------- активация ----------

    private fun keyScreen() {
        backBar("🔑 Активация")
        val i = License.info(this)
        val c = card()
        val badge: String
        val col: Int
        when (i.state) {
            LicState.ACTIVE -> { badge = "✅ Ключ активен"; col = cGreen }
            LicState.EXPIRED -> { badge = "⌛ Срок действия истёк"; col = cRed }
            LicState.PENDING -> { badge = "⏳ Ключ ждёт проверки"; col = 0xFFFFC107.toInt() }
            LicState.INVALID -> { badge = "⛔ Ключ не подошёл"; col = cRed }
            LicState.NONE -> { badge = "⛔ Ключ не активирован"; col = cMuted }
        }
        c.addView(text(badge, 19f, col, true))
        if (i.state == LicState.ACTIVE) {
            c.addView(text("Осталось: " + License.left(i.expiresAt - System.currentTimeMillis()), 15f, cText, true))
            c.addView(text("Действует до " + License.expiresText(i.expiresAt), 13f, cMuted))
        }
        if (i.state == LicState.EXPIRED) c.addView(text("Истёк " + License.expiresText(i.expiresAt), 13f, cMuted))
        if (i.msg.isNotEmpty() && i.state != LicState.ACTIVE) c.addView(text(i.msg, 13f, cMuted))
        if (i.key.isNotEmpty()) c.addView(text("Ключ: " + i.key.take(8) + "••••", 13f, cMuted))
        c.addView(text("Устройство: " + License.deviceId(this), 12f, cMuted))
        keyEt = inputBox("Введи ключ: TTB-XXXX-XXXX-XXXX-XXXX")
        c.addView(keyEt)
        c.addView(button("Активировать", 1) {
            License.activate(this, keyEt.text.toString()) { r ->
                runOnUiThread {
                    toast(r.msg)
                    render()
                }
            }
        })
        if (i.key.isNotEmpty()) {
            c.addView(button("Удалить ключ", 2) {
                License.clear(this)
                render()
            })
        }
        if (!LicenseConfig.ENFORCE) c.addView(text("Сейчас бот работает и без ключа: проверка включится позже.", 12f, cMuted))
        content.addView(c)

        // ссылки: позже сюда подставим бота с ключами, канал и инструкцию
        val buy = card()
        buy.addView(text("Получить ключ", 16f, cText, true))
        buy.addView(text("Ключи будет выдавать бот в Telegram после покупки. Пока пиши разработчику.", 13f, cMuted))
        buy.addView(button("🤖 Бот с ключами в Telegram") { openLink(LicenseConfig.BOT_URL) })
        buy.addView(button("🛒 FunPay") { openLink(LicenseConfig.FUNPAY_URL) })
        buy.addView(button("💬 Написать разработчику", 1) { openLink(LicenseConfig.SUPPORT_URL) })
        buy.addView(button("📣 Канал обновлений") { openLink(LicenseConfig.CHANNEL_URL) })
        buy.addView(button("📖 Инструкция") { openLink(LicenseConfig.GUIDE_URL) })
        content.addView(buy)
    }

    // ---------- амбар ----------

    private fun numField(c: LinearLayout, label: String, value: Int): EditText {
        c.addView(text(label, 13f, cMuted))
        val e = inputBox(label)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(value.toString())
        c.addView(e)
        return e
    }

    // ---------- справка ----------

    private fun guideScreen() {
        backBar("📖 Как пользоваться")
        val c = card()
        c.addView(text(
            "1. Включи службу: нажми «Запустить» на главной (если служба выключена, откроются специальные возможности). Если пункт серый (Android 13+): «Настройки приложения» → ⋮ → «Разрешить ограниченные настройки».\n\n" +
                "2. Открой Hay Day. Поверх игры появится панель TapTapBot's. Панель сама ничего не запускает.\n\n" +
                "3. Нажми «⚙ Настроить» и пройди шаги: камера, грядка, культура, область поля (растяни рамку), пустая земля, проверка посадки и сбора, продажа. На каждом шаге написано, что нажать.\n\n" +
                "4. «▶ Запустить»: бот работает сам. Статус виден сверху в игре, остановка кнопкой ■.\n\n" +
                "5. Несколько полей: панель → ⋯ Ещё → ➕ Поле. Поля должны быть рядом, чтобы камера не ехала при нажатии. Если камера съезжает, включи выравнивание 📷 в ⋯ Ещё: бот сам подтянет карту по эталону (👻 показывает эталон).\n\n" +
                "6. Свои задачи: ⋯ Ещё → 🧩 Задачи → 🔴 Записать.\n\n" +
                "7. Пауза и стоп: пока бот работает или идёт проверка (посадка, сбор, листание), в шапке панели есть ⏸ и ■, а в раскрытой панели большая кнопка. Пауза срабатывает после текущего действия.\n\n" +
                "8. Лавка со страницами слотов: на шаге «Пролистай лавку» проведи пальцем, лавка прокрутится по-настоящему, бот проверит это по картинке, а ты отметишь слоты на каждой странице. Число страниц меняется в ⋯ Ещё → 📄.\n\n" +
                "9. Скорость, паузы и прижим земли: Настройки → Скорость (или ⚡ в панели). В лавке бот сам находит пшеницу в списке по картинке, даже если другая культура заняла её место.\n\n" +
                "10. Силосная башня: числа (занято, вместимость, клетки) вводятся в самом начале мастера, их можно поправить в Настройки → Хранилище. Бот сам считает урожай и продаёт, когда места не хватает.\n\n" +
                "11. Если что-то идёт не так, загляни в журнал и отправь его разработчику.",
            14f, cText
        ))
        content.addView(c)
    }

    // ================= новый интерфейс: неон, плитки, ползунки =================

    private val cCyan = 0xFF35D6FF.toInt()
    private val cViolet = 0xFF7B3DFF.toInt()
    private val cPink = 0xFFFF3DD6.toInt()
    private var speedTab = 0
    private var barnTab = 0

    private fun withA(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    /** Стеклянная панель с неоновой рамкой. active: подсвеченная (выбранная). */
    private fun glass(r: Int, active: Boolean = false): LayerDrawable {
        val a = if (active) 0xFF else 0x99
        val outer = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(withA(cCyan, a), withA(cViolet, a), withA(cPink, a)))
        outer.cornerRadius = dp(r).toFloat()
        val inner = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            if (active) intArrayOf(0xF0143A9A.toInt(), 0xF0230E6A.toInt()) else intArrayOf(0xF00B1040.toInt(), 0xF0140B3A.toInt())
        )
        inner.cornerRadius = dp(r - 2).toFloat()
        val ld = LayerDrawable(arrayOf(outer, inner))
        ld.setLayerInset(1, dp(2), dp(2), dp(2), dp(2))
        return ld
    }

    /** Лёгкая реакция на нажатие: всё кликабельное чуть тускнеет под пальцем. */
    private fun press(v: View) {
        v.isClickable = true
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.alpha = 0.7f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.alpha = 1f
            }
            false
        }
    }

    private fun centered(t: String, size: Float, color: Int = cText, bold: Boolean = false): TextView {
        val v = text(t, size, color, bold)
        v.gravity = Gravity.CENTER
        return v
    }

    private fun tile(icon: String, title: String, sub: String = "", active: Boolean = false, onClick: () -> Unit): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.background = glass(18, active)
        t.setPadding(dp(8), dp(18), dp(8), dp(18))
        t.addView(centered(icon, 34f), lp(MATCH, WRAP))
        t.addView(centered(title, 15f, cText, true), lp(MATCH, WRAP, 0f, 0, 4))
        if (sub.isNotEmpty()) t.addView(centered(sub, 11f, cMuted), lp(MATCH, WRAP))
        press(t)
        t.setOnClickListener { onClick() }
        t.layoutParams = lp(0, WRAP, 1f, 4, 4, 4, 4)
        return t
    }

    private fun tileRow(vararg tiles: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (t in tiles) r.addView(t)
        content.addView(r, lp(MATCH, WRAP, 0f, 0, 6, 0, 6))
        return r
    }

    /** Шапка экрана: «Назад», значок, заголовок и логотип справа. */
    private fun topBar(icon: String, title: String, sub: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val back = text("‹  Назад", 15f, cText, true)
        back.setPadding(dp(16), dp(10), dp(16), dp(10))
        back.background = glass(12)
        press(back)
        back.setOnClickListener { onBackPressed() }
        row.addView(back)
        val sep = View(this)
        sep.setBackgroundColor(0x883D6BFF.toInt())
        row.addView(sep, lp(dp(1), dp(38), 0f, 14, 0, 14, 0))
        row.addView(text(icon, 30f), lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(title, 22f, cText, true))
        col.addView(text(sub, 12f, cMuted))
        row.addView(col, lp(0, WRAP, 1f))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        row.addView(logo, lp(dp(64), dp(64)))
        content.addView(row, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
    }

    private fun panel(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = glass(20)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        return c
    }

    private fun styledSwitch(on: Boolean, onChange: (Boolean) -> Unit): Switch {
        val sw = Switch(this)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(cCyan, 0xFF3A3F6B.toInt()))
        sw.thumbTintList = ColorStateList(states, intArrayOf(0xFFFFFFFF.toInt(), 0xFFCCD3F0.toInt()))
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        return sw
    }

    /** Карточка с переключателем: нажатие по любому месту карточки переключает. */
    private fun toggleCard(icon: String, title: String, desc: String, on: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.background = glass(20)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.addView(text(icon, 40f), lp(WRAP, WRAP, 0f, 0, 0, 14, 0))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(title, 17f, cText, true))
        col.addView(text(desc, 13f, cMuted))
        c.addView(col, lp(0, WRAP, 1f))
        val sw = styledSwitch(on, onChange)
        c.addView(sw, lp(WRAP, WRAP, 0f, 10, 0, 0, 0))
        press(c)
        c.setOnClickListener { sw.toggle() }
        content.addView(c, lp(MATCH, WRAP, 0f, 0, 6, 0, 6))
        return c
    }

    /** Ползунок со значением и кнопками ▲▼. show: как печатать значение. */
    private fun sliderRow(value: Int, min: Int, max: Int, step: Int, show: (Int) -> String, onChange: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(16)
        row.setPadding(dp(14), dp(12), dp(10), dp(12))
        var cur = value.coerceIn(min, max)
        val sb = SeekBar(this)
        sb.max = (max - min) / step
        sb.progress = (cur - min) / step
        sb.progressTintList = ColorStateList.valueOf(cCyan)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0x773D6BFF)
        sb.thumbTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        val valueTv = centered(show(cur), 22f, cText, true)
        valueTv.minWidth = dp(110)
        fun setV(v: Int) {
            cur = v.coerceIn(min, max)
            valueTv.text = show(cur)
            sb.progress = (cur - min) / step
            onChange(cur)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    cur = min + p * step
                    valueTv.text = show(cur)
                    onChange(cur)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(sb, lp(0, dp(44), 1f))
        row.addView(valueTv, lp(WRAP, WRAP, 0f, 8, 0, 4, 0))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = glass(12)
        val up = centered("▲", 16f, cText, true)
        up.setPadding(dp(14), dp(8), dp(14), dp(8))
        press(up)
        up.setOnClickListener { setV(cur + step) }
        val dn = centered("▼", 16f, cText, true)
        dn.setPadding(dp(14), dp(8), dp(14), dp(8))
        press(dn)
        dn.setOnClickListener { setV(cur - step) }
        col.addView(up)
        col.addView(dn)
        row.addView(col, lp(WRAP, WRAP))
        return row
    }

    private fun infoRow(msg: String): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = glass(14)
        r.setPadding(dp(14), dp(10), dp(14), dp(10))
        r.addView(text("ⓘ", 22f, cCyan, true), lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        r.addView(text(msg, 13f, cText), lp(0, WRAP, 1f))
        return r
    }

    private fun confirm(msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton("Да") { _, _ -> onYes() }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun askText(title: String, hint: String, initial: String, lines: Int = 1, onOk: (String) -> Unit) {
        val e = EditText(this)
        e.hint = hint
        e.setText(initial)
        e.minLines = lines
        if (lines == 1) e.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(e)
            .setPositiveButton("ОК") { _, _ -> onOk(e.text.toString()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ---------- главный экран ----------

    private fun launchGame(cmdSetup: Boolean) {
        if (!serviceOn()) {
            toast("Сначала включи службу: Специальные возможности → TapTapBot's")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (cmdSetup) getSharedPreferences("cmd", MODE_PRIVATE).edit().putString("do", "setup").apply()
        openGame()
    }

    private fun homeScreen() {
        content.addView(space(6))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        content.addView(logo, lp(dp(130), dp(130)).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        content.addView(centered("Автоматизация мобильных игр · Hay Day", 13f, cMuted))
        content.addView(space(14))

        tileRow(
            tile("▶", "Запустить", "открыть Hay Day", true) { launchGame(false) },
            tile("🔄", "Настроить заново", "мастер в игре") { launchGame(true) },
            tile("⚙", "Настройки", "скорость, склад, лавка") { go("settings") },
            tile("📁", "Конфиги", "сохранить и загрузить") { go("configs") },
            tile("❓", "Помощь", "поддержка и справка") { go("help") }
        )

        val on = serviceOn()
        val strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        strip.gravity = Gravity.CENTER_VERTICAL
        strip.background = glass(16)
        strip.setPadding(dp(14), dp(10), dp(14), dp(10))
        val st = text(if (on) "● Служба включена" else "⛔ Служба выключена · нажми, чтобы включить", 13f, if (on) cGreen else cRed, true)
        st.setOnClickListener { if (!on) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        strip.addView(st, lp(0, WRAP, 1f))
        val li = License.info(this)
        val kc = when (li.state) {
            LicState.ACTIVE -> cGreen
            LicState.NONE -> cMuted
            LicState.PENDING -> 0xFFFFC107.toInt()
            else -> cRed
        }
        val key = text("🔑 " + License.shortStatus(this).replaceFirstChar { it.uppercase() }, 13f, kc, true)
        key.setPadding(dp(10), dp(6), dp(10), dp(6))
        press(key)
        key.setOnClickListener { go("key") }
        strip.addView(key)
        content.addView(strip, lp(MATCH, WRAP, 0f, 0, 10, 0, 6))

        content.addView(centered("Разработчик 4ernovik · Telegram @flomaster6", 12f, cMuted))
        content.addView(centered("Использование ботов нарушает правила игр. Риск блокировки аккаунта лежит на пользователе.", 11f, cMuted))
    }

    // ---------- настройки: разделы ----------

    private fun settingsScreen() {
        topBar("⚙", "Настройки", "Выбери раздел")
        tileRow(
            tile("⚡", "Скорость", "посев, сбор, лавка") { go("speed") },
            tile("📦", "Хранилище", "силос и подсчёт") { go("storage") },
            tile("🏪", "Магазин", "продажа и реклама") { go("shop") }
        )
        tileRow(
            tile("🧩", "Свои задачи", "макросы по таймеру") { go("tasks") },
            tile("📊", "Статистика", "посадки, сборы, продажи") { go("stats") },
            tile("📜", "Журнал", "debug для разработчика") { go("log") }
        )
    }

    private fun statsScreen() {
        topBar("📊", "Статистика", "Что бот сделал за всё время")
        val sc = panel()
        sc.addView(text("🌾 Посадок: " + stats.get("plants") + "      🔪 Сборов: " + stats.get("harvests"), 17f, cText))
        sc.addView(text("💰 Продаж: " + stats.get("sales") + "      🧩 Задач: " + stats.get("macros"), 17f, cText))
        sc.addView(text("▶ Запусков: " + stats.get("runs") + "      ⚠ Сбоев: " + stats.get("fails"), 17f, cText))
        sc.addView(text("⏱ В работе: " + fmtMs(stats.get("runMs")), 17f, cText))
        content.addView(sc, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        content.addView(button("🗑 Сбросить статистику", 2) {
            confirm("Сбросить статистику?") {
                stats.reset()
                render()
            }
        })
    }

    // ---------- скорость ----------

    private class SpeedItem(
        val icon: String, val title: String, val sub: String, val tip: String, val rec: String,
        val min: Int, val max: Int, val step: Int,
        val get: () -> Int, val set: (Int) -> Unit, val show: (Int) -> String
    )

    private fun speedScreen() {
        topBar("⚡", "Скорость", "Регулируйте скорость действий бота")
        val pct = { v: Int -> "$v %" }
        val ms = { v: Int -> "$v мс" }
        val items = listOf(
            SpeedItem("🌱", "Посадка культуры", "Скорость посадки культур на поле", "Чем больше значение, тем быстрее палец ведёт по полю при посеве.",
                "500 %", 50, 600, 10, { cfg.speedPlant }, { cfg.speedPlant = it }, pct),
            SpeedItem("🌾", "Сбор культуры", "Скорость сбора урожая серпом", "Чем больше значение, тем быстрее палец ведёт по полю при сборе.",
                "500 %", 50, 600, 10, { cfg.speedHarvest }, { cfg.speedHarvest = it }, pct),
            SpeedItem("⏱", "Задержка между посадками и сбором", "Пауза после каждой посадки и сбора", "Если камера сдвигается или игра не успевает, увеличь паузу. 0 — без добавочной паузы.",
                "0 мс", 0, 10000, 100, { cfg.delayAct }, { cfg.delayAct = it }, ms),
            SpeedItem("🏪", "Выставление предметов", "Скорость работы в лавке", "Чем больше значение, тем быстрее бот нажимает в лавке. Если окна не успевают открываться, уменьши.",
                "200 %", 50, 400, 10, { cfg.speedShop }, { cfg.speedShop = it }, pct),
            SpeedItem("🛒", "Задержка между выставлением в магазин", "Пауза после каждого выставленного слота", "Увеличь, если игра пропускает нажатия при выставлении. 0 — без добавочной паузы.",
                "0 мс", 0, 10000, 100, { cfg.delayShop }, { cfg.delayShop = it }, ms),
            SpeedItem("🟫", "Прижим земли", "Сколько держать палец на пустой земле после посева и сбора", "Палец уходит на точку «пустая земля», держится там и отпускается. Так камера не уезжает. Меньше 0,6 с — выключено.",
                "1000 мс", 500, 4000, 100, { cfg.groundMs.let { if (it <= 0) 500 else it } }, { cfg.groundMs = it },
                { v -> if (v < 600) "выкл" else "$v мс" }),
            SpeedItem("✋", "Удержание иконки", "Сколько держать иконку культуры или серпа перед посевом", "Игре нужно время, чтобы «взять» иконку. Если посев не начинается, увеличь.",
                "600 мс", 100, 2000, 50, { cfg.holdMs }, { cfg.holdMs = it }, ms)
        )
        if (speedTab >= items.size) speedTab = 0

        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.HORIZONTAL
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        for ((i, si) in items.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = glass(14, i == speedTab)
            row.setPadding(dp(10), dp(10), dp(10), dp(10))
            row.addView(text(si.icon, 22f), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
            row.addView(text(si.title, 13f, cText, i == speedTab), lp(0, WRAP, 1f))
            press(row)
            row.setOnClickListener {
                speedTab = i
                render()
            }
            side.addView(row, lp(MATCH, WRAP, 0f, 0, 3, 0, 3))
        }
        wrap.addView(side, lp(dp(230), WRAP, 0f, 0, 0, 10, 0))

        val cur = items[speedTab]
        val main = panel()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(text(cur.icon, 44f), lp(WRAP, WRAP, 0f, 0, 0, 12, 0))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(cur.title, 19f, cText, true))
        col.addView(text(cur.sub, 13f, cMuted))
        head.addView(col, lp(0, WRAP, 1f))
        val rec = text("⚡ Рекомендуемое: " + cur.rec, 12f, cText)
        rec.background = glass(14)
        rec.setPadding(dp(10), dp(6), dp(10), dp(6))
        head.addView(rec)
        main.addView(head)
        main.addView(space(10))
        main.addView(sliderRow(cur.get(), cur.min, cur.max, cur.step, cur.show) { v -> cur.set(v) })
        main.addView(space(10))
        main.addView(infoRow(cur.tip))
        wrap.addView(main, lp(0, WRAP, 1f))
        content.addView(wrap)
    }

    // ---------- хранилище ----------

    private fun storageScreen() {
        topBar("📦", "Хранилище", "Настройте параметры хранилища")
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val names = listOf("🌾  Информация о хранилище", "📦  Лимит хранилища")
        for ((i, n) in names.withIndex()) {
            val t = centered(n, 15f, cText, i == barnTab)
            t.background = glass(16, i == barnTab)
            t.setPadding(dp(8), dp(14), dp(8), dp(14))
            press(t)
            t.setOnClickListener {
                barnTab = i
                render()
            }
            tabs.addView(t, lp(0, WRAP, 1f, 3, 0, 3, 0))
        }
        content.addView(tabs, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))

        if (barnTab == 0) {
            val used = cfg.barnUsed
            val cap = cfg.barnCap
            val p = panel()
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for ((label, v) in listOf("Сейчас в хранилище:" to used, "Лимит хранилища:" to cap)) {
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.background = glass(14)
                box.setPadding(dp(16), dp(10), dp(16), dp(10))
                box.addView(text(label, 13f, cMuted))
                box.addView(text("$v шт.", 30f, cText, true))
                row.addView(box, lp(0, WRAP, 1f, 4, 0, 4, 0))
            }
            p.addView(row)
            val pc = if (cap > 0) (used * 100 / cap).coerceIn(0, 100) else 0
            val pr = LinearLayout(this)
            pr.orientation = LinearLayout.HORIZONTAL
            pr.gravity = Gravity.CENTER_VERTICAL
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = 100
            bar.progress = pc
            bar.progressTintList = ColorStateList.valueOf(cCyan)
            bar.progressBackgroundTintList = ColorStateList.valueOf(0x773D6BFF)
            pr.addView(bar, lp(0, dp(16), 1f))
            pr.addView(text("$pc%", 22f, cCyan, true), lp(WRAP, WRAP, 0f, 12, 0, 0, 0))
            p.addView(pr, lp(MATCH, WRAP, 0f, 0, 12, 0, 0))
            if (cap <= 0) p.addView(text("Лимит не задан: открой вкладку «Лимит хранилища» и впиши вместимость.", 12f, cMuted))
            content.addView(p, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
            toggleCard("⚙", "Автоматический подсчёт", "Бот сам считает, сколько пшеницы в хранилище: плюс при сборе, минус на посев и при продаже", cfg.autoCount) {
                cfg.autoCount = it
            }
        } else {
            val c = panel()
            c.addView(text(
                "Бот считает урожай: после каждого сбора прибавляет «клеток × урожай с клетки». Когда места на следующий сбор не хватает, он идёт в лавку и вычитает проданное. Вместимость 0 = расчёт выключен.",
                13f, cMuted
            ))
            val e1 = numField(c, "Клеток на первом поле", cfg.cellsOf(0))
            val e2 = numField(c, "Урожай с одной клетки", cfg.perCell)
            val e3 = numField(c, "Вместимость хранилища (всего)", cfg.barnCap)
            val e4 = numField(c, "Занято сейчас", cfg.barnUsed)
            val e5 = numField(c, "Пшеницы в одном слоте лавки", cfg.perSlot)
            c.addView(button("💾 Сохранить", 1) {
                cfg.setCells(0, e1.text.toString().toIntOrNull() ?: 0)
                cfg.perCell = e2.text.toString().toIntOrNull() ?: 2
                cfg.barnCap = e3.text.toString().toIntOrNull() ?: 0
                cfg.barnUsed = e4.text.toString().toIntOrNull() ?: 0
                cfg.perSlot = e5.text.toString().toIntOrNull() ?: 10
                toast("Сохранено")
                render()
            })
            content.addView(c, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        }
    }

    // ---------- магазин ----------

    private fun shopScreen() {
        topBar("🏪", "Магазин", "Настройте параметры магазина")
        toggleCard("🏪", "Автоматическое выставление на продажу при заполнении хранилища",
            "Когда в хранилище будет мало места на следующий сбор, бот выставит пшеницу на продажу.", cfg.sellOnFull) {
            cfg.sellOnFull = it
            render()
        }
        toggleCard("📢", "Автоматическое выставление товара в рекламу",
            "Бот будет ставить товар в рекламу на последнем слоте (не чаще раза в 5 минут).", cfg.adOn) { cfg.adOn = it }
        if (!cfg.sellOnFull) {
            val p = panel()
            p.addView(text("Продажа по заполнению выключена: бот продаёт раз в N посадок.", 13f, cMuted))
            p.addView(text("Продавать каждые N посадок", 15f, cText, true))
            p.addView(sliderRow(cfg.sellEvery, 1, 9, 1, { "$it" }) { cfg.sellEvery = it })
            content.addView(p, lp(MATCH, WRAP, 0f, 0, 6, 0, 6))
        }
        if (cfg.first(T.SHOP, 0) == null) {
            content.addView(infoRow("Лавка ещё не настроена в мастере (шаг «Лавка»): без этого продажа не работает."), lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        }
    }

    // ---------- конфиги ----------

    private fun fmtTime(t: Long): String =
        if (t <= 0L) "—" else SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(t))

    private fun configsScreen() {
        topBar("📁", "Конфиг настроек", "Управляйте своими конфигурациями")
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.addView(tile("💾", "Сохранить конфиг", "текущие настройки", true) {
            askText("Название конфига", "Например: Основной", cfg.activeProfile) { n ->
                val name = n.trim()
                if (name.isEmpty()) toast("Впиши название") else {
                    cfg.saveProfile(name)
                    toast("Сохранено: $name")
                    render()
                }
            }
        })
        top.addView(tile("📥", "Загрузить конфиг", "вставить текст конфига") {
            askText("Загрузить конфиг", "Вставь текст конфига", "", 4) { txt ->
                if (cfg.importJson(txt)) {
                    toast("Загружено. Сохрани его, если нужно")
                } else toast("Не получилось: текст повреждён")
            }
        })
        content.addView(top, lp(MATCH, WRAP, 0f, 0, 0, 0, 6))

        val names = cfg.profileNames()
        val list = panel()
        val hr = LinearLayout(this)
        hr.orientation = LinearLayout.HORIZONTAL
        hr.addView(text("☰  Ваши конфигурации", 18f, cText, true), lp(0, WRAP, 1f))
        hr.addView(text("Всего: " + names.size, 14f, cCyan, true))
        list.addView(hr)
        if (names.isEmpty()) list.addView(text("Конфигов пока нет. Нажми «Сохранить конфиг».", 13f, cMuted))
        for (name in names) {
            val act = name == cfg.activeProfile
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = glass(14, act)
            row.setPadding(dp(12), dp(10), dp(10), dp(10))
            row.addView(text(if (act) "⭐" else "📄", 26f), lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(text(name, 16f, cText, true))
            col.addView(text("Последнее изменение: " + fmtTime(cfg.profileTime(name)), 11f, cMuted))
            row.addView(col, lp(0, WRAP, 1f))
            val chip = centered(if (act) "Активный" else "Сделать активным", 12f, cText, true)
            chip.background = glass(12, act)
            chip.setPadding(dp(10), dp(8), dp(10), dp(8))
            press(chip)
            chip.setOnClickListener {
                toast(if (cfg.loadProfile(name)) "Активен: $name" else "Не удалось загрузить")
                render()
            }
            row.addView(chip, lp(WRAP, WRAP, 0f, 4, 0, 4, 0))
            fun icon(t: String, f: () -> Unit) {
                val v = centered(t, 18f)
                v.background = glass(12)
                v.setPadding(dp(10), dp(8), dp(10), dp(8))
                press(v)
                v.setOnClickListener { f() }
                row.addView(v, lp(WRAP, WRAP, 0f, 2, 0, 2, 0))
            }
            icon("▶") {
                if (cfg.loadProfile(name)) launchGame(false) else toast("Не удалось загрузить")
            }
            icon("✏") {
                askText("Переименовать", "Новое название", name) { n ->
                    if (cfg.renameProfile(name, n)) render() else toast("Такое имя занято или пустое")
                }
            }
            icon("🗑") {
                confirm("Удалить конфиг «$name»?") {
                    cfg.deleteProfile(name)
                    render()
                }
            }
            row.setOnLongClickListener {
                val json = cfg.profileJson(name)
                if (json != null) {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_TEXT, json)
                    startActivity(Intent.createChooser(i, "Поделиться конфигом"))
                }
                true
            }
            list.addView(row, lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        }
        if (names.isNotEmpty()) list.addView(text("Долгое нажатие на конфиг — поделиться им текстом.", 11f, cMuted))
        content.addView(list, lp(MATCH, WRAP, 0f, 0, 0, 0, 6))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.addView(tile("↺", "Сбросить настройки", "стандартные значения") {
            confirm("Вернуть стандартные настройки? Поля и точки останутся.") {
                cfg.resetDefaults()
                toast("Настройки сброшены")
                render()
            }
        })
        val del = tile("🗑", "Удалить все конфиги", "сохранённые копии") {
            confirm("Удалить все сохранённые конфиги?") {
                cfg.deleteAllProfiles()
                render()
            }
        }
        del.background = shape(0xCC3A1228.toInt(), 18, cRed)
        bottom.addView(del)
        content.addView(bottom)
    }

    // ---------- помощь ----------

    private fun helpScreen() {
        topBar("❓", "Помощь", "Нужна помощь? Мы рядом!")
        val p = panel()
        p.gravity = Gravity.CENTER_HORIZONTAL
        p.addView(centered("🤖", 56f))
        p.addView(centered("Для технической поддержки переходите в Telegram:", 17f, cText, true))
        val tg = centered("✈  @flomaster6", 24f, cText, true)
        tg.background = glass(22, true)
        tg.setPadding(dp(20), dp(14), dp(20), dp(14))
        press(tg)
        tg.setOnClickListener { openTg() }
        p.addView(tg, lp(WRAP, WRAP, 0f, 0, 12, 0, 12))
        content.addView(p, lp(MATCH, WRAP, 0f, 0, 0, 0, 6))
        tileRow(
            tile("📖", "Инструкция", "как пользоваться") { go("guide") },
            tile("📜", "Журнал", "скопировать debug") { go("log") },
            tile("📢", "Канал", "новости и обновления") { openLink(LicenseConfig.CHANNEL_URL) }
        )
    }
}
