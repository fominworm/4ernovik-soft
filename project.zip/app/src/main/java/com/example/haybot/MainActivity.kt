package com.example.haybot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var list: LinearLayout
    private lateinit var nameEt: EditText
    private lateinit var importEt: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, size: Float = 15f, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        if (bold) v.setTypeface(v.typeface, android.graphics.Typeface.BOLD)
        v.setPadding(0, dp(8), 0, dp(4))
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        val pad = dp(16)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        root.addView(
            text(
                "HayBot 🌾 автопосадка, сбор и продажа пшеницы.\n\n" +
                    "1) Нажми «Включить службу», найди HayBot и включи.\n" +
                    "Если пункт серый (Android 13+): «Настройки приложения» → ⋮ → «Разрешить ограниченные настройки», потом снова включи.\n\n" +
                    "2) Открой Hay Day. Панель появится сама, только внутри игры. Она ведёт по шагам: пишет, на что нажать, ты нажимаешь, и она идёт дальше.\n\n" +
                    "Использование ботов нарушает правила Supercell, аккаунт могут заблокировать."
            )
        )
        root.addView(button("Включить службу") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Настройки приложения") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        root.addView(text("Профили настроек", 18f, true))
        root.addView(
            text("Профиль хранит точки, шаг строк и эталоны цвета. Удобно для разных экранов и аккаунтов.", 13f)
        )
        nameEt = EditText(this)
        nameEt.hint = "Название профиля"
        nameEt.setSingleLine()
        root.addView(nameEt)
        root.addView(button("💾 Сохранить текущие настройки") { saveProfile() })
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list)

        root.addView(text("Импорт", 18f, true))
        importEt = EditText(this)
        importEt.hint = "Вставь сюда текст профиля"
        importEt.minLines = 3
        root.addView(importEt)
        root.addView(button("📥 Импортировать как текущие настройки") { doImport() })

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun saveProfile() {
        val n = nameEt.text.toString().trim()
        if (n.isEmpty()) {
            toast("Впиши название профиля")
            return
        }
        cfg.saveProfile(n)
        nameEt.setText("")
        toast("Профиль «$n» сохранён")
        refresh()
    }

    private fun doImport() {
        val s = importEt.text.toString()
        if (cfg.importJson(s)) {
            importEt.setText("")
            toast("Импортировано. Можно сохранить как профиль")
        } else {
            toast("Не получилось: текст профиля повреждён")
        }
    }

    private fun refresh() {
        list.removeAllViews()
        val names = cfg.profileNames()
        if (names.isEmpty()) list.addView(text("Профилей пока нет", 13f))
        for (name in names) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val tv = text(name, 15f, true)
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("Загрузить") {
                toast(if (cfg.loadProfile(name)) "Профиль «$name» загружен" else "Не удалось загрузить")
            })
            row.addView(button("Поделиться") {
                val json = cfg.profileJson(name) ?: return@button
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, json)
                startActivity(Intent.createChooser(i, "Поделиться профилем"))
            })
            row.addView(button("🗑") {
                cfg.deleteProfile(name)
                refresh()
            })
            list.addView(row)
        }
    }
}
