package com.example.haybot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.hypot

/**
 * Показ касаний бота: на каждом нажатии значок «клик», на зажатии значок «зажатие», на проходе по полю змейка
 * (сеет или собирает), плюс неоновый след.
 */
class TrailView(ctx: Context) : View(ctx) {
    /** kind: 0 обычный, 1 змейка-сев, 2 змейка-сбор. */
    private class Tr(val pts: List<P>, val born: Long, val ms: Long, val kind: Int)

    private val trails = ArrayList<Tr>()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val life = 1000L
    private val hsv = FloatArray(3)
    private val hist = ArrayList<P>()
    private var snakeKind = 1
    private var lastSnake = 0L

    /** Пока true, след не рисуется: иначе он попадает на скриншоты и сбивает распознавание. */
    @Volatile var quiet = false

    init {
        line.style = Paint.Style.STROKE
        line.strokeCap = Paint.Cap.ROUND
        Sprites.init(ctx)
    }

    fun hasTrails(): Boolean = trails.size > 0 || hist.isNotEmpty()

    fun add(pts: List<P>, ms: Long, delay: Long = 0L, kind: Int = 0) {
        if (pts.isEmpty()) return
        trails.add(Tr(pts, System.currentTimeMillis() + delay, ms.coerceAtLeast(60L), kind))
        if (trails.size > 60) trails.removeAt(0)
        invalidate()
    }

    private fun neon(hue: Float, alpha: Int): Int {
        hsv[0] = ((hue % 360f) + 360f) % 360f
        hsv[1] = 0.85f
        hsv[2] = 1f
        return Color.HSVToColor(alpha.coerceIn(0, 255), hsv)
    }

    /** Где сейчас палец на этом следе. */
    private fun headPos(t: Tr, age: Long): P {
        val n = t.pts.size
        if (n == 1) return t.pts[0]
        val f = ((age.toFloat() / t.ms) * (n - 1)).coerceIn(0f, (n - 1).toFloat())
        val i = f.toInt().coerceAtMost(n - 2)
        val k = f - i
        return P(t.pts[i].x + (t.pts[i + 1].x - t.pts[i].x) * k, t.pts[i].y + (t.pts[i + 1].y - t.pts[i].y) * k)
    }

    override fun onDraw(c: Canvas) {
        if (quiet) return
        val now = System.currentTimeMillis()
        trails.removeAll { now - it.born > it.ms + life }
        val sc = (width / 2400f).coerceIn(0.6f, 1.6f)
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        var snakeHead: P? = null
        for (t in trails) {
            val n = t.pts.size
            val age = now - t.born
            if (age < 0) continue   // это нажатие ещё впереди
            if (n == 1) {
                val f = (age.toFloat() / life).coerceIn(0f, 1f)
                val a = (255 * (1f - f)).toInt()
                val r = (18f + 70f * f) * sc
                line.strokeWidth = 14f * sc
                line.color = neon(now / 3f, a)
                c.drawCircle(t.pts[0].x - ox, t.pts[0].y - oy, r, line)
                line.strokeWidth = 5f * sc
                line.color = neon(now / 3f + 120f, a)
                c.drawCircle(t.pts[0].x - ox, t.pts[0].y - oy, r * 0.55f, line)
                // значок: короткое касание это «клик», долгое это «зажатие»
                val iconA = if (age <= t.ms) 1f else (1f - (age - t.ms) / 350f)
                if (iconA > 0f) Cursor.draw(c, t.pts[0].x - ox, t.pts[0].y - oy, t.ms >= 300L, 125f * sc, iconA)
                continue
            }
            val head = ((age.toFloat() / t.ms) * (n - 1)).coerceIn(0f, (n - 1).toFloat())
            for (i in 1 until n) {
                if (i - 1 > head) break
                val segAge = age - t.ms * i / (n - 1)
                if (segAge > life) continue
                val f = (segAge.toFloat() / life).coerceIn(0f, 1f)
                val a = (255 * (1f - f)).toInt()
                val hue = now / 3f + i * 9f
                val x0 = t.pts[i - 1].x - ox
                val y0 = t.pts[i - 1].y - oy
                val x1 = t.pts[i].x - ox
                val y1 = t.pts[i].y - oy
                val k = if (t.kind > 0) 0.35f else 1f   // под змейкой след делаем тоньше
                line.strokeWidth = 26f * sc * k
                line.color = neon(hue, a / 4)
                c.drawLine(x0, y0, x1, y1, line)
                line.strokeWidth = 11f * sc * k
                line.color = neon(hue, a)
                c.drawLine(x0, y0, x1, y1, line)
                line.strokeWidth = 3f * sc
                line.color = Color.argb(a, 255, 255, 255)
                c.drawLine(x0, y0, x1, y1, line)
            }
            if (age <= t.ms) {
                val hp = headPos(t, age)
                if (t.kind > 0) {
                    snakeHead = hp
                    snakeKind = t.kind
                    lastSnake = now
                } else {
                    Cursor.draw(c, hp.x - ox, hp.y - oy, true, 125f * sc, 1f)   // палец ведёт: значок «зажатие»
                }
            } else if (age <= t.ms + 350L && t.kind == 0) {
                val hp = t.pts[n - 1]
                Cursor.draw(c, hp.x - ox, hp.y - oy, true, 125f * sc, 1f - (age - t.ms) / 350f)
            }
        }
        // змейка идёт по следу пальца, тянется за головой
        val sh = snakeHead
        if (sh != null) {
            val last = if (hist.isEmpty()) null else hist[hist.size - 1]
            if (last == null || hypot(sh.x - last.x, sh.y - last.y) > 5f) {
                hist.add(sh)
                if (hist.size > 500) hist.removeAt(0)
            }
        }
        if (hist.isNotEmpty()) {
            val since = now - lastSnake
            if (since > 900L) {
                hist.clear()
            } else {
                val poly = hist.map { P(it.x - ox, it.y - oy) }
                val alpha = if (sh != null) 1f else 1f - since / 900f
                Snake.draw(c, poly, Snake.length(poly), snakeKind, now, sc, alpha)
            }
        }
        if (trails.isNotEmpty() || hist.isNotEmpty()) postInvalidateOnAnimation()
    }
}
