package com.example.haybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.text.TextUtils
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.random.Random

class BotService : AccessibilityService() {
    private enum class Mode { MENU, SETUP, RUN, REC }

    private class Act(val t: String, val c: Int, val f: () -> Unit)

    private class Gray(val w: Int, val h: Int, val d: IntArray)

    private val gamePkg = "com.supercell.hayday"

    private val ui = Handler(Looper.getMainLooper())
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val shotExec: Executor = Executors.newSingleThreadExecutor()
    private lateinit var cfg: Cfg
    private lateinit var stats: Stats

    private var mode = Mode.MENU
    private var menuPage = 0
    private var step = 0
    private var expanded = true
    private var note = ""
    private var inGame = false              // сейчас на экране Hay Day
    @Volatile private var busy = false      // идёт повтор нажатия, снятие эталона или задача бота
    @Volatile private var active = false    // работает фоновый поток
    private var plantedAt = 0L
    @Volatile private var lastAd = 0L
    @Volatile private var stopReason: String? = null
    @Volatile private var paused = false
    @Volatile private var taskAborted = false
    private var gestureFails = 0
    private var fails = 0
    private var lastSold = 0
    private var swipeDone = false
    private var shopDirty = false          // после прошлой продажи лавка могла остаться не на первой странице
    private val patchN = 24
    private var worker: Thread? = null

    private val recTaps = ArrayList<MTap>()
    private var recLast = 0L
    private val lastMacro = LongArray(Cfg.MAXM)
    private var runStart = 0L
    @Volatile private var sPlants = 0
    @Volatile private var sHarv = 0
    @Volatile private var sSales = 0
    @Volatile private var sFails = 0

    private val botMode: Boolean get() = mode == Mode.RUN

    private var root: LinearLayout? = null
    private var body: LinearLayout? = null
    private var cap: MarkView? = null
    private var ghost: GhostView? = null
    private var ghostOn = false
    private var trail: TrailView? = null
    private var pill: TextView? = null
    private lateinit var capLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var titleTv: TextView
    private lateinit var promptTv: TextView
    private lateinit var subTv: TextView
    private lateinit var primaryBtn: TextView
    private lateinit var foldBtn: TextView
    private lateinit var stopBtn: TextView
    private lateinit var pauseBtn: TextView
    private lateinit var menuBtn: TextView
    private lateinit var rowA: LinearLayout
    private lateinit var rowB: LinearLayout
    private lateinit var rowC: LinearLayout
    private lateinit var rowD: LinearLayout

    private val adCooldownMs = 305_000L    // реклама не чаще раза в 5 минут

    private val cGray = 0xFF26337A.toInt()
    private val cGreen = 0xFF2E9E4F.toInt()
    private val cRed = 0xFFD64545.toInt()
    private val cBlue = 0xFF2F6FDE.toInt()

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val panelFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    private fun growMs(f: Int): Long = cfg.grow(f) * 1000L

    private fun jlog(m: String) {
        Journal.log(this, m)
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (mode != Mode.SETUP || FLOW[step].kind != Kind.WAIT) return
            val left = ((plantedAt + growMs(cfg.cur) - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
            note = if (left > 0) {
                "⏳ Осталось примерно " + fmt(left.toInt()) + "\nКак только созреет, жми кнопку: я замерю время."
            } else {
                "✅ Должна быть готова. Жми, когда увидишь, что созрела."
            }
            subTv.text = note
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- жизненный цикл ----------

    override fun onServiceConnected() {
        cfg = Cfg(this)
        stats = Stats(this)
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { Journal.log(applicationContext, "💥 Сбой в потоке " + t.name + ": " + e) } catch (_: Throwable) {}
            prevHandler?.uncaughtException(t, e)
        }
        cfg.onExternalChange = { enterMenu("Настройки обновлены") }
        val mv = MarkView(this, cfg)
        mv.onTap = { x, y -> onTapped(x, y) }
        mv.onSwipe = { a, b, ms -> onSwiped(a, b, ms) }
        capLp = overlayParams()
        wm.addView(mv, capLp)
        cap = mv
        val gv = GhostView(this, File(filesDir, "ref.png"))
        wm.addView(gv, overlayParams())
        gv.visibility = View.GONE
        ghost = gv
        val tv = TrailView(this)
        wm.addView(tv, overlayParams())
        trail = tv
        showPanel()   // панель добавляется после слоёв, значит лежит выше них
        showPill()
        mode = Mode.MENU
        inGame = false
        updateUi()
        applyGameState()
        jlog("Служба запущена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val cls = event.className?.toString() ?: ""
        if (cls.contains("InputMethod") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        val g = pkg == gamePkg
        if (g != inGame) {
            inGame = g
            applyGameState()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        active = false
        worker?.interrupt()
        ui.removeCallbacks(ticker)
        removeView(cap)
        removeView(ghost)
        removeView(trail)
        removeView(pill)
        removeView(root)
        super.onDestroy()
    }

    /** Панель и перехват касаний живут только внутри Hay Day. При входе в игру всегда меню: ничего само не запускается. */
    private fun applyGameState() {
        val v = if (inGame) View.VISIBLE else View.GONE
        root?.visibility = v
        cap?.visibility = v
        ghost?.visibility = if (inGame && ghostOn) View.VISIBLE else View.GONE
        trail?.visibility = v
        pill?.visibility = if (inGame && botMode) View.VISIBLE else View.GONE
        if (!inGame) {
            if (botMode) {
                stopBot("Игра свёрнута")
            } else {
                mode = Mode.MENU
                menuPage = 0
                recTaps.clear()
                note = ""
            }
            setArmed(false)
        } else {
            updateUi()
        }
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun overlayParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    /** armed = слой ловит касание пользователя; иначе касания проходят в игру. */
    private fun setArmed(on: Boolean) {
        val mv = cap ?: return
        val want = on && inGame
        if (mv.armed == want) return
        mv.armed = want
        capLp.flags = if (want) baseFlags else (baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        try { wm.updateViewLayout(mv, capLp) } catch (_: Exception) {}
        mv.invalidate()
    }

    private fun keepAwake(on: Boolean) {
        val r = root ?: return
        panelLp.flags = if (on) (panelFlags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else panelFlags
        try { wm.updateViewLayout(r, panelLp) } catch (_: Exception) {}
    }

    private fun copyDebug() {
        val txt = Debug.build(this, cfg, screenW().toString() + "x" + screenH())
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("TapTapBot debug", txt))
        toast("📋 Debug скопирован (" + txt.length + " символов). Вставь его в чат")
    }

    private fun toast(m: String) {
        ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    private fun fmt(sec: Int): String = (sec / 60).toString() + ":" + (sec % 60).toString().padStart(2, '0')

    private fun modeName(m: Int): String = when (m) {
        0 -> "плавно"
        1 -> "медленно"
        2 -> "по шагам"
        3 -> "как человек"
        else -> "туда-сюда"
    }

    private fun recText(): String = when {
        Build.VERSION.SDK_INT < 30 -> "недоступно (нужен Android 11+)"
        !cfg.useRec -> "выкл"
        else -> "вкл, эталонов " + listOf(T.HFIELD, T.CLOSE, T.PUT, T.ITEM).count { cfg.getRef(it, 0) != null }
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    /** Неоновая кнопка: градиент от цвета к светлому оттенку и светящаяся рамка. */
    private fun neon(color: Int, r: Int): GradientDrawable {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[0] = (hsv[0] + 40f) % 360f
        hsv[2] = minOf(1f, hsv[2] + 0.15f)
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(color, Color.HSVToColor(hsv)))
        g.cornerRadius = dp(r).toFloat()
        g.setStroke(dp(1) + 1, 0x99FFFFFF.toInt())
        return g
    }

    private fun panelBg(): LayerDrawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF35D6FF.toInt(), 0xFF7B3DFF.toInt(), 0xFFFF3DD6.toInt()))
        outer.cornerRadius = dp(16).toFloat()
        val inner = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xF00A0D2B.toInt(), 0xF0140B3A.toInt()))
        inner.cornerRadius = dp(14).toFloat()
        val ld = LayerDrawable(arrayOf(outer, inner))
        ld.setLayerInset(1, dp(2), dp(2), dp(2), dp(2))
        return ld
    }

    private fun cardBg(): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(0x66000020)
        g.cornerRadius = dp(12).toFloat()
        g.setStroke(dp(1), 0x6635D6FF)
        return g
    }

    private fun vis(show: Boolean): Int = if (show) View.VISIBLE else View.GONE

    private fun btn(t: String, color: Int, weight: Float = 0f, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.WHITE)
        v.textSize = 13f
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(8), dp(8), dp(8), dp(8))
        v.background = neon(color, 12)
        v.setOnClickListener { onClick() }
        val w = if (weight > 0f) 0 else ViewGroup.LayoutParams.WRAP_CONTENT
        val lp = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        v.layoutParams = lp
        return v
    }

    private fun big(t: String, color: Int, onClick: () -> Unit): TextView {
        val v = btn(t, color, 0f, onClick)
        v.textSize = 16f
        v.setPadding(dp(10), dp(12), dp(10), dp(12))
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(dp(2), dp(6), dp(2), dp(4))
        v.layoutParams = lp
        return v
    }

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(4), dp(3), dp(4), dp(3))
        return v
    }

    private fun newRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun fillRow(row: LinearLayout, items: List<Act>) {
        row.removeAllViews()
        for (a in items) row.addView(btn(a.t, a.c, 1f, a.f))
        row.visibility = vis(items.isNotEmpty())
    }

    private fun clearRows() {
        fillRow(rowA, emptyList())
        fillRow(rowB, emptyList())
        fillRow(rowC, emptyList())
        fillRow(rowD, emptyList())
    }

    private fun showPanel() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = panelBg()
        box.setPadding(dp(6), dp(6), dp(6), dp(6))

        // шапка: перетащить, заголовок, в меню, стоп, показать точки, свернуть
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val drag = btn("≡", cGray) {}
        titleTv = label(12f, 0xFF7DE8FF.toInt())
        titleTv.maxWidth = dp(150)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        menuBtn = btn("🏠", cGray) { if (!busy) enterMenu() }
        pauseBtn = btn("⏸", cBlue) { togglePause() }
        stopBtn = btn("■", cRed) { stopBot("Остановлено кнопкой") }
        val eye = btn("👁", cGray) { toggleMarks() }
        foldBtn = btn("⌄", cGray) { expanded = !expanded; applyFold() }
        head.addView(drag)
        head.addView(titleTv)
        head.addView(menuBtn)
        head.addView(pauseBtn)
        head.addView(stopBtn)
        head.addView(eye)
        head.addView(foldBtn)

        // тело: текущее задание, одна главная кнопка, мелкие кнопки
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        promptTv = label(16f, Color.WHITE, true)
        subTv = label(12.5f, 0xFFE3ECFF.toInt())
        subTv.background = cardBg()
        subTv.setPadding(dp(10), dp(8), dp(10), dp(8))
        primaryBtn = big("", cGreen) { onPrimary() }
        rowA = newRow()
        rowB = newRow()
        rowC = newRow()
        rowD = newRow()
        b.addView(promptTv)
        b.addView(subTv)
        b.addView(primaryBtn)
        b.addView(rowA)
        b.addView(rowB)
        b.addView(rowC)
        b.addView(rowD)

        box.addView(head)
        box.addView(b, LinearLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            panelFlags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(8)
        panelLp = lp

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }

        wm.addView(box, lp)
        root = box
        body = b
        applyFold()
    }

    /** Плашка со статусом бота по центру сверху: видна прямо в игре, пока бот работает. */
    private fun showPill() {
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 12.5f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(14), dp(6), dp(14), dp(6))
        tv.background = bg(0xCC101820.toInt(), 16)
        tv.maxWidth = dp(420)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(6)
        tv.visibility = View.GONE
        wm.addView(tv, lp)
        pill = tv
    }

    private fun counters(): String =
        "🌾 $sPlants   🔪 $sHarv   💰 $sSales   ⚠ $sFails" + (if (cfg.barnCap > 0) "   📦 " + cfg.barnUsed + "/" + cfg.barnCap else "")

    private fun applyFold() {
        body?.visibility = if (expanded) View.VISIBLE else View.GONE
        foldBtn.text = if (expanded) "⌄" else "⌃"
    }

    private fun toggleMarks() {
        val mv = cap ?: return
        mv.showAll = !mv.showAll
        mv.invalidate()
        val g = ghost ?: return
        if (mv.showAll && hasRef()) {
            g.reload()
            g.setLevel(40)   // очень прозрачный снимок поля, чтобы сопоставить детали
            g.visibility = if (inGame) View.VISIBLE else View.GONE
        } else {
            g.setLevel(120)
            g.visibility = if (inGame && ghostOn) View.VISIBLE else View.GONE
        }
    }

    private fun updateUi() {
        ui.removeCallbacks(ticker)
        val running = mode == Mode.RUN || (busy && active)
        stopBtn.visibility = vis(running)
        pauseBtn.visibility = vis(running)
        pauseBtn.text = if (paused) "▶" else "⏸"
        pauseBtn.background = neon(if (paused) cGreen else cBlue, 12)
        cap?.swipeMode = false
        val inRect = mode == Mode.SETUP && !busy && FLOW[step].kind == Kind.RECT
        if (!inRect) {
            cap?.editMode = false
            cap?.editPts = null
        }
        menuBtn.visibility = vis(mode == Mode.SETUP && !busy)
        pill?.visibility = if (inGame && mode == Mode.RUN) View.VISIBLE else View.GONE

        if (mode == Mode.RUN) {
            titleTv.text = "🤖 Бот работает"
            promptTv.text = if (paused) "⏸ Пауза" else "Бот работает. Не трогай экран."
            subTv.text = note
            showPrimary(if (paused) "▶ Продолжить" else "⏸ Пауза", if (paused) cGreen else cBlue, true)
            clearRows()
            fillRow(rowA, listOf(Act("■ Стоп", cRed) { stopBot("Остановлено кнопкой") }))
            setArmed(false)
            return
        }
        if (busy) {
            titleTv.text = "TapTapBot's"
            promptTv.text = if (paused) "⏸ Пауза" else "⏳ Выполняю…"
            subTv.text = note
            primaryBtn.visibility = View.GONE
            clearRows()
            if (active) {
                fillRow(rowA, listOf(
                    Act(if (paused) "▶ Продолжить" else "⏸ Пауза", cBlue) { togglePause() },
                    Act("■ Стоп", cRed) { stopBot("Остановлено кнопкой") }
                ))
            }
            setArmed(false)
            return
        }
        when (mode) {
            Mode.MENU -> drawMenu()
            Mode.REC -> drawRec()
            else -> drawStep()
        }
        cap?.invalidate()
    }

    private fun showPrimary(t: String, color: Int, enabled: Boolean) {
        primaryBtn.visibility = View.VISIBLE
        primaryBtn.text = t
        primaryBtn.background = neon(color, 14)
        primaryBtn.alpha = if (enabled) 1f else 0.45f
    }

    // ---------- меню ----------

    private fun drawMenu() {
        when (menuPage) {
            1 -> drawSettings()
            2 -> drawTasks()
            3 -> drawSpeed()
            4 -> drawSilo()
            else -> drawHome()
        }
        setArmed(false)
    }

    private fun drawHome() {
        val ready = cfg.missingPair() == null
        titleTv.text = "TapTapBot's · Hay Day"
        promptTv.text = if (ready) "Готов к работе" else "Настройка не завершена"
        val grows = (0 until cfg.fieldCount).joinToString(", ") { "П" + (it + 1) + " " + fmt(cfg.grow(it)) }
        val sale = if (cfg.first(T.SHOP, 0) != null) "каждые " + cfg.sellEvery + " посадки" else "выкл"
        subTv.text = (if (note.isNotEmpty()) note + "\n\n" else "") +
            "🌾 Полей: " + cfg.fieldCount + "   ⏱ " + grows + "\n" +
            "🏪 Продажа: " + sale + "   🧩 Задач: " + cfg.macroCount() + "\n" +
            (if (barnOn()) "📦 Силос: занято " + cfg.barnUsed + " из " + cfg.barnCap + "\n" else "") +
            "🧪 " + modeName(cfg.plantMode) + "   👻 " + (if (hasRef()) "есть" else "нет")

        showPrimary(if (ready) "▶ Запустить" else "⚙ Настроить", if (ready) cGreen else cBlue, true)

        val a = ArrayList<Act>()
        if (ready) a.add(Act("⚙ Заново", cGray) { cfg.cur = 0; startSetup() })
        if (hasRef()) a.add(Act("👻", if (ghostOn) cGreen else cGray) { showGhost(!ghostOn); updateUi() })
        a.add(Act("⚡", cGray) { menuPage = 3; updateUi() })
        a.add(Act("⋯ Ещё", cGray) { menuPage = 1; updateUi() })
        fillRow(rowA, a)

        val b = ArrayList<Act>()
        if (ready && Build.VERSION.SDK_INT >= 30) {
            b.add(Act("📸 Эталон", cGray) {
                runTask("Снимаю эталон вида…", { captureRef() }, { enterMenu("📸 Эталон вида обновлён") })
            })
        }
        if (ready) {
            b.add(Act("🌱 Тест", cGray) {
                runTask("Тест посадки…", { plantOnce(cfg.cur); siloPlanted(cfg.cur) }, { enterMenu("🌱 Тест посадки выполнен") })
            })
            b.add(Act("🔪 Тест", cGray) {
                runTask("Тест сбора…", { harvestOnce(cfg.cur); siloHarvested(cfg.cur) }, { enterMenu("🔪 Тест сбора выполнен") })
            })
        }
        b.add(Act("📦", cGray) { menuPage = 4; updateUi() })
        fillRow(rowB, b)
        fillRow(rowC, listOf(Act("🐞 Скопировать debug", cGray) { copyDebug() }))
        fillRow(rowD, emptyList())
    }

    private fun drawSettings() {
        titleTv.text = "TapTapBot's · настройки"
        promptTv.text = "Настройки"
        val f = cfg.cur
        val shopOn = cfg.first(T.SHOP, 0) != null
        subTv.text = "📍 Поле " + (f + 1) + " из " + cfg.fieldCount + ": ⏱ " + fmt(cfg.grow(f)) + "\n" +
            "✋ Удержание " + (cfg.holdMs / 100) / 10.0 + " с   🧪 " + modeName(cfg.plantMode) + "\n" +
            "🏪 Продажа: " + (if (shopOn) "каждые " + cfg.sellEvery + " посадки, страниц " + cfg.shopPages else "выкл") + "\n" +
            "🎯 Распознавание: " + recText() + "\n" +
            "📷 Выравнивание камеры: " + (if (cfg.autoAlign) "вкл" else "выкл") +
            "   ↩ Палец назад: " + (if (cfg.returnHand > 0) "да" else "нет") + "\n" +
            "🧱 Отступ от краёв экрана: " + cfg.edgePct + "%"
        primaryBtn.visibility = View.GONE

        fillRow(rowA, listOf(
            Act("⏱ −", cGray) { cfg.setGrow(cfg.grow(cfg.cur) - 5); updateUi() },
            Act("⏱ +", cGray) { cfg.setGrow(cfg.grow(cfg.cur) + 5); updateUi() },
            Act("✋ −", cGray) { cfg.holdMs = cfg.holdMs - 100; updateUi() },
            Act("✋ +", cGray) { cfg.holdMs = cfg.holdMs + 100; updateUi() }
        ))

        val b = ArrayList<Act>()
        b.add(Act("🧱 −", cGray) { cfg.edgePct = cfg.edgePct - 2; updateUi() })
        b.add(Act("🧱 +", cGray) { cfg.edgePct = cfg.edgePct + 2; updateUi() })
        if (shopOn) {
            b.add(Act("🏪 −", cGray) { cfg.sellEvery = cfg.sellEvery - 1; updateUi() })
            b.add(Act("🏪 +", cGray) { cfg.sellEvery = cfg.sellEvery + 1; updateUi() })
            b.add(Act("📄 −", cGray) { cfg.shopPages = cfg.shopPages - 1; updateUi() })
            b.add(Act("📄 +", cGray) { cfg.shopPages = cfg.shopPages + 1; updateUi() })
        }
        fillRow(rowB, b)

        val c = ArrayList<Act>()
        c.add(Act("🧪 " + modeName(cfg.plantMode), cGray) { cfg.plantMode = cfg.plantMode + 1; updateUi() })
        if (Build.VERSION.SDK_INT >= 30) {
            c.add(Act("🎯", if (cfg.useRec) cGreen else cGray) { cfg.useRec = !cfg.useRec; updateUi() })
            c.add(Act("📷", if (cfg.autoAlign) cGreen else cGray) { cfg.autoAlign = !cfg.autoAlign; updateUi() })
        }
        c.add(Act("↩ Палец", if (cfg.returnHand > 0) cGreen else cGray) {
            cfg.returnHand = if (cfg.returnHand > 0) 0 else 1
            updateUi()
        })
        fillRow(rowC, c)

        val d = ArrayList<Act>()
        d.add(Act("📍 " + (f + 1), cGray) { cfg.cur = (cfg.cur + 1) % cfg.fieldCount; updateUi() })
        if (cfg.fieldCount < Cfg.MAXF) {
            d.add(Act("➕ Поле", cGray) { cfg.cur = cfg.fieldCount; startSetup() })
        }
        if (cfg.fieldCount > 1) {
            d.add(Act("🗑 " + cfg.fieldCount, cGray) { cfg.removeField(); updateUi() })
        }
        d.add(Act("🧩 ▸", cGray) { menuPage = 2; updateUi() })
        d.add(Act("‹ Назад", cGray) { menuPage = 0; updateUi() })
        fillRow(rowD, d)
    }

    private fun drawSpeed() {
        titleTv.text = "TapTapBot's · скорость"
        promptTv.text = "Скорость"
        subTv.text = "🌱 Посев: " + cfg.speedPlant + "%\n🔪 Сбор: " + cfg.speedHarvest + "%\n🏪 Лавка: " + cfg.speedShop + "%\n🟫 Прижим земли: " + (cfg.groundMs / 100) / 10.0 + " с\n" +
            "↔ Длина свайпа лавки: " + cfg.swipeLen + " px\n" +
            "Больше % = быстрее (палец и паузы). Если бот начал промахиваться, уменьши."
        primaryBtn.visibility = View.GONE
        fillRow(rowA, listOf(
            Act("🌱 −", cGray) { cfg.speedPlant = cfg.speedPlant - 100; updateUi() },
            Act("🌱 +", cGray) { cfg.speedPlant = cfg.speedPlant + 100; updateUi() }
        ))
        fillRow(rowB, listOf(
            Act("🔪 −", cGray) { cfg.speedHarvest = cfg.speedHarvest - 100; updateUi() },
            Act("🔪 +", cGray) { cfg.speedHarvest = cfg.speedHarvest + 100; updateUi() }
        ))
        fillRow(rowC, listOf(
            Act("🏪 −", cGray) { cfg.speedShop = cfg.speedShop - 10; updateUi() },
            Act("🏪 +", cGray) { cfg.speedShop = cfg.speedShop + 10; updateUi() },
            Act("↔ −", cGray) { cfg.swipeLen = cfg.swipeLen - 100; updateUi() },
            Act("↔ +", cGray) { cfg.swipeLen = cfg.swipeLen + 100; updateUi() }
        ))
        fillRow(rowD, listOf(
            Act("🟫 −", cGray) { cfg.groundMs = cfg.groundMs - 200; updateUi() },
            Act("🟫 +", cGray) { cfg.groundMs = cfg.groundMs + 200; updateUi() },
            Act("✨", if (cfg.trail) cGreen else cGray) { cfg.trail = !cfg.trail; updateUi() },
            Act("‹ Назад", cGray) { menuPage = 0; updateUi() }
        ))
    }

    private fun drawSilo() {
        titleTv.text = "TapTapBot's · силос"
        promptTv.text = "Силосная башня"
        subTv.text = "Занято: " + cfg.barnUsed + " из " + cfg.barnCap + "\nКлеток: " + cfg.cellsOf(0) + "   В слоте: " + cfg.perSlot + "\n" +
            "Сбор даёт ×" + cfg.perCell + " на клетку, посев тратит 1 на клетку. Поправь «занято», если не сходится."
        primaryBtn.visibility = View.GONE
        fillRow(rowA, listOf(
            Act("−100", cGray) { cfg.barnUsed = cfg.barnUsed - 100; updateUi() },
            Act("−10", cGray) { cfg.barnUsed = cfg.barnUsed - 10; updateUi() },
            Act("+10", cGray) { cfg.barnUsed = cfg.barnUsed + 10; updateUi() },
            Act("+100", cGray) { cfg.barnUsed = cfg.barnUsed + 100; updateUi() }
        ))
        fillRow(rowB, listOf(
            Act("слот −5", cGray) { cfg.perSlot = cfg.perSlot - 5; updateUi() },
            Act("слот −1", cGray) { cfg.perSlot = cfg.perSlot - 1; updateUi() },
            Act("слот +1", cGray) { cfg.perSlot = cfg.perSlot + 1; updateUi() },
            Act("слот +5", cGray) { cfg.perSlot = cfg.perSlot + 5; updateUi() }
        ))
        fillRow(rowC, listOf(
            Act("вмест. −100", cGray) { cfg.barnCap = cfg.barnCap - 100; updateUi() },
            Act("вмест. +100", cGray) { cfg.barnCap = cfg.barnCap + 100; updateUi() }
        ))
        fillRow(rowD, listOf(Act("‹ Назад", cGray) { menuPage = 0; updateUi() }))
    }

    private fun drawTasks() {
        titleTv.text = "TapTapBot's · задачи"
        promptTv.text = "Свои задачи"
        val n = cfg.macroCount()
        val lines = StringBuilder()
        for (m in 0 until n) {
            val iv = cfg.macroInterval(m)
            lines.append("🧩 ").append(m + 1).append(": ").append(cfg.macroTaps(m).size).append(" нажатий, ")
            lines.append(if (iv <= 0) "выключена" else "каждые $iv мин").append("\n")
        }
        if (n == 0) lines.append("Задач нет. Запиши любую последовательность нажатий (яйца, молоко, пекарня), и бот будет повторять её по таймеру.\n")
        lines.append("Кнопка с номером меняет интервал. В конце задачи верни игру в исходный вид.")
        subTv.text = lines.toString()
        primaryBtn.visibility = View.GONE

        val a = ArrayList<Act>()
        a.add(Act("🔴 Записать", cGray) { startRec() })
        if (n > 0) a.add(Act("🏃 Прогнать", cGray) {
            runTask("Выполняю задачи…", { for (m in 0 until cfg.macroCount()) playMacro(m) }, { enterMenu("🧩 Задачи выполнены") })
        })
        fillRow(rowA, a)

        val b = ArrayList<Act>()
        for (m in 0 until n) {
            val iv = cfg.macroInterval(m)
            b.add(Act("🧩" + (m + 1) + "·" + (if (iv <= 0) "выкл" else iv.toString() + "м"), cGray) { cycleInterval(m) })
        }
        fillRow(rowB, b)

        val c = ArrayList<Act>()
        if (n > 0) c.add(Act("🗑 Последняя", cGray) { cfg.deleteMacro(cfg.macroCount() - 1); updateUi() })
        c.add(Act("‹ Назад", cGray) { menuPage = 1; updateUi() })
        fillRow(rowC, c)
        fillRow(rowD, emptyList())
    }

    private fun cycleInterval(m: Int) {
        val ivs = intArrayOf(5, 10, 15, 30, 60, 0)
        val i = ivs.indexOf(cfg.macroInterval(m))
        cfg.setMacroInterval(m, ivs[(i + 1) % ivs.size])
        updateUi()
    }

    // ---------- запись своей задачи ----------

    private fun startRec() {
        if (cfg.macroCount() >= Cfg.MAXM) {
            toast("Максимум " + Cfg.MAXM + " задач")
            return
        }
        mode = Mode.REC
        recTaps.clear()
        recLast = 0L
        note = ""
        updateUi()
    }

    private fun drawRec() {
        titleTv.text = "🔴 Запись задачи"
        promptTv.text = "Нажимай в игре всё, что нужно"
        subTv.text = "Записано нажатий: " + recTaps.size + "\n" +
            "Каждое нажатие выполняется в игре, паузы между ними запоминаются. В конце верни игру в исходный вид: закрой окна и меню."
        showPrimary("✔ Сохранить задачу", cGreen, recTaps.isNotEmpty())
        fillRow(rowA, listOf(Act("✖ Отмена", cGray) { cancelRec() }))
        fillRow(rowB, emptyList())
        fillRow(rowC, emptyList())
        fillRow(rowD, emptyList())
        setArmed(true)
    }

    private fun cancelRec() {
        recTaps.clear()
        mode = Mode.MENU
        menuPage = 2
        updateUi()
    }

    private fun saveRec() {
        if (recTaps.isEmpty()) {
            note = "⚠ Пока нет ни одного нажатия"
            updateUi()
            return
        }
        val idx = cfg.saveMacro(ArrayList(recTaps))
        if (idx < 0) {
            toast("Максимум " + Cfg.MAXM + " задач")
        } else {
            toast("🧩 Задача " + (idx + 1) + " сохранена: каждые " + cfg.macroInterval(idx) + " мин")
            jlog("🧩 Записана задача " + (idx + 1) + ": " + recTaps.size + " нажатий")
        }
        recTaps.clear()
        mode = Mode.MENU
        menuPage = 2
        updateUi()
    }

    // ---------- мастер ----------

    /** Стартовая рамка: квадрат посередине экрана. */
    private fun defaultRect(): MutableList<P> {
        val cx = screenW() / 2f
        val cy = screenH() / 2f
        val h = screenH() * 0.22f
        return mutableListOf(P(cx - h, cy - h), P(cx + h, cy - h), P(cx + h, cy + h), P(cx - h, cy + h))
    }

    private fun numGet(k: String): Int = when (k) {
        "used" -> cfg.barnUsed
        "cap" -> cfg.barnCap
        "slot" -> cfg.perSlot
        else -> cfg.cellsOf(cfg.cur)
    }

    private fun numAdd(k: String, d: Int) {
        val v = (numGet(k) + d).coerceAtLeast(0)
        when (k) {
            "used" -> cfg.barnUsed = v
            "cap" -> cfg.barnCap = v
            "slot" -> cfg.perSlot = v
            else -> cfg.setCells(cfg.cur, v)
        }
        updateUi()
    }

    private fun drawStep() {
        val s = FLOW[step]
        val r = s.role
        val n = if (r != null) cfg.list(r).size else 0
        val keep = if (s.fresh) 0 else 1
        val fp = if (cfg.cur > 0 || cfg.fieldCount > 1) "Поле " + (cfg.cur + 1) + " · " else ""

        titleTv.text = fp + "шаг " + (step + 1) + " из " + FLOW.size
        promptTv.text = if (s.kind == Kind.NUM) s.text + "\n👉 " + numGet(s.act ?: "") else s.text
        val base = if (note.isNotEmpty()) note else s.hint
        subTv.text = when {
            r == T.AREA ->
                "$base\nШаг строк: " + cfg.rowGap + " px (➖ чаще · ➕ реже)"
            s.kind == Kind.MULTI && s.max > 0 -> "Точек: $n из " + s.max + "\n$base"
            s.kind == Kind.MULTI -> "Точек: $n\n$base"
            else -> base
        }

        if (s.btn != null) {
            showPrimary(s.btn, if (s.kind == Kind.DO) cBlue else cGreen, !(s.kind == Kind.MULTI && n < s.min))
        } else {
            primaryBtn.visibility = View.GONE
        }

        val canErase = s.kind == Kind.MULTI && n > keep
        val a = ArrayList<Act>()
        if (canErase || prevIndex() >= 0) a.add(Act("↩ Назад", cGray) { back() })
        if (canErase) a.add(Act("🗑 Всё", cGray) { clearAll() })
        if (s.kind == Kind.RECT) a.add(Act("⟲ Сброс рамки", cGray) { cap?.editPts = defaultRect(); updateUi() })
        if (s.skip != null) a.add(Act(s.skip, cGray) { onSkip() })
        if (s.kind == Kind.SWIPE) {
            showPrimary("↔ Свайп вперёд", cBlue, true)
            a.add(Act("↔ Назад", cGray) { testSwipe(false) })
            a.add(Act("✅ Работает ▶", cGreen) { advance() })
        }
        fillRow(rowA, a)

        val b = ArrayList<Act>()
        if (r == T.AREA) {
            b.add(Act("➖ чаще", cGray) { adjustGap(-5) })
            b.add(Act("➕ реже", cGray) { adjustGap(5) })
        }
        if (s.kind == Kind.SWIPE) {
            b.add(Act("Короче", cGray) { cfg.swipeLen = cfg.swipeLen - 100; updateUi() })
            b.add(Act("Длиннее", cGray) { cfg.swipeLen = cfg.swipeLen + 100; updateUi() })
        }
        fillRow(rowB, b)
        fillRow(rowC, emptyList())
        fillRow(rowD, emptyList())
        if (s.kind == Kind.NUM) {
            val key = s.act ?: ""
            fillRow(rowC, listOf(
                Act("−1000", cGray) { numAdd(key, -1000) },
                Act("−100", cGray) { numAdd(key, -100) },
                Act("−10", cGray) { numAdd(key, -10) },
                Act("−1", cGray) { numAdd(key, -1) }
            ))
            fillRow(rowD, listOf(
                Act("+1", cGray) { numAdd(key, 1) },
                Act("+10", cGray) { numAdd(key, 10) },
                Act("+100", cGray) { numAdd(key, 100) },
                Act("+1000", cGray) { numAdd(key, 1000) }
            ))
        }

        cap?.swipeMode = s.kind == Kind.SWIPE
        cap?.focus = s.role
        if (s.kind == Kind.RECT) {
            val mv = cap
            if (mv != null) {
                if (mv.editPts == null) mv.editPts = defaultRect()
                mv.editMode = true
            }
        }
        setArmed(s.kind == Kind.TAP || s.kind == Kind.MULTI || s.kind == Kind.RECT)
        if (s.kind == Kind.WAIT) ui.post(ticker)
    }

    private fun say(m: String) {
        ui.post {
            note = m
            if (botMode) {
                val pre = if (paused) "⏸ " else ""
                titleTv.text = "🤖 $pre$m"
                pill?.text = pre + m + "\n" + counters()
            }
            subTv.text = m
        }
    }

    // ---------- переходы ----------

    private fun enterMenu(msg: String = "") {
        mode = Mode.MENU
        menuPage = 0
        note = msg
        updateUi()
    }

    private fun startSetup() {
        go(nextIndex(0))
    }

    private fun skipped(i: Int): Boolean {
        val s = FLOW[i]
        if (cfg.cur > 0 && (s.kind == Kind.INFO || i >= I_ASK || s.role == T.GROUND || (s.kind == Kind.NUM && s.act != "cells"))) return true
        return false
    }

    private fun nextIndex(from: Int): Int {
        var k = from
        while (k < FLOW.size && skipped(k)) k++
        return k
    }

    private fun prevIndex(): Int {
        var k = step - 1
        while (k >= 0 && skipped(k)) k--
        return k
    }

    private fun go(n: Int) {
        mode = Mode.SETUP
        step = n.coerceIn(0, FLOW.size - 1)
        swipeDone = false
        note = ""
        val s = FLOW[step]
        val r = s.role
        if (r != null && s.fresh) cfg.clear(r)
        updateUi()
    }

    private fun advance() {
        val n = nextIndex(step + 1)
        if (n >= FLOW.size) {
            if (cfg.cur >= cfg.fieldCount) cfg.fieldCount = cfg.cur + 1
            jlog("Настройка поля " + (cfg.cur + 1) + " завершена")
            enterMenu(
                if (cfg.cur > 0) "✅ Поле " + (cfg.cur + 1) + " настроено."
                else "✅ Настройка завершена. Жми «▶ Запустить»."
            )
        } else {
            go(n)
        }
    }

    private fun back() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role
        if (s.kind == Kind.MULTI && r != null) {
            val keep = if (s.fresh) 0 else 1
            if (cfg.list(r).size > keep) {
                cfg.removeLast(r)
                note = "↩ Последняя точка стёрта"
                updateUi()
                return
            }
        }
        val p = prevIndex()
        if (p >= 0) go(p) else enterMenu()
    }

    private fun clearAll() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role ?: return
        if (s.kind == Kind.MULTI) {
            cfg.truncate(r, if (s.fresh) 0 else 1)
            note = "🗑 Точки стёрты"
            updateUi()
        }
    }

    private fun adjustGap(d: Int) {
        if (busy || botMode) return
        cfg.rowGap = cfg.rowGap + d
        updateUi()
    }

    private fun onPrimary() {
        if (mode == Mode.RUN) {
            togglePause()
            return
        }
        if (busy) return
        if (mode == Mode.REC) {
            saveRec()
            return
        }
        if (mode == Mode.MENU) {
            if (cfg.missingPair() == null) startBot() else {
                cfg.cur = 0
                startSetup()
            }
            return
        }
        val s = FLOW[step]
        when (s.kind) {
            Kind.MULTI -> {
                val r = s.role
                val n = if (r != null) cfg.list(r).size else 0
                if (n < s.min) {
                    note = "⚠ Нужно минимум " + s.min + " точки"
                    updateUi()
                } else {
                    advance()
                }
            }
            Kind.WAIT -> {
                if (plantedAt > 0) {
                    val sec = ((System.currentTimeMillis() - plantedAt) / 1000).toInt() + 3
                    if (sec < 90) {
                        note = "⚠ Прошло только " + fmt(sec) + ". Пшеница растёт около 2 минут: жми, когда она правда созреет"
                        updateUi()
                        return
                    }
                    cfg.setGrow(sec)
                    toast("⏱ Время созревания: " + fmt(cfg.grow(cfg.cur)))
                }
                advance()
            }
            Kind.RECT -> {
                val mv = cap
                val pts = mv?.editPts
                if (mv == null || pts == null || pts.size < 4) {
                    note = "⚠ Рамка не готова"
                    updateUi()
                } else {
                    cfg.clear(T.AREA)
                    for (p in pts) cfg.add(T.AREA, p)
                    mv.editPts = null
                    mv.editMode = false
                    advance()
                }
            }
            Kind.SWIPE -> testSwipe(true)
            Kind.ASK, Kind.INFO, Kind.NUM -> {
                if (s.act == "onepage" && cfg.shopPages < 2) cfg.shopPages = 2
                advance()
            }
            Kind.DO -> doAction(s.act ?: "")
            else -> {}
        }
    }

    private fun onSkip() {
        if (busy || botMode) return
        when (FLOW[step].kind) {
            Kind.ASK -> {
                cfg.clear(T.SHOP)
                enterMenu("✅ Настройка завершена (без продажи). Жми «▶ Запустить».")
            }
            Kind.DO -> {
                val ci = FLOW.indexOfFirst { it.role == T.CLOSE }
                if (ci >= 0) go(ci) else advance()
            }
            Kind.INFO -> {
                if (FLOW[step].act == "onepage") {
                    cfg.shopPages = 1
                    val ci = FLOW.indexOfFirst { it.role == T.CLOSE }
                    if (ci >= 0) go(ci) else advance()
                } else {
                    advance()
                }
            }
            else -> advance()
        }
    }

    // ---------- нажатия пользователя ----------

    private fun onTapped(x: Float, y: Float) {
        if (busy || (mode != Mode.SETUP && mode != Mode.REC)) return
        val p = P(x, y)

        if (mode == Mode.REC) {
            val now = System.currentTimeMillis()
            val dt = if (recLast == 0L) 700L else (now - recLast).coerceIn(600L, 8000L)
            recTaps.add(MTap(p, dt))
            recLast = now
            busy = true
            setArmed(false)
            replayTap(p, 700) {
                busy = false
                recLast = System.currentTimeMillis()
                updateUi()
            }
            return
        }

        val s = FLOW[step]
        if (s.kind == Kind.SWIPE) {
            note = "Нужен свайп: проведи пальцем по слотам"
            updateUi()
            return
        }
        if (s.kind != Kind.TAP && s.kind != Kind.MULTI) return
        val r = s.role
        if (r != null) {
            if (s.kind == Kind.MULTI && s.max > 0 && cfg.list(r).size >= s.max) {
                note = "Уже " + s.max + " точки. Жми «Готово» или ↩"
                updateUi()
                return
            }
            cfg.add(r, p)
        }
        if (s.kind == Kind.MULTI) {
            note = if (r == T.AREA && nearEdge(p)) {
                "⚠ Угол у края экрана: игра будет двигать карту. Лучше сдвинь камеру, чтобы поле было ближе к центру (🏠 → настроить заново)"
            } else {
                "✔ Запомнил"
            }
        }

        if (s.sample && r != null && cfg.useRec && Build.VERSION.SDK_INT >= 30) {
            // сначала убираем жёлтую подсветку, потом снимаем эталон цвета, потом повторяем нажатие
            busy = true
            setArmed(false)
            Thread {
                try { Thread.sleep(200) } catch (_: InterruptedException) {}
                val c = colorAt(p)
                val pat = if (c != null && r == T.ITEM) grabPatch(p) else null
                ui.post {
                    if (pat != null) cfg.setWheatPatch(pat)
                    if (c != null) {
                        cfg.setRef(r, c)
                        toast("🎯 Эталон цвета записан")
                    } else {
                        toast("⚠ Эталон не записался, попробуй ещё раз")
                    }
                    finishTap(s, p)
                }
            }.start()
            return
        }
        finishTap(s, p)
    }

    /** Пользователь провёл пальцем в шаге листания лавки: повторяем свайп в игре по-настоящему и проверяем по картинке. */
    private fun onSwiped(a: P, b: P, ms: Long) {
        if (busy || mode != Mode.SETUP) return
        if (FLOW[step].kind != Kind.SWIPE) return
        cfg.clear(T.SWIPE)
        cfg.add(T.SWIPE, a)
        cfg.add(T.SWIPE, b)
        cfg.swipeMs = ms.toInt()
        runSwipeOnce()
    }

    private fun runSwipeOnce() {
        val sw = cfg.list(T.SWIPE, 0)
        if (sw.size < 2) return
        val a = sw[0]
        val b = sw[1]
        runTask("Листаю лавку…", { pause(350); gentleSwipe(a, b, cfg.swipeMs.toLong()); pause(1000) }, {
            swipeDone = true
            note = "Лавка пролистнулась? Если да, жми зелёную кнопку. Если нет: «Ещё раз» или проведи заново"
            updateUi()
        })
    }

    private fun screenW(): Int =
        if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.width() else resources.displayMetrics.widthPixels

    private fun screenH(): Int =
        if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.height() else resources.displayMetrics.heightPixels

    /** Точка в зоне краёв экрана, где игра сама прокручивает карту. */
    private fun nearEdge(p: P): Boolean {
        val e = cfg.edgePct
        if (e <= 0) return false
        val w = screenW().toFloat()
        val h = screenH().toFloat()
        return p.x < w * e / 100f || p.x > w * (1f - e / 100f) || p.y < h * e * 1.15f / 100f || p.y > h * (1f - e * 1.15f / 100f)
    }

    private fun finishTap(s: Stp, p: P) {
        if (s.replay) {
            busy = true
            setArmed(false)
            replayTap(p, s.settle) {
                busy = false
                if (s.kind == Kind.TAP) advance() else updateUi()
            }
        } else {
            busy = false
            if (s.kind == Kind.TAP) advance() else updateUi()
        }
    }

    /** Повторяет нажатие пользователя в игре (слой уже стал прозрачным для касаний). */
    private fun replayTap(p: P, settle: Long, then: () -> Unit) {
        trailPath(listOf(p), 450)
        ui.postDelayed({
            val path = Path()
            path.moveTo(p.x, p.y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            val cb = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ui.postDelayed({ then() }, settle) }
                override fun onCancelled(d: GestureDescription?) { ui.postDelayed({ then() }, 300) }
            }
            if (!dispatchGesture(g, cb, null)) ui.postDelayed({ then() }, 300)
        }, 180)
    }

    // ---------- задачи бота вне основного цикла ----------

    private fun runTask(msg: String, work: () -> Unit, done: () -> Unit) {
        if (busy || botMode) return
        busy = true
        active = true
        taskAborted = false
        paused = false
        note = msg
        setArmed(false)
        updateUi()
        worker = Thread {
            try {
                work()
            } catch (_: InterruptedException) {
            } catch (e: Throwable) {
                jlog("💥 Ошибка в задаче: " + e)
                toast("Ошибка: " + (e.message ?: e.javaClass.simpleName))
            } finally {
                active = false
                ui.post {
                    busy = false
                    paused = false
                    if (taskAborted) {
                        taskAborted = false
                        enterMenu("⏹ Остановлено")
                    } else {
                        done()
                    }
                }
            }
        }.also { it.start() }
    }

    private fun doAction(act: String) {
        when (act) {
            "plant" -> runTask(
                "Сажаю по области…",
                { plantOnce(cfg.cur); siloPlanted(cfg.cur); plantedAt = System.currentTimeMillis() },
                { advance() }
            )
            "harvest" -> runTask(
                "Собираю по области…",
                { harvestOnce(cfg.cur); siloHarvested(cfg.cur); pause(800); if (cfg.cur == 0) captureRef() },
                { advance() }
            )
            "swipe2" -> {
                val sw = cfg.list(T.SWIPE, 0)
                if (sw.size < 2) {
                    advance()
                } else {
                    val a = sw[0]
                    val b = sw[1]
                    runTask("Листаю лавку дальше…", { pause(300); gentleSwipe(a, b, cfg.swipeMs.toLong()); pause(1000) }, {
                        if (cfg.shopPages < 3) cfg.shopPages = 3
                        advance()
                    })
                }
            }
        }
    }

    // ---------- основной цикл ----------

    private fun startBot() {
        val m = cfg.missingPair()
        if (m != null) {
            cfg.cur = m.first
            val i = FLOW.indexOfFirst { it.role == m.second }
            go(if (i >= 0) i else 0)
            note = "⚠ Не хватает: " + m.second.icon + " " + m.second.label + " (поле " + (m.first + 1) + ")"
            updateUi()
            return
        }
        mode = Mode.RUN
        busy = false
        active = true
        paused = false
        gestureFails = 0
        stopReason = null
        sPlants = 0
        sHarv = 0
        sSales = 0
        sFails = 0
        runStart = System.currentTimeMillis()
        for (i in lastMacro.indices) lastMacro[i] = runStart
        stats.add("runs")
        jlog("▶ Запуск: полей " + cfg.fieldCount + ", задач " + cfg.macroCount() + ", посадка: " + modeName(cfg.plantMode))
        showGhost(false)
        cap?.showAll = false   // в работе никакой разметки поверх игры
        cap?.invalidate()
        note = "Запускаю…"
        expanded = false          // панель сворачивается, чтобы не закрывать игру
        applyFold()
        keepAwake(true)
        setArmed(false)
        updateUi()
        pill?.text = "Запускаю…\n" + counters()
        worker = Thread {
            try {
                loop()
            } catch (_: InterruptedException) {
            } catch (e: Throwable) {
                jlog("💥 Ошибка в цикле: " + e)
                if (stopReason == null) stopReason = "Ошибка: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                active = false
                paused = false
                val why = stopReason ?: "Бот остановлен"
                stopReason = null
                stats.add("runMs", System.currentTimeMillis() - runStart)
                jlog("⏹ $why. " + counters())
                ui.post {
                    keepAwake(false)
                    expanded = true
                    applyFold()
                    enterMenu("⏹ $why")
                }
            }
        }.also { it.start() }
    }

    private fun togglePause() {
        if (!active) return
        paused = !paused
        val msg = if (paused) "⏸ Пауза: остановлюсь после текущего действия" else "▶ Продолжаю"
        jlog(msg)
        note = msg
        pill?.text = msg + "\n" + counters()
        updateUi()
    }

    private fun waitIfPaused() {
        while (paused && active) Thread.sleep(150)
    }

    private fun stopBot(reason: String? = null) {
        if (reason != null) stopReason = reason
        if (mode != Mode.RUN) taskAborted = true
        paused = false
        active = false
        worker?.interrupt()
    }

    private fun sp(ms: Long, pct: Int): Long = (ms * 100L / pct.coerceIn(30, 400)).coerceAtLeast(50L)

    private fun plantOnce(f: Int) {
        ensureShopClosed()
        val pct = cfg.speedPlant
        val fld = cfg.first(T.FIELD, f)!!
        tap(fld)
        pause(sp(1500, pct.coerceAtMost(100)))   // меню открывается, камера доезжает до места
        holdDrag(cfg.first(T.WHEAT, f)!!, cfg.pathFrom(fld, f), fld, pct, groundStroke(), cfg.first(T.GROUND, 0))
        pause(sp(900, pct.coerceAtMost(100)))
    }

    /** Прижим пустой земли после посева: стартует прямо в колбэке конца прошлого жеста, без паузы. */
    private fun groundStroke(): GestureDescription.StrokeDescription? {
        val g = cfg.first(T.GROUND, 0) ?: return null
        val p = Path()
        p.moveTo(g.x, g.y)
        return GestureDescription.StrokeDescription(p, 0, cfg.groundMs.toLong())
    }

    private fun playChained(first: GestureDescription.StrokeDescription, next: GestureDescription.StrokeDescription, nextPt: P?, nextMs: Long) {
        val latch = CountDownLatch(1)
        val g1 = GestureDescription.Builder().addStroke(first).build()
        val g2 = GestureDescription.Builder().addStroke(next).build()
        val cb2 = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }
        val cb1 = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                if (nextPt != null) trailPath(listOf(nextPt), nextMs)
                if (!dispatchGesture(g2, cb2, null)) latch.countDown()
            }

            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }
        ui.post { if (!dispatchGesture(g1, cb1, null)) latch.countDown() }
        latch.await(75, TimeUnit.SECONDS)
    }

    private fun harvestOnce(f: Int) {
        ensureShopClosed()
        val pct = cfg.speedHarvest
        val fld = cfg.first(T.HFIELD, f)!!
        tap(fld)
        pause(sp(1500, pct.coerceAtMost(100)))
        holdDrag(cfg.first(T.SICKLE, f)!!, cfg.pathFrom(fld, f), fld, pct)
        pause(sp(1500, pct.coerceAtMost(100)))
    }

    // ---------- выравнивание камеры по картинке ----------

    private fun toGray(bmp: Bitmap, w: Int): Gray {
        val h = (bmp.height * w.toFloat() / bmp.width).toInt()
        val sc = Bitmap.createScaledBitmap(bmp, w, h, true)
        val px = IntArray(w * h)
        sc.getPixels(px, 0, w, 0, 0, w, h)
        if (sc !== bmp) sc.recycle()
        val d = IntArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            d[i] = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
        }
        return Gray(w, h, d)
    }

    private fun loadRefGray(): Gray? {
        val f = File(filesDir, "ref.png")
        if (!f.exists()) return null
        val b = BitmapFactory.decodeFile(f.path) ?: return null
        val g = toGray(b, b.width)
        b.recycle()
        return g
    }

    private fun variance(g: Gray, cx: Int, cy: Int, half: Int): Int {
        var sum = 0L
        var sq = 0L
        var n = 0
        for (y in -half until half step 4) {
            for (x in -half until half step 4) {
                val v = g.d[(cy + y) * g.w + cx + x]
                sum += v
                sq += (v * v).toLong()
                n++
            }
        }
        val mean = sum / n
        return ((sq / n) - mean * mean).toInt()
    }

    /** Ищет, куда сместился кусочек эталона на текущей картинке. Возвращает сдвиг или null, если пик неуверенный. */
    private fun matchTile(ref: Gray, cur: Gray, cx: Int, cy: Int, half: Int, rad: Int): Pair<Int, Int>? {
        fun ssdAt(ox: Int, oy: Int): Long {
            var ssd = 0L
            for (y in -half until half step 2) {
                val rb = (cy + y) * ref.w + cx
                val cb = (cy + y + oy) * cur.w + cx + ox
                for (x in -half until half step 2) {
                    val d = ref.d[rb + x] - cur.d[cb + x]
                    ssd += (d * d).toLong()
                }
            }
            return ssd
        }
        var best = Long.MAX_VALUE
        var bx = 0
        var by = 0
        var sum = 0L
        var cnt = 0
        for (oy in -rad..rad step 2) {
            for (ox in -rad..rad step 2) {
                val v = ssdAt(ox, oy)
                sum += v
                cnt++
                if (v < best) {
                    best = v
                    bx = ox
                    by = oy
                }
            }
        }
        var rb = best
        var rx = bx
        var ry = by
        for (oy in by - 1..by + 1) {
            for (ox in bx - 1..bx + 1) {
                if (ox < -rad || ox > rad || oy < -rad || oy > rad) continue
                val v = ssdAt(ox, oy)
                if (v < rb) {
                    rb = v
                    rx = ox
                    ry = oy
                }
            }
        }
        val mean = sum / cnt
        if (rb * 100 >= mean * 35) return null
        return Pair(rx, ry)
    }

    private fun median(v: List<Float>): Float {
        val s = v.sorted()
        return s[s.size / 2]
    }

    /** Общий сдвиг картинки относительно эталона (в пикселях эталона) по самым «рельефным» участкам середины экрана. */
    private fun estimateShift(ref: Gray, cur: Gray): Pair<Float, Float>? {
        if (ref.w != cur.w || ref.h != cur.h) return null
        val half = 24
        val rad = 48
        val margin = half + rad
        val x0 = (ref.w * 0.20f).toInt() + margin
        val x1 = (ref.w * 0.80f).toInt() - margin
        val y0 = (ref.h * 0.16f).toInt() + margin
        val y1 = (ref.h * 0.82f).toInt() - margin
        if (x1 < x0 || y1 < y0) return null
        val tiles = ArrayList<IntArray>()
        var cy = y0
        while (cy <= y1) {
            var cx = x0
            while (cx <= x1) {
                tiles.add(intArrayOf(cx, cy, variance(ref, cx, cy, half)))
                cx += half * 2
            }
            cy += half * 2
        }
        tiles.sortByDescending { it[2] }
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        for (t in tiles.take(10)) {
            if (t[2] < 150) continue
            val r = matchTile(ref, cur, t[0], t[1], half, rad) ?: continue
            xs.add(r.first.toFloat())
            ys.add(r.second.toFloat())
        }
        if (xs.size < 3) return null
        val mx = median(xs)
        val my = median(ys)
        var agree = 0
        for (i in xs.indices) if (abs(xs[i] - mx) <= 3f && abs(ys[i] - my) <= 3f) agree++
        if (agree < 3 || agree * 100 / xs.size < 60) return null
        return Pair(mx, my)
    }

    /**
     * Сравнивает экран с эталонным видом и, если карта сместилась, тянет её обратно медленным свайпом.
     * true: камера на месте или проверить нельзя. false: съехала и вернуть не удалось.
     */
    private fun alignCamera(): Boolean {
        if (!cfg.autoAlign || !cfg.useRec || Build.VERSION.SDK_INT < 30) return true
        val ref = loadRefGray() ?: return true
        pause(1200)   // камера после действия ещё может доезжать, даём ей остановиться
        val b = wm.maximumWindowMetrics.bounds
        val k = b.width().toFloat() / ref.w
        for (attempt in 0..2) {
            if (!active) return true
            val bmp = takeBitmap() ?: return true
            val cur = toGray(bmp, ref.w)
            bmp.recycle()
            val sh = estimateShift(ref, cur) ?: return true   // оценить не удалось, не мешаем
            val dx = sh.first * k
            val dy = sh.second * k
            val mag = hypot(dx, dy)
            if (mag < 30f) return true   // мелкие сдвиги не трогаем: короткий свайп игра приняла бы за нажатие на грядку
            if (attempt == 2) return mag < 60f
            say("📷 Камера сместилась на " + mag.toInt() + " px, возвращаю")
            jlog("📷 Сдвиг камеры " + dx.toInt() + "," + dy.toInt() + " px, подтягиваю обратно")
            // содержимое ушло на (dx, dy), значит палец должен пройти на (-dx, -dy)
            panMap(-dx, -dy)
            pause(900)
        }
        return true
    }

    /**
     * Двигает карту так, чтобы содержимое сместилось на (vx, vy). Короткий свайп игра принимает за нажатие
     * на грядку под пальцем, поэтому для малых сдвигов палец делает крюк подальше и возвращается.
     */
    private fun panMap(vx: Float, vy: Float) {
        val len = hypot(vx, vy)
        val cx = screenW() / 2f
        val cy = screenH() / 2f
        if (len >= 160f || Build.VERSION.SDK_INT < 26) {
            gentleSwipe(P(cx - vx / 2f, cy - vy / 2f), P(cx + vx / 2f, cy + vy / 2f), (500 + len * 3).toLong())
            return
        }
        waitIfPaused()
        val ux = vx / len
        val uy = vy / len
        val far = 180f
        val sx = cx - (ux * far + vx) / 2f
        val sy = cy - (uy * far + vy) / 2f
        val ax = sx + ux * far
        val ay = sy + uy * far
        val ex = sx + vx
        val ey = sy + vy
        trailPath(listOf(P(sx, sy), P(ax, ay), P(ex, ey)), 1400)
        val p1 = Path()
        p1.moveTo(sx, sy)
        p1.lineTo(ax, ay)
        val s1 = GestureDescription.StrokeDescription(p1, 0, 550, true)
        play(s1)
        val p2 = Path()
        p2.moveTo(ax, ay)
        p2.lineTo(ex, ey)
        val s2 = s1.continueStroke(p2, 0, 650, true)
        play(s2)
        val p3 = Path()
        p3.moveTo(ex, ey)
        play(s2.continueStroke(p3, 0, 200, false))
    }

    private fun afterAction(): Boolean {
        if (!active) return false
        if (alignCamera()) return true
        cameraMismatch()
        return false
    }

    /** Камера не там: показываем призрак эталона и останавливаемся. Двигать камеру автоматически не пытаемся. */
    private fun cameraMismatch() {
        sFails++
        stats.add("fails")
        ui.post { if (hasRef()) showGhost(true) }
        stopBot("Камера не совпала с эталоном. Совмести картинку с 👻 и жми «▶ Запустить»")
    }

    private fun siloOn(f: Int): Boolean = cfg.barnCap > 0 && cfg.cellsOf(f) > 0

    /** Посев тратит по 1 пшенице на клетку. */
    private fun siloPlanted(f: Int) {
        if (siloOn(f)) cfg.barnUsed = max(0, cfg.barnUsed - cfg.cellsOf(f))
    }

    /** Сбор даёт перCell пшеницы с клетки. */
    private fun siloHarvested(f: Int) {
        if (siloOn(f)) cfg.barnUsed = cfg.barnUsed + cfg.cellsOf(f) * cfg.perCell
    }

    private fun barnOn(): Boolean = cfg.barnCap > 0 && cfg.cellsOf(0) > 0 && cfg.first(T.SHOP, 0) != null

    /** Нужна ли продажа: по заполнению амбара (если заданы числа) или раз в N посадок. false — остановить бота. */
    private fun saleCheck(plants: Int, sellOn: Boolean, every: Int): Boolean {
        if (!sellOn) return true
        if (barnOn()) {
            val harvest = (0 until cfg.fieldCount).maxOf { cfg.cellsOf(it) } * cfg.perCell
            val room = cfg.barnCap - cfg.barnUsed
            if (room >= harvest) return true
            say("📦 В силосе мало места (свободно $room, нужно $harvest): продаю")
            jlog("📦 Мало места: свободно $room, нужно $harvest. Продажа с рекламой")
            return doSale(plants, true)
        }
        return if (plants % every == 0) doSale(plants, false) else true
    }

    private fun doSale(round: Int, force: Boolean = false): Boolean {
        val sold = sell(round, force)
        ensureShopClosed()
        if (sold) {
            if (barnOn()) cfg.barnUsed = max(0, cfg.barnUsed - lastSold * cfg.perSlot)
            fails = 0
        } else {
            fails++
            sFails++
            stats.add("fails")
        }
        if (fails >= 3) {
            stopBot("3 сбоя продажи подряд")
            return false
        }
        return afterAction()
    }

    private fun loop() {
        val n = cfg.fieldCount
        val tp = LongArray(n)
        val sellOn = cfg.first(T.SHOP, 0) != null
        val every = cfg.sellEvery
        var plants = 0
        fails = 0

        // первая посадка на всех полях
        for (f in 0 until n) {
            if (!active) return
            say("Поле " + (f + 1) + ": посадка 🌾")
            jlog("🌾 Посадка поля " + (f + 1) + ", силос " + cfg.barnUsed + "/" + cfg.barnCap)
            plantOnce(f)
            siloPlanted(f)
            tp[f] = System.currentTimeMillis()
            if (!afterAction()) return
            sPlants++
            stats.add("plants")
            plants++
            if (!saleCheck(plants, sellOn, every)) return
        }

        // дальше по кругу: берём поле, которое созреет раньше всех
        while (active) {
            var nf = 0
            for (f in 1 until n) if (tp[f] + growMs(f) < tp[nf] + growMs(nf)) nf = f
            waitRipe(nf, tp[nf])
            if (!active) return
            say("Поле " + (nf + 1) + ": сбор 🔪")
            jlog("🔪 Сбор поля " + (nf + 1))
            harvestOnce(nf)
            sHarv++
            stats.add("harvests")
            siloHarvested(nf)
            if (!afterAction()) return
            pause(Random.nextLong(0, 500))
            say("Поле " + (nf + 1) + ": посадка 🌾")
            jlog("🌾 Посадка поля " + (nf + 1) + ", силос " + cfg.barnUsed + "/" + cfg.barnCap)
            plantOnce(nf)
            siloPlanted(nf)
            tp[nf] = System.currentTimeMillis()
            if (!afterAction()) return
            sPlants++
            stats.add("plants")
            plants++
            if (!saleCheck(plants, sellOn, every)) return
        }
    }

    /** Ждёт созревания поля f по таймеру. Между делом запускает свои задачи. */
    private fun waitRipe(f: Int, tPlant: Long) {
        idleUntil(tPlant + growMs(f) + Random.nextLong(0, 4000), "Поле " + (f + 1) + ": растёт ⏳")
    }

    private fun idleUntil(end: Long, label: String, shownEnd: Long = end) {
        while (active && System.currentTimeMillis() < end) {
            val left = end - System.currentTimeMillis()
            say(label + " " + fmt(((shownEnd - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)))
            pause(minOf(left, 1000L))
            if (active && !runMacros()) return
        }
    }

    // ---------- свои задачи ----------

    /** Запускает задачи, у которых подошло время. */
    private fun runMacros(): Boolean {
        val n = cfg.macroCount()
        for (m in 0 until n) {
            val iv = cfg.macroInterval(m)
            if (iv <= 0) continue
            if (System.currentTimeMillis() - lastMacro[m] < iv * 60_000L) continue
            playMacro(m)
            lastMacro[m] = System.currentTimeMillis()
        }
        return true
    }

    private fun playMacro(m: Int) {
        val taps = cfg.macroTaps(m)
        say("🧩 Задача " + (m + 1) + "…")
        jlog("🧩 Задача " + (m + 1) + ": " + taps.size + " нажатий")
        stats.add("macros")
        for (t in taps) {
            if (!active) return
            pause(t.dtMs)
            tap(t.p)
        }
        pause(900)
    }

    // ---------- продажа ----------

    /** Слоты страницы pg: свои, если отмечены, иначе как на предыдущей странице. */
    private fun slotsFor(pg: Int): List<P> {
        val l1 = cfg.list(T.SLOT, 0)
        val l2 = cfg.list(T.SLOT2, 0)
        val l3 = cfg.list(T.SLOT3, 0)
        return when {
            pg == 0 -> l1
            pg == 1 -> if (l2.isNotEmpty()) l2 else l1
            else -> if (l3.isNotEmpty()) l3 else (if (l2.isNotEmpty()) l2 else l1)
        }.toList()
    }

    /** Уменьшенная яркостная картинка экрана для сравнения «до и после». */
    private fun grid(): IntArray? {
        val bmp = takeBitmap() ?: return null
        val gw = 32
        val gh = 18
        val out = IntArray(gw * gh)
        for (y in 0 until gh) {
            for (x in 0 until gw) {
                val px = bmp.getPixel(
                    ((x + 0.5f) * bmp.width / gw).toInt().coerceIn(0, bmp.width - 1),
                    ((y + 0.5f) * bmp.height / gh).toInt().coerceIn(0, bmp.height - 1)
                )
                out[y * gw + x] = (Color.red(px) * 30 + Color.green(px) * 59 + Color.blue(px) * 11) / 100
            }
        }
        bmp.recycle()
        return out
    }

    private fun changedPercent(a: IntArray, b: IntArray): Int {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 20) n++
        return n * 100 / a.size
    }

    /**
     * Листает лавку на следующую страницу и по картинке проверяет, что экран изменился.
     * Если нет и retry=true, пробует ещё раз подлиннее и помедленнее. Если проверить нельзя, считает, что получилось.
     */
    /** Подпись киоска: плашки соседей внизу экрана у каждого киоска свои. */
    private fun kioskSig(): List<IntArray>? {
        if (Build.VERSION.SDK_INT < 30) return null
        val bmp = takeBitmap() ?: return null
        val b = wm.maximumWindowMetrics.bounds
        val sx = bmp.width.toFloat() / b.width()
        val sy = bmp.height.toFloat() / b.height()
        val l = cropPatch(bmp, P(b.width() * 0.19f, b.height() * 0.86f), sx, sy)
        val r = cropPatch(bmp, P(b.width() * 0.81f, b.height() * 0.86f), sx, sy)
        bmp.recycle()
        return if (l != null && r != null) listOf(l, r) else null
    }

    private fun sameKiosk(a: List<IntArray>, b: List<IntArray>): Boolean =
        patchDist(a[0], b[0]) < 22f && patchDist(a[1], b[1]) < 22f

    private fun swipePage(a: P, b: P, retry: Boolean = true): Boolean {
        val rec = cfg.useRec && Build.VERSION.SDK_INT >= 30
        val sig0 = if (rec) kioskSig() else null
        val before = if (rec) grid() else null
        gentleSwipe(a, b, cfg.swipeMs.toLong())
        pause(sp(1000, cfg.speedShop))
        if (rec) {
            val sig1 = kioskSig()
            if (sig0 != null && sig1 != null && !sameKiosk(sig0, sig1)) {
                // свайп переключил на киоск соседа: возвращаем назад и считаем, что страниц нет
                jlog("⚠ Свайп переключил на киоск соседа: страниц в лавке нет")
                say("⚠ Свайп уехал на киоск соседа, возвращаю")
                gentleSwipe(b, a, cfg.swipeMs.toLong())
                pause(1000)
                cfg.shopPages = 1
                return false
            }
        }
        if (before == null) return true
        val after = grid() ?: return true
        return changedPercent(before, after) >= 3
    }

    // ----- поиск пшеницы в списке товаров по картинке -----

    /** Вырезает квадрат вокруг точки и сжимает до patchN x patchN. */
    private fun cropPatch(bmp: Bitmap, p: P, sx: Float, sy: Float): IntArray? {
        val sz = (110f * sx).toInt().coerceAtLeast(24)
        if (bmp.width < sz || bmp.height < sz) return null
        val x = ((p.x * sx).toInt() - sz / 2).coerceIn(0, bmp.width - sz)
        val y = ((p.y * sy).toInt() - sz / 2).coerceIn(0, bmp.height - sz)
        val crop = Bitmap.createBitmap(bmp, x, y, sz, sz)
        val sc = Bitmap.createScaledBitmap(crop, patchN, patchN, true)
        val out = IntArray(patchN * patchN)
        sc.getPixels(out, 0, patchN, 0, 0, patchN, patchN)
        if (sc !== crop) sc.recycle()
        if (crop !== bmp) crop.recycle()
        return out
    }

    private fun grabPatch(p: P): IntArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        val bmp = takeBitmap() ?: return null
        val b = wm.maximumWindowMetrics.bounds
        val out = cropPatch(bmp, p, bmp.width.toFloat() / b.width(), bmp.height.toFloat() / b.height())
        bmp.recycle()
        return out
    }

    private fun patchDist(a: IntArray, b: IntArray): Float {
        var s = 0L
        for (i in a.indices) {
            val x = a[i]
            val y = b[i]
            s += abs(Color.red(x) - Color.red(y)) + abs(Color.green(x) - Color.green(y)) + abs(Color.blue(x) - Color.blue(y))
        }
        return s.toFloat() / (a.size * 3)
    }

    /** Ячейка, в которой сейчас пшеница (среди возможных), или null. Если снимок не получился, доверяем первой. */
    private fun matchWheat(cands: List<P>, pat: IntArray): P? {
        val bmp = takeBitmap() ?: return cands.firstOrNull()
        val b = wm.maximumWindowMetrics.bounds
        val sx = bmp.width.toFloat() / b.width()
        val sy = bmp.height.toFloat() / b.height()
        var best = Float.MAX_VALUE
        var bp: P? = null
        for (c in cands) {
            val q = cropPatch(bmp, c, sx, sy) ?: continue
            val d = patchDist(q, pat)
            if (d < best) {
                best = d
                bp = c
            }
        }
        bmp.recycle()
        if (bp != null && bp !== cands.first()) jlog("🔎 Пшеница сдвинулась в другую ячейку (отличие " + best.toInt() + ")")
        return if (best < 42f) bp else null
    }

    private fun candidates(item: P): List<P> {
        val out = ArrayList<P>()
        out.add(item)
        for (p in cfg.list(T.ITEMS, 0)) {
            if (out.none { hypot(it.x - p.x, it.y - p.y) < 30f }) out.add(p)
        }
        return out
    }

    /**
     * Ждёт, пока откроется выбор товара, и возвращает точку, где лежит пшеница.
     * С картинкой иконки ищет среди всех ячеек, иначе проверяет цвет на старом месте.
     */
    private fun findItem(itemRef: Int?, item: P, cands: List<P>, pat: IntArray?, timeoutMs: Long, poll: Long): P? {
        val t0 = System.currentTimeMillis()
        while (active) {
            if (pat != null) {
                val f = matchWheat(cands, pat)
                if (f != null) return f
            } else if (itemRef != null) {
                val c = colorAt(item) ?: return item
                if (near(c, itemRef)) return item
            } else {
                return item   // распознавание выключено: нажимаем вслепую
            }
            if (System.currentTimeMillis() - t0 > timeoutMs) return null
            pause(poll)
        }
        return null
    }

    private fun openShop(shop: P, close: P, shopRef: Int?, pct: Int, poll: Long): Boolean {
        val rec = Build.VERSION.SDK_INT >= 30 && cfg.useRec
        for (attempt in 0..1) {
            val before = if (rec) grid() else null
            tap(shop)
            pause(sp(1800, pct))
            if (!rec) return true
            val after = grid()
            if (before == null || after == null) return true   // проверить нельзя, считаем открытой
            // лавка открылась, если экран заметно изменился или цвет крестика совпал с эталоном
            val ch = changedPercent(before, after)
            jlog("лавка: экран изменился на " + ch + "%")
            if (ch >= 15) return true
            if (shopRef != null && waitColor(close, shopRef, 1500, poll)) return true
            if (attempt == 0) say("Лавка не открылась, пробую ещё раз")
        }
        return false
    }

    /** Возвращает лавку на первую страницу, если прошлая продажа оставила её сдвинутой. */
    private fun rewindShop(sw: List<P>, pages: Int) {
        say("Лавка: возвращаюсь на первую страницу")
        for (k in 0 until pages - 1) {
            if (!active) return
            if (!swipePage(sw[1], sw[0], false)) return   // не изменилось: уже на первой
        }
    }

    /** Если «назад» закрыло лавку, открывает её снова и возвращается на страницу pg. */
    private fun recoverShop(pg: Int, shop: P, close: P, shopRef: Int?, sw: List<P>, pct: Int, poll: Long): Boolean {
        if (shopRef == null || waitColor(close, shopRef, 1500, poll)) return true
        if (!openShop(shop, close, shopRef, pct, poll)) return false
        for (k in 0 until pg) {
            if (!swipePage(sw[0], sw[1])) return false
            pause(sp(500, pct))
        }
        return true
    }

    /** Точки свайпа бота для листания лавки: по горизонтали через середину слотов. */
    private fun swipePts(): List<P> {
        val slots = cfg.list(T.SLOT, 0)
        val w = screenW().toFloat()
        val h = screenH().toFloat()
        val cx = if (slots.isNotEmpty()) slots.map { it.x }.average().toFloat() else w / 2f
        val cy = if (slots.isNotEmpty()) slots.map { it.y }.average().toFloat() else h / 2f
        val half = cfg.swipeLen / 2f
        return listOf(
            P((cx + half).coerceIn(w * 0.03f, w * 0.97f), cy),
            P((cx - half).coerceIn(w * 0.03f, w * 0.97f), cy)
        )
    }

    private fun testSwipe(forward: Boolean) {
        val sw = swipePts()
        val a = if (forward) sw[0] else sw[1]
        val b = if (forward) sw[1] else sw[0]
        runTask("Листаю лавку…", { pause(300); gentleSwipe(a, b, cfg.swipeMs.toLong()); pause(1000) }, { updateUi() })
    }

    /** Если лавка осталась открытой, закрывает её: иначе нажатия по полю попадут в кнопки лавки и соседних киосков. */
    private fun ensureShopClosed() {
        if (cfg.first(T.SHOP, 0) == null || !cfg.useRec || Build.VERSION.SDK_INT < 30) return
        val close = cfg.first(T.CLOSE, 0) ?: return
        val ref = cfg.getRef(T.CLOSE, 0) ?: return
        for (k in 0..2) {
            val c = colorAt(close) ?: return
            if (!near(c, ref)) return   // крестика нет: лавка закрыта
            say("Закрываю лавку")
            jlog("Лавка осталась открытой, закрываю")
            if (k == 0) tap(close) else backAction()
            pause(900)
        }
    }

    private fun backAction() {
        ui.post { performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }
    }

    private fun sell(round: Int, force: Boolean = false): Boolean {
        lastSold = 0
        val shop = cfg.first(T.SHOP, 0) ?: return true
        val item = cfg.first(T.ITEM, 0) ?: return true
        val extra = cfg.list(T.EXTRA, 0).toList()
        val ad = cfg.first(T.AD, 0)
        val put = cfg.first(T.PUT, 0) ?: return true
        val close = cfg.first(T.CLOSE, 0) ?: return true
        val sw = if (cfg.shopPages > 1) swipePts() else emptyList()
        val pages = if (sw.size >= 2) cfg.shopPages else 1
        val rec = cfg.useRec && Build.VERSION.SDK_INT >= 30
        val shopRef = if (rec) cfg.getRef(T.CLOSE, 0) else null
        val lotRef = if (rec) cfg.getRef(T.PUT, 0) else null
        val itemRef = if (rec) cfg.getRef(T.ITEM, 0) else null
        val pat = if (rec) cfg.getWheatPatch() else null
        val cands = candidates(item)
        val pct = cfg.speedShop
        val poll = (600L * 100 / pct.coerceIn(30, 400)).coerceIn(330L, 900L)

        if (force && ad != null && lastAd > 0L && System.currentTimeMillis() < lastAd + adCooldownMs &&
            lastAd + adCooldownMs - System.currentTimeMillis() <= 90_000L
        ) {
            idleUntil(lastAd + adCooldownMs, "📢 Жду, пока можно поставить рекламу")
        }
        say("Продажа $round: открываю лавку 🏪")
        if (!openShop(shop, close, shopRef, pct, poll)) {
            say("⚠ Лавка не открылась, продажу пропускаю")
            jlog("⚠ Лавка не открылась")
            shopDirty = true
            return false
        }
        shopDirty = true   // пока идёт продажа, страницы могут быть сдвинуты

        var sold = 0
        var flipped = 0   // сколько раз успешно пролистали вперёд
        var misses = 0    // подряд слотов без выбора пшеницы
        pagesLoop@ for (pg in 0 until pages) {
            if (!active) return true
            if (pg > 0) {
                say("Продажа $round: страница " + (pg + 1) + " ↔")
                if (!swipePage(sw[0], sw[1])) {
                    say("⚠ Лавка не листается, остальные страницы пропускаю")
                    jlog("⚠ Лавка не пролистнулась на странице " + (pg + 1))
                    break@pagesLoop
                }
                flipped++
                pause(sp(500, pct))
            }
            val pageSlots = slotsFor(pg)
            for ((i, slot) in pageSlots.withIndex()) {
                if (!active) return true
                say("Продажа $round: стр. " + (pg + 1) + ", слот " + (i + 1) + " из " + pageSlots.size + " 🧺")
                // 1-е нажатие забирает выручку (или сразу открывает выбор, если слот пуст)
                tap(slot)
                pause(sp(900 + Random.nextLong(0, 250), pct))
                var target = findItem(itemRef, item, cands, pat, 900L, poll)
                if (target == null) {
                    // 2-е нажатие открывает выбор
                    tap(slot)
                    pause(sp(1000 + Random.nextLong(0, 250), pct))
                    target = findItem(itemRef, item, cands, pat, 2200L, poll)
                }
                if (target == null) {
                    // слот занят (лот ещё висит) или пшеница закончилась: закрываем окно кнопкой «назад», идём дальше
                    misses++
                    jlog("Стр. " + (pg + 1) + ", слот " + (i + 1) + ": выбора с пшеницей нет (занят или пшеницы нет)")
                    say("Слот " + (i + 1) + ": занят или нет пшеницы, пропускаю")
                    backAction()
                    pause(sp(800, pct))
                    if (!recoverShop(pg, shop, close, shopRef, sw, pct, poll)) {
                        jlog("⚠ Лавка закрылась и не открылась снова")
                        return false
                    }
                    flipped = pg
                    if (misses >= 3) {
                        say("Пшеницы в списке не видно, останавливаю продажу")
                        jlog("Продажа остановлена: 3 слота подряд без пшеницы")
                        break@pagesLoop
                    }
                    continue
                }
                misses = 0
                val b4 = if (rec) grid() else null
                tap(target)
                pause(sp(800, pct))
                // окно лота должно открыться: иначе следующие нажатия попали бы по кнопкам соседних киосков
                if (rec) {
                    val af = grid()
                    var opened = b4 != null && af != null && changedPercent(b4, af) >= 5
                    if (!opened && lotRef != null) opened = waitColor(put, lotRef, 1200, poll)
                    if (!opened && b4 != null && af != null) {
                        say("⚠ Окно лота не открылось, пропускаю слот")
                        jlog("⚠ Окно лота не открылось, слот " + (i + 1) + " пропущен")
                        backAction()
                        pause(sp(800, pct))
                        if (!recoverShop(pg, shop, close, shopRef, sw, pct, poll)) return false
                        flipped = pg
                        continue
                    }
                }
                for (e in extra) {
                    tap(e)
                    pause(sp(600, pct))
                }
                if (ad != null && pg == pages - 1 && i == pageSlots.size - 1 && System.currentTimeMillis() - lastAd >= adCooldownMs) {
                    tap(ad)
                    lastAd = System.currentTimeMillis()
                    pause(sp(900, pct))
                }
                tap(put)
                pause(sp(1300, pct))
                sold++
                sSales++
                stats.add("sales")
            }
        }
        // вернуть лавку на первую страницу
        for (k in 0 until flipped) {
            if (!active) return true
            gentleSwipe(sw[1], sw[0], cfg.swipeMs.toLong())
            pause(sp(900, pct))
        }
        shopDirty = false
        tap(close)
        pause(sp(1200, pct))
        lastSold = sold
        jlog("🏪 Продажа " + round + ": выставлено " + sold + " (страниц " + (flipped + 1) + ")")
        return true
    }

    // ---------- распознавание экрана и эталон вида (скриншот через службу, Android 11+) ----------

    private fun near(a: Int, b: Int, tol: Int = 48): Boolean {
        val dr = Color.red(a) - Color.red(b)
        val dg = Color.green(a) - Color.green(b)
        val db = Color.blue(a) - Color.blue(b)
        return dr * dr + dg * dg + db * db < tol * tol
    }

    /** true — цвет в точке совпал с эталоном. Если скриншот не удаётся, не блокируем бота. */
    private fun waitColor(p: P, ref: Int, timeoutMs: Long, pollMs: Long = 600L): Boolean {
        val t0 = System.currentTimeMillis()
        while (active) {
            val c = colorAt(p) ?: return true
            if (near(c, ref)) return true
            if (System.currentTimeMillis() - t0 > timeoutMs) return false
            pause(pollMs)
        }
        return false
    }

    private fun colorAt(p: P): Int? = shot(listOf(p))?.firstOrNull()

    private fun toSoft(r: AccessibilityService.ScreenshotResult): Bitmap? {
        val hb = r.hardwareBuffer
        val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
        hw?.recycle()
        hb.close()
        return soft
    }

    /** Скриншот экрана. Вызывать не из главного потока. */
    private fun takeBitmap(): Bitmap? {
        val tv = trail
        if (tv != null) {
            ui.post { tv.quiet = true; tv.invalidate() }
            Thread.sleep(60)
        }
        try {
            return takeBitmapRaw()
        } finally {
            if (tv != null) ui.post { tv.quiet = false; tv.invalidate() }
        }
    }

    private fun takeBitmapRaw(): Bitmap? {
        if (Build.VERSION.SDK_INT < 30) return null
        for (attempt in 0..1) {
            val latch = CountDownLatch(1)
            val res = AtomicReference<Bitmap?>(null)
            ui.post {
                try {
                    takeScreenshot(
                        Display.DEFAULT_DISPLAY,
                        shotExec,
                        object : AccessibilityService.TakeScreenshotCallback {
                            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                                try { res.set(toSoft(r)) } catch (_: Exception) {}
                                latch.countDown()
                            }

                            override fun onFailure(errorCode: Int) {
                                latch.countDown()
                            }
                        }
                    )
                } catch (_: Exception) {
                    latch.countDown()
                }
            }
            latch.await(3, TimeUnit.SECONDS)
            val out = res.get()
            if (out != null) return out
            Thread.sleep(450)   // скриншоты можно делать не чаще раза в треть секунды
        }
        return null
    }

    /** Средний цвет небольших участков вокруг точек. */
    private fun shot(points: List<P>): List<Int>? {
        val soft = takeBitmap() ?: return null
        val bounds = wm.maximumWindowMetrics.bounds
        val sx = soft.width.toFloat() / bounds.width()
        val sy = soft.height.toFloat() / bounds.height()
        val out = ArrayList<Int>()
        for (p in points) {
            val cx = (p.x * sx).toInt().coerceIn(3, soft.width - 4)
            val cy = (p.y * sy).toInt().coerceIn(3, soft.height - 4)
            var rr = 0
            var gg = 0
            var bb = 0
            var n = 0
            for (dy in -3..3 step 2) {
                for (dx in -3..3 step 2) {
                    val px = soft.getPixel(cx + dx, cy + dy)
                    rr += Color.red(px)
                    gg += Color.green(px)
                    bb += Color.blue(px)
                    n++
                }
            }
            out.add(Color.rgb(rr / n, gg / n, bb / n))
        }
        soft.recycle()
        return out
    }

    private fun hasRef(): Boolean = File(filesDir, "ref.png").exists()

    /** Призрак: полупрозрачный эталонный вид поверх игры, чтобы совместить камеру руками. */
    private fun showGhost(on: Boolean) {
        val g = ghost ?: return
        if (on) {
            g.setLevel(120)
            g.reload()
            if (!g.hasImage()) {
                toast("Эталона вида пока нет")
                ghostOn = false
                g.visibility = View.GONE
                return
            }
        }
        ghostOn = on
        g.visibility = if (on && inGame) View.VISIBLE else View.GONE
    }

    /** Запоминает текущий вид как эталон (без нашей панели на снимке). */
    private fun captureRef(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        ui.post {
            root?.visibility = View.INVISIBLE
            cap?.visibility = View.INVISIBLE
            ghost?.visibility = View.GONE
        }
        Thread.sleep(350)
        val bmp = takeBitmap()
        ui.post {
            root?.visibility = View.VISIBLE
            cap?.visibility = View.VISIBLE
            ghost?.visibility = if (ghostOn && inGame) View.VISIBLE else View.GONE
        }
        if (bmp == null) return false
        val w = 800
        val h = (bmp.height * w.toFloat() / bmp.width).toInt()
        val small = Bitmap.createScaledBitmap(bmp, w, h, true)
        bmp.recycle()
        try {
            FileOutputStream(File(filesDir, "ref.png")).use { small.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {
            small.recycle()
            return false
        }
        small.recycle()
        return true
    }

    // ---------- жесты ----------

    private fun pause(ms: Long, label: String? = null) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        var left = ms
        var shown = -1L
        var tick = 0
        while (left > 0 && active) {
            if (paused) {
                waitIfPaused()
                continue
            }
            if (label != null) {
                val s = left / 1000
                if (s != shown) {
                    shown = s
                    say(label + " " + fmt(s.toInt()))
                }
            }
            if (botMode && ++tick % 10 == 0 && !pm.isInteractive) {
                stopBot("Экран погас")
                return
            }
            Thread.sleep(minOf(left, 200L))
            left -= 200L
        }
    }

    private fun jit(a: Float) = (Random.nextFloat() * 2f - 1f) * a
    private fun j(v: Float) = v + jit(5f)

    private fun trailPath(pts: List<P>, ms: Long) {
        if (!cfg.trail) return
        ui.post { trail?.add(pts, ms) }
    }

    private fun tap(p: P) {
        waitIfPaused()
        trailPath(listOf(p), 450)
        jlog("tap " + p.x.toInt() + "," + p.y.toInt())
        val path = Path()
        path.moveTo(j(p.x), j(p.y))
        play(GestureDescription.StrokeDescription(path, 0, 40L + Random.nextLong(0, 40)))
        // режим «как человек»: совсем крошечная случайная пауза после нажатия
        if (cfg.plantMode >= 3) Thread.sleep(Random.nextLong(60, 220))
    }

    private fun drag(start: P, pts: List<P>) {
        val path = Path()
        path.moveTo(j(start.x), j(start.y))
        for (q in pts) path.lineTo(q.x + jit(2f), q.y + jit(2f))
        val len = Geo.length(start, pts)
        val dur = (len / 0.5f).toLong().coerceIn(900L, 50_000L)   // примерно 500 px в секунду
        play(GestureDescription.StrokeDescription(path, 0, dur))
    }

    private fun waypoints(pts: List<P>, stepPx: Float): List<P> {
        val out = ArrayList<P>()
        out.add(pts[0])
        for (i in 1 until pts.size) {
            val a = pts[i - 1]
            val b = pts[i]
            val d = hypot(b.x - a.x, b.y - a.y)
            val n = max(1, ceil(d / stepPx).toInt())
            for (k in 1..n) out.add(P(a.x + (b.x - a.x) * k / n, a.y + (b.y - a.y) * k / n))
        }
        return out
    }

    /** Аккуратный свайп: основная часть быстрее, последние 15% пути медленно, чтобы игра не подхватила инерцию. */
    private fun gentleSwipe(a: P, b: P, ms: Long) {
        waitIfPaused()
        val dur = ms.coerceIn(400L, 2500L)
        val ax = a.x + jit(3f)
        val ay = a.y + jit(3f)
        val bx = b.x + jit(3f)
        val by = b.y + jit(3f)
        trailPath(listOf(P(ax, ay), P(bx, by)), dur)
        jlog("swipe " + ax.toInt() + "," + ay.toInt() + " -> " + bx.toInt() + "," + by.toInt() + " за " + dur + "мс")
        if (Build.VERSION.SDK_INT < 26) {
            val p = Path()
            p.moveTo(ax, ay)
            p.lineTo(bx, by)
            play(GestureDescription.StrokeDescription(p, 0, dur))
            return
        }
        val mx = ax + (bx - ax) * 0.85f
        val my = ay + (by - ay) * 0.85f
        val p1 = Path()
        p1.moveTo(ax, ay)
        p1.lineTo(mx, my)
        val s1 = GestureDescription.StrokeDescription(p1, 0, (dur * 0.65).toLong(), true)
        play(s1)
        val p2 = Path()
        p2.moveTo(mx, my)
        p2.lineTo(bx, by)
        val s2 = s1.continueStroke(p2, 0, (dur * 0.35).toLong(), true)
        play(s2)
        val p3 = Path()
        p3.moveTo(bx, by)
        play(s2.continueStroke(p3, 0, 120, false))
    }

    /**
     * Как живой палец: зажимаем иконку (культура или серп) и держим, слегка «вытягиваем» её из меню,
     * несём к выбранной грядке и дальше, не отпуская, ведём по маршруту. В конце, всё так же не отпуская,
     * возвращаем палец в исходную точку (к выбранной грядке): тогда камера не уплывает за местом, где закончили.
     * Режимы: 0 плавно, 1 медленно, 2 по шагам, 3 как человек (палец быстро дёргается
     * из стороны в сторону поперёк строки много раз).
     */
    private fun holdDrag(start: P, pts: List<P>, anchor: P? = null, pct: Int = 100, after: GestureDescription.StrokeDescription? = null, afterPt: P? = null) {
        if (Build.VERSION.SDK_INT < 26 || pts.isEmpty()) {
            drag(start, pts)
            return
        }
        waitIfPaused()
        val mode3 = cfg.plantMode == 3
        val k = pct / 100f   // скорость: больше — быстрее
        jlog("drag режим " + cfg.plantMode + ", скорость " + pct + "%, точек " + pts.size)
        // безопасная зона: палец с культурой не заходит к краям экрана, иначе игра двигает камеру
        val scw = screenW().toFloat()
        val sch = screenH().toFloat()
        val mgx = scw * cfg.edgePct / 100f
        val mgy = sch * cfg.edgePct * 1.15f / 100f
        var clamped = 0
        fun cxx(x: Float): Float {
            val v = x.coerceIn(mgx, scw - mgx)
            if (v != x) clamped++
            return v
        }
        fun cyy(y: Float): Float {
            val v = y.coerceIn(mgy, sch - mgy)
            if (v != y) clamped++
            return v
        }
        // последний штрих жеста; если задан «after», следующий жест стартует сразу из его колбэка
        fun fin(st: GestureDescription.StrokeDescription) {
            if (after != null) playChained(st, after, afterPt, cfg.groundMs.toLong()) else play(st)
        }
        var cx = j(start.x)
        var cy = j(start.y)
        val p0 = Path()
        p0.moveTo(cx, cy)
        val hold = cfg.holdMs.toLong() + (if (mode3) Random.nextLong(0, 120) else 0L)
        var prev = GestureDescription.StrokeDescription(p0, 0, hold, true)
        trailPath(listOf(P(cx, cy)), hold)
        play(prev)

        // вытягиваем иконку из меню: небольшой медленный сдвиг в сторону поля
        val first = anchor ?: pts[0]
        val dx = first.x - cx
        val dy = first.y - cy
        val dl = max(1f, hypot(dx, dy))
        val px = cx + dx / dl * 45f
        val py = cy + dy / dl * 45f
        val pp = Path()
        pp.moveTo(cx, cy)
        pp.lineTo(px, py)
        prev = prev.continueStroke(pp, 0, 300, true)
        trailPath(listOf(P(cx, cy), P(px, py)), 300)
        play(prev)
        cx = px
        cy = py

        // несём культуру к выбранной грядке и задерживаемся над ней: посадка идёт от неё
        if (anchor != null) {
            val ax = anchor.x + jit(2f)
            val ay = anchor.y + jit(2f)
            val d0 = hypot(ax - cx, ay - cy)
            val durA = (d0 / (0.5f * k)).toLong().coerceIn(200L, 6000L)
            val pa = Path()
            pa.moveTo(cx, cy)
            pa.lineTo(ax, ay)
            prev = prev.continueStroke(pa, 0, durA, true)
            trailPath(listOf(P(cx, cy), P(ax, ay)), durA)
            play(prev)
            cx = ax
            cy = ay
            val pd = Path()
            pd.moveTo(cx, cy)
            prev = prev.continueStroke(pd, 0, if (mode3) 200L else 300L, true)
            play(prev)
        }

        val goHome = cfg.returnHand > 0   // вернуть палец к началу посева, не отпуская
        if (cfg.plantMode == 2) {
            val wps = waypoints(pts, max(30f, cfg.rowGap * 1.6f))
            for ((i, w) in wps.withIndex()) {
                val isEnd = !goHome && i == wps.size - 1
                val tx = cxx(w.x + jit(2f))
                val ty = cyy(w.y + jit(2f))
                val d = hypot(tx - cx, ty - cy)
                val dur = (d / (0.35f * k)).toLong().coerceIn(30L, 4000L)
                val mv = Path()
                mv.moveTo(cx, cy)
                mv.lineTo(tx, ty)
                prev = prev.continueStroke(mv, 0, dur, !isEnd)
                if (isEnd) fin(prev) else play(prev)
                cx = tx
                cy = ty
                if (!isEnd) {
                    val dw = Path()
                    dw.moveTo(cx, cy)
                    prev = prev.continueStroke(dw, 0, 70, true)
                    play(prev)
                }
            }
        } else {
            val route = if (mode3) {
                Geo.scribble(pts, max(10f, cfg.rowGap * 0.5f), max(12f, cfg.rowGap * 0.4f), Random)
            } else {
                pts
            }
            val base = when (cfg.plantMode) {
                1 -> 0.25f
                3, 4 -> 0.8f
                else -> 0.5f
            }
            val chunks = when (cfg.plantMode) {
                3 -> route.chunked(14)
                4 -> route.map { listOf(it) }
                else -> listOf(route)
            }
            for ((ci, chunk) in chunks.withIndex()) {
                val path = Path()
                path.moveTo(cx, cy)
                val seg = ArrayList<P>()
                seg.add(P(cx, cy))
                var len = 0f
                var lx = cx
                var ly = cy
                for (q in chunk) {
                    val tx = cxx(if (mode3) q.x else q.x + jit(2f))
                    val ty = cyy(if (mode3) q.y else q.y + jit(2f))
                    path.lineTo(tx, ty)
                    seg.add(P(tx, ty))
                    len += hypot(tx - lx, ty - ly)
                    lx = tx
                    ly = ty
                }
                // дёрганое движение: у каждого куска своя скорость
                val v = base * k * (if (mode3) 0.5f + 1.3f * Random.nextFloat() else if (cfg.plantMode == 4) 0.9f + 0.3f * Random.nextFloat() else 1f)
                val speed = max(v, len / 50_000f)
                val dur = (len / speed).toLong().coerceIn(30L, 55_000L)
                val lastChunk = ci == chunks.size - 1
                prev = prev.continueStroke(path, 0, dur, !(lastChunk && !goHome))
                trailPath(seg, dur)
                if (lastChunk && !goHome) fin(prev) else play(prev)
                cx = lx
                cy = ly
            }
        }

        // возвращаем палец, не отпуская, к началу посева (медленно) и сразу отпускаем: больше ничего не нажимаем
        if (goHome) {
            val home = anchor ?: start
            val hx = cxx(home.x + jit(2f))
            val hy = cyy(home.y + jit(2f))
            val dr = hypot(hx - cx, hy - cy)
            val pr = Path()
            pr.moveTo(cx, cy)
            pr.lineTo(hx, hy)
            val durR = (dr / (1.2f * k)).toLong().coerceIn(200L, 5000L)
            trailPath(listOf(P(cx, cy), P(hx, hy)), durR)
            fin(prev.continueStroke(pr, 0, durR, false))
        }
        if (clamped > 0) jlog("🧱 Маршрут обрезан у края экрана: " + clamped + " точек (отступ " + cfg.edgePct + "%)")
    }

    /** Несколько штрихов в одном жесте = несколько пальцев одновременно. */
    private fun play(vararg strokes: GestureDescription.StrokeDescription) {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val gb = GestureDescription.Builder()
        for (s in strokes) gb.addStroke(s)
        val g = gb.build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                ok.set(true)
                latch.countDown()
            }

            override fun onCancelled(d: GestureDescription?) {
                latch.countDown()
            }
        }
        ui.post { if (!dispatchGesture(g, cb, null)) latch.countDown() }
        latch.await(70, TimeUnit.SECONDS)
        if (ok.get()) {
            gestureFails = 0
        } else {
            gestureFails++
            if (gestureFails >= 6 && botMode) {
                jlog("⚠ Жесты не проходят")
                stopBot("Жесты не проходят. Проверь службу и не трогай экран")
            }
        }
    }
}
