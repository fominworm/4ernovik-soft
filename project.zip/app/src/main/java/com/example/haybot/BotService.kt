package com.example.haybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.text.TextUtils
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.random.Random

class BotService : AccessibilityService() {
    private enum class Mode { MENU, SETUP, RUN, REC }

    private class Act(val t: String, val c: Int, val f: () -> Unit)

    private class Gray(val w: Int, val h: Int, val d: IntArray)

    private val gamePkg = "com.supercell.hayday"

    private val ui = Handler(Looper.getMainLooper())
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val shotExec: Executor = Executors.newSingleThreadExecutor()
    private lateinit var cfg: Cfg
    private lateinit var stats: Stats

    private var mode = Mode.MENU
    private var menuPage = 0
    private var step = 0
    private var expanded = true
    private var note = ""
    private var inGame = false              // сейчас на экране Hay Day
    @Volatile private var busy = false      // идёт повтор нажатия, снятие эталона или задача бота
    @Volatile private var active = false    // работает фоновый поток
    private var plantedAt = 0L
    @Volatile private var lastAd = 0L
    @Volatile private var stopReason: String? = null
    @Volatile private var paused = false
    @Volatile private var taskAborted = false
    private var gestureFails = 0
    private var fails = 0
    private var worker: Thread? = null

    private val recTaps = ArrayList<MTap>()
    private var recLast = 0L
    private val lastMacro = LongArray(Cfg.MAXM)
    private var runStart = 0L
    @Volatile private var sPlants = 0
    @Volatile private var sHarv = 0
    @Volatile private var sSales = 0
    @Volatile private var sFails = 0

    private val botMode: Boolean get() = mode == Mode.RUN

    private var root: LinearLayout? = null
    private var body: LinearLayout? = null
    private var cap: MarkView? = null
    private var ghost: GhostView? = null
    private var ghostOn = false
    private var pill: TextView? = null
    private lateinit var capLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var titleTv: TextView
    private lateinit var promptTv: TextView
    private lateinit var subTv: TextView
    private lateinit var primaryBtn: TextView
    private lateinit var foldBtn: TextView
    private lateinit var stopBtn: TextView
    private lateinit var pauseBtn: TextView
    private lateinit var menuBtn: TextView
    private lateinit var rowA: LinearLayout
    private lateinit var rowB: LinearLayout
    private lateinit var rowC: LinearLayout
    private lateinit var rowD: LinearLayout

    private val adCooldownMs = 305_000L    // реклама не чаще раза в 5 минут

    private val cGray = 0xFF4A4F57.toInt()
    private val cGreen = 0xFF2E9E4F.toInt()
    private val cRed = 0xFFD64545.toInt()
    private val cBlue = 0xFF2F6FDE.toInt()

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val panelFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    private fun growMs(f: Int): Long = cfg.grow(f) * 1000L

    private fun jlog(m: String) {
        Journal.log(this, m)
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (mode != Mode.SETUP || FLOW[step].kind != Kind.WAIT) return
            val left = ((plantedAt + growMs(cfg.cur) - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
            note = if (left > 0) {
                "⏳ Осталось примерно " + fmt(left.toInt()) + "\nКак только созреет, жми кнопку: я замерю время."
            } else {
                "✅ Должна быть готова. Жми, когда увидишь, что созрела."
            }
            subTv.text = note
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- жизненный цикл ----------

    override fun onServiceConnected() {
        cfg = Cfg(this)
        stats = Stats(this)
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { Journal.log(applicationContext, "💥 Сбой в потоке " + t.name + ": " + e) } catch (_: Throwable) {}
            prevHandler?.uncaughtException(t, e)
        }
        cfg.onExternalChange = { enterMenu("Настройки обновлены") }
        val mv = MarkView(this, cfg)
        mv.onTap = { x, y -> onTapped(x, y) }
        mv.onSwipe = { a, b, ms -> onSwiped(a, b, ms) }
        capLp = overlayParams()
        wm.addView(mv, capLp)
        cap = mv
        val gv = GhostView(this, File(filesDir, "ref.png"))
        wm.addView(gv, overlayParams())
        gv.visibility = View.GONE
        ghost = gv
        showPanel()   // панель добавляется после слоёв, значит лежит выше них
        showPill()
        mode = Mode.MENU
        inGame = false
        updateUi()
        applyGameState()
        jlog("Служба запущена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val cls = event.className?.toString() ?: ""
        if (cls.contains("InputMethod") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        val g = pkg == gamePkg
        if (g != inGame) {
            inGame = g
            applyGameState()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        active = false
        worker?.interrupt()
        ui.removeCallbacks(ticker)
        removeView(cap)
        removeView(ghost)
        removeView(pill)
        removeView(root)
        super.onDestroy()
    }

    /** Панель и перехват касаний живут только внутри Hay Day. При входе в игру всегда меню: ничего само не запускается. */
    private fun applyGameState() {
        val v = if (inGame) View.VISIBLE else View.GONE
        root?.visibility = v
        cap?.visibility = v
        ghost?.visibility = if (inGame && ghostOn) View.VISIBLE else View.GONE
        pill?.visibility = if (inGame && botMode) View.VISIBLE else View.GONE
        if (!inGame) {
            if (botMode) {
                stopBot("Игра свёрнута")
            } else {
                mode = Mode.MENU
                menuPage = 0
                recTaps.clear()
                note = ""
            }
            setArmed(false)
        } else {
            updateUi()
        }
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun overlayParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    /** armed = слой ловит касание пользователя; иначе касания проходят в игру. */
    private fun setArmed(on: Boolean) {
        val mv = cap ?: return
        val want = on && inGame
        if (mv.armed == want) return
        mv.armed = want
        capLp.flags = if (want) baseFlags else (baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        try { wm.updateViewLayout(mv, capLp) } catch (_: Exception) {}
        mv.invalidate()
    }

    private fun keepAwake(on: Boolean) {
        val r = root ?: return
        panelLp.flags = if (on) (panelFlags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else panelFlags
        try { wm.updateViewLayout(r, panelLp) } catch (_: Exception) {}
    }

    private fun toast(m: String) {
        ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    private fun fmt(sec: Int): String = (sec / 60).toString() + ":" + (sec % 60).toString().padStart(2, '0')

    private fun modeName(m: Int): String = when (m) {
        0 -> "плавно"
        1 -> "медленно"
        2 -> "по шагам"
        else -> "как человек"
    }

    private fun recText(): String = when {
        Build.VERSION.SDK_INT < 30 -> "недоступно (нужен Android 11+)"
        !cfg.useRec -> "выкл"
        else -> "вкл, эталонов " + listOf(T.HFIELD, T.CLOSE, T.PUT, T.ITEM).count { cfg.getRef(it, 0) != null }
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun vis(show: Boolean): Int = if (show) View.VISIBLE else View.GONE

    private fun btn(t: String, color: Int, weight: Float = 0f, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.WHITE)
        v.textSize = 13f
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(8), dp(8), dp(8), dp(8))
        v.background = bg(color, 10)
        v.setOnClickListener { onClick() }
        val w = if (weight > 0f) 0 else ViewGroup.LayoutParams.WRAP_CONTENT
        val lp = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        v.layoutParams = lp
        return v
    }

    private fun big(t: String, color: Int, onClick: () -> Unit): TextView {
        val v = btn(t, color, 0f, onClick)
        v.textSize = 16f
        v.setPadding(dp(10), dp(12), dp(10), dp(12))
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(dp(2), dp(6), dp(2), dp(4))
        v.layoutParams = lp
        return v
    }

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(4), dp(3), dp(4), dp(3))
        return v
    }

    private fun newRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun fillRow(row: LinearLayout, items: List<Act>) {
        row.removeAllViews()
        for (a in items) row.addView(btn(a.t, a.c, 1f, a.f))
        row.visibility = vis(items.isNotEmpty())
    }

    private fun clearRows() {
        fillRow(rowA, emptyList())
        fillRow(rowB, emptyList())
        fillRow(rowC, emptyList())
        fillRow(rowD, emptyList())
    }

    private fun showPanel() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = bg(0xEE101820.toInt(), 14)
        box.setPadding(dp(6), dp(6), dp(6), dp(6))

        // шапка: перетащить, заголовок, в меню, стоп, показать точки, свернуть
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val drag = btn("≡", cGray) {}
        titleTv = label(12f, 0xFFB0BEC5.toInt())
        titleTv.maxWidth = dp(150)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        menuBtn = btn("🏠", cGray) { if (!busy) enterMenu() }
        pauseBtn = btn("⏸", cBlue) { togglePause() }
        stopBtn = btn("■", cRed) { stopBot("Остановлено кнопкой") }
        val eye = btn("👁", cGray) { toggleMarks() }
        foldBtn = btn("⌄", cGray) { expanded = !expanded; applyFold() }
        head.addView(drag)
        head.addView(titleTv)
        head.addView(menuBtn)
        head.addView(pauseBtn)
        head.addView(stopBtn)
        head.addView(eye)
        head.addView(foldBtn)

        // тело: текущее задание, одна главная кнопка, мелкие кнопки
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        promptTv = label(16f, Color.WHITE, true)
        subTv = label(12.5f, 0xFFCFD8DC.toInt())
        primaryBtn = big("", cGreen) { onPrimary() }
        rowA = newRow()
        rowB = newRow()
        rowC = newRow()
        rowD = newRow()
        b.addView(promptTv)
        b.addView(subTv)
        b.addView(primaryBtn)
        b.addView(rowA)
        b.addView(rowB)
        b.addView(rowC)
        b.addView(rowD)

        box.addView(head)
        box.addView(b, LinearLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            panelFlags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(8)
        panelLp = lp

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }

        wm.addView(box, lp)
        root = box
        body = b
        applyFold()
    }

    /** Плашка со статусом бота по центру сверху: видна прямо в игре, пока бот работает. */
    private fun showPill() {
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 12.5f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(14), dp(6), dp(14), dp(6))
        tv.background = bg(0xCC101820.toInt(), 16)
        tv.maxWidth = dp(420)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(6)
        tv.visibility = View.GONE
        wm.addView(tv, lp)
        pill = tv
    }

    private fun counters(): String = "🌾 $sPlants   🔪 $sHarv   💰 $sSales   ⚠ $sFails"

    private fun applyFold() {
        body?.visibility = if (expanded) View.VISIBLE else View.GONE
        foldBtn.text = if (expanded) "⌄" else "⌃"
    }

    private fun toggleMarks() {
        val mv = cap ?: return
        mv.showAll = !mv.showAll
        mv.invalidate()
    }

    private fun updateUi() {
        ui.removeCallbacks(ticker)
        val running = mode == Mode.RUN || (busy && active)
        stopBtn.visibility = vis(running)
        pauseBtn.visibility = vis(running)
        pauseBtn.text = if (paused) "▶" else "⏸"
        pauseBtn.background = bg(if (paused) cGreen else cBlue, 10)
        cap?.swipeMode = false
        menuBtn.visibility = vis(mode == Mode.SETUP && !busy)
        pill?.visibility = if (inGame && mode == Mode.RUN) View.VISIBLE else View.GONE

        if (mode == Mode.RUN) {
            titleTv.text = "🤖 Бот работает"
            promptTv.text = if (paused) "⏸ Пауза" else "Бот работает. Не трогай экран."
            subTv.text = note
            showPrimary(if (paused) "▶ Продолжить" else "⏸ Пауза", if (paused) cGreen else cBlue, true)
            clearRows()
            fillRow(rowA, listOf(Act("■ Стоп", cRed) { stopBot("Остановлено кнопкой") }))
            setArmed(false)
            return
        }
        if (busy) {
            titleTv.text = "TapTapBot's"
            promptTv.text = if (paused) "⏸ Пауза" else "⏳ Выполняю…"
            subTv.text = note
            primaryBtn.visibility = View.GONE
            clearRows()
            if (active) {
                fillRow(rowA, listOf(
                    Act(if (paused) "▶ Продолжить" else "⏸ Пауза", cBlue) { togglePause() },
                    Act("■ Стоп", cRed) { stopBot("Остановлено кнопкой") }
                ))
            }
            setArmed(false)
            return
        }
        when (mode) {
            Mode.MENU -> drawMenu()
            Mode.REC -> drawRec()
            else -> drawStep()
        }
        cap?.invalidate()
    }

    private fun showPrimary(t: String, color: Int, enabled: Boolean) {
        primaryBtn.visibility = View.VISIBLE
        primaryBtn.text = t
        primaryBtn.background = bg(color, 10)
        primaryBtn.alpha = if (enabled) 1f else 0.45f
    }

    // ---------- меню ----------

    private fun drawMenu() {
        when (menuPage) {
            1 -> drawSettings()
            2 -> drawTasks()
            else -> drawHome()
        }
        setArmed(false)
    }

    private fun drawHome() {
        val ready = cfg.missingPair() == null
        titleTv.text = "TapTapBot's · Hay Day"
        promptTv.text = if (ready) "Готов к работе" else "Настройка не завершена"
        val grows = (0 until cfg.fieldCount).joinToString(", ") { "П" + (it + 1) + " " + fmt(cfg.grow(it)) }
        val sale = if (cfg.first(T.SHOP, 0) != null) "каждые " + cfg.sellEvery + " посадки" else "выкл"
        subTv.text = (if (note.isNotEmpty()) note + "\n\n" else "") +
            "🌾 Полей: " + cfg.fieldCount + "   ⏱ " + grows + "\n" +
            "🏪 Продажа: " + sale + "   🧩 Задач: " + cfg.macroCount() + "\n" +
            "🧪 " + modeName(cfg.plantMode) + "   ⚓ " + cfg.list(T.ANCHOR, 0).size + "   👻 " + (if (hasRef()) "есть" else "нет")

        showPrimary(if (ready) "▶ Запустить" else "⚙ Настроить", if (ready) cGreen else cBlue, true)

        val a = ArrayList<Act>()
        if (ready) a.add(Act("⚙ Заново", cGray) { cfg.cur = 0; startSetup() })
        if (hasRef()) a.add(Act("👻", if (ghostOn) cGreen else cGray) { showGhost(!ghostOn); updateUi() })
        a.add(Act("⋯ Ещё", cGray) { menuPage = 1; updateUi() })
        fillRow(rowA, a)

        val b = ArrayList<Act>()
        if (ready && Build.VERSION.SDK_INT >= 30) {
            b.add(Act("📸 Эталон", cGray) {
                runTask("Снимаю эталон вида…", { captureRef() }, { enterMenu("📸 Эталон вида обновлён") })
            })
        }
        if (ready) {
            b.add(Act("🌱 Тест", cGray) {
                runTask("Тест посадки…", { plantOnce(cfg.cur) }, { enterMenu("🌱 Тест посадки выполнен") })
            })
            b.add(Act("🔪 Тест", cGray) {
                runTask("Тест сбора…", { harvestOnce(cfg.cur) }, { enterMenu("🔪 Тест сбора выполнен") })
            })
        }
        fillRow(rowB, b)
        fillRow(rowC, emptyList())
        fillRow(rowD, emptyList())
    }

    private fun drawSettings() {
        titleTv.text = "TapTapBot's · настройки"
        promptTv.text = "Настройки"
        val f = cfg.cur
        val shopOn = cfg.first(T.SHOP, 0) != null
        subTv.text = "📍 Поле " + (f + 1) + " из " + cfg.fieldCount + ": ⏱ " + fmt(cfg.grow(f)) + "\n" +
            "✋ Удержание " + (cfg.holdMs / 100) / 10.0 + " с   🧪 " + modeName(cfg.plantMode) + "\n" +
            "🏪 Продажа: " + (if (shopOn) "каждые " + cfg.sellEvery + " посадки, страниц " + cfg.shopPages else "выкл") + "\n" +
            "🎯 Распознавание: " + recText() + "\n" +
            "📷 Выравнивание камеры: " + (if (cfg.autoAlign) "вкл" else "выкл") +
            "   ↩ Палец назад: " + (if (cfg.returnHand > 0) "да" else "нет")
        primaryBtn.visibility = View.GONE

        fillRow(rowA, listOf(
            Act("⏱ −", cGray) { cfg.setGrow(cfg.grow(cfg.cur) - 5); updateUi() },
            Act("⏱ +", cGray) { cfg.setGrow(cfg.grow(cfg.cur) + 5); updateUi() },
            Act("✋ −", cGray) { cfg.holdMs = cfg.holdMs - 100; updateUi() },
            Act("✋ +", cGray) { cfg.holdMs = cfg.holdMs + 100; updateUi() }
        ))

        val b = ArrayList<Act>()
        if (shopOn) {
            b.add(Act("🏪 −", cGray) { cfg.sellEvery = cfg.sellEvery - 1; updateUi() })
            b.add(Act("🏪 +", cGray) { cfg.sellEvery = cfg.sellEvery + 1; updateUi() })
            b.add(Act("📄 −", cGray) { cfg.shopPages = cfg.shopPages - 1; updateUi() })
            b.add(Act("📄 +", cGray) { cfg.shopPages = cfg.shopPages + 1; updateUi() })
        }
        fillRow(rowB, b)

        val c = ArrayList<Act>()
        c.add(Act("🧪 " + modeName(cfg.plantMode), cGray) { cfg.plantMode = cfg.plantMode + 1; updateUi() })
        if (Build.VERSION.SDK_INT >= 30) {
            c.add(Act("🎯", if (cfg.useRec) cGreen else cGray) { cfg.useRec = !cfg.useRec; updateUi() })
            c.add(Act("📷", if (cfg.autoAlign) cGreen else cGray) { cfg.autoAlign = !cfg.autoAlign; updateUi() })
        }
        c.add(Act("↩ Палец", if (cfg.returnHand > 0) cGreen else cGray) {
            cfg.returnHand = if (cfg.returnHand > 0) 0 else 1
            updateUi()
        })
        fillRow(rowC, c)

        val d = ArrayList<Act>()
        d.add(Act("📍 " + (f + 1), cGray) { cfg.cur = (cfg.cur + 1) % cfg.fieldCount; updateUi() })
        if (cfg.fieldCount < Cfg.MAXF) {
            d.add(Act("➕ Поле", cGray) { cfg.cur = cfg.fieldCount; startSetup() })
        }
        if (cfg.fieldCount > 1) {
            d.add(Act("🗑 " + cfg.fieldCount, cGray) { cfg.removeField(); updateUi() })
        }
        d.add(Act("🧩 ▸", cGray) { menuPage = 2; updateUi() })
        d.add(Act("‹ Назад", cGray) { menuPage = 0; updateUi() })
        fillRow(rowD, d)
    }

    private fun drawTasks() {
        titleTv.text = "TapTapBot's · задачи"
        promptTv.text = "Свои задачи"
        val n = cfg.macroCount()
        val lines = StringBuilder()
        for (m in 0 until n) {
            val iv = cfg.macroInterval(m)
            lines.append("🧩 ").append(m + 1).append(": ").append(cfg.macroTaps(m).size).append(" нажатий, ")
            lines.append(if (iv <= 0) "выключена" else "каждые $iv мин").append("\n")
        }
        if (n == 0) lines.append("Задач нет. Запиши любую последовательность нажатий (яйца, молоко, пекарня), и бот будет повторять её по таймеру.\n")
        lines.append("Кнопка с номером меняет интервал. В конце задачи верни игру в исходный вид.")
        subTv.text = lines.toString()
        primaryBtn.visibility = View.GONE

        val a = ArrayList<Act>()
        a.add(Act("🔴 Записать", cGray) { startRec() })
        if (n > 0) a.add(Act("🏃 Прогнать", cGray) {
            runTask("Выполняю задачи…", { for (m in 0 until cfg.macroCount()) playMacro(m) }, { enterMenu("🧩 Задачи выполнены") })
        })
        fillRow(rowA, a)

        val b = ArrayList<Act>()
        for (m in 0 until n) {
            val iv = cfg.macroInterval(m)
            b.add(Act("🧩" + (m + 1) + "·" + (if (iv <= 0) "выкл" else iv.toString() + "м"), cGray) { cycleInterval(m) })
        }
        fillRow(rowB, b)

        val c = ArrayList<Act>()
        if (n > 0) c.add(Act("🗑 Последняя", cGray) { cfg.deleteMacro(cfg.macroCount() - 1); updateUi() })
        c.add(Act("‹ Назад", cGray) { menuPage = 1; updateUi() })
        fillRow(rowC, c)
        fillRow(rowD, emptyList())
    }

    private fun cycleInterval(m: Int) {
        val ivs = intArrayOf(5, 10, 15, 30, 60, 0)
        val i = ivs.indexOf(cfg.macroInterval(m))
        cfg.setMacroInterval(m, ivs[(i + 1) % ivs.size])
        updateUi()
    }

    // ---------- запись своей задачи ----------

    private fun startRec() {
        if (cfg.macroCount() >= Cfg.MAXM) {
            toast("Максимум " + Cfg.MAXM + " задач")
            return
        }
        mode = Mode.REC
        recTaps.clear()
        recLast = 0L
        note = ""
        updateUi()
    }

    private fun drawRec() {
        titleTv.text = "🔴 Запись задачи"
        promptTv.text = "Нажимай в игре всё, что нужно"
        subTv.text = "Записано нажатий: " + recTaps.size + "\n" +
            "Каждое нажатие выполняется в игре, паузы между ними запоминаются. В конце верни игру в исходный вид: закрой окна и меню."
        showPrimary("✔ Сохранить задачу", cGreen, recTaps.isNotEmpty())
        fillRow(rowA, listOf(Act("✖ Отмена", cGray) { cancelRec() }))
        fillRow(rowB, emptyList())
        fillRow(rowC, emptyList())
        fillRow(rowD, emptyList())
        setArmed(true)
    }

    private fun cancelRec() {
        recTaps.clear()
        mode = Mode.MENU
        menuPage = 2
        updateUi()
    }

    private fun saveRec() {
        if (recTaps.isEmpty()) {
            note = "⚠ Пока нет ни одного нажатия"
            updateUi()
            return
        }
        val idx = cfg.saveMacro(ArrayList(recTaps))
        if (idx < 0) {
            toast("Максимум " + Cfg.MAXM + " задач")
        } else {
            toast("🧩 Задача " + (idx + 1) + " сохранена: каждые " + cfg.macroInterval(idx) + " мин")
            jlog("🧩 Записана задача " + (idx + 1) + ": " + recTaps.size + " нажатий")
        }
        recTaps.clear()
        mode = Mode.MENU
        menuPage = 2
        updateUi()
    }

    // ---------- мастер ----------

    private fun drawStep() {
        val s = FLOW[step]
        val r = s.role
        val n = if (r != null) cfg.list(r).size else 0
        val keep = if (s.fresh) 0 else 1
        val fp = if (cfg.cur > 0 || cfg.fieldCount > 1) "Поле " + (cfg.cur + 1) + " · " else ""

        titleTv.text = fp + "шаг " + (step + 1) + " из " + FLOW.size
        promptTv.text = s.text
        val base = if (note.isNotEmpty()) note else s.hint
        subTv.text = when {
            r == T.AREA ->
                "Точек: $n из 4\n$base\nШаг строк: " + cfg.rowGap + " px (➖ чаще · ➕ реже)"
            s.kind == Kind.MULTI && s.max > 0 -> "Точек: $n из " + s.max + "\n$base"
            s.kind == Kind.MULTI -> "Точек: $n\n$base"
            else -> base
        }

        if (s.btn != null) {
            showPrimary(s.btn, if (s.kind == Kind.DO) cBlue else cGreen, !(s.kind == Kind.MULTI && n < s.min))
        } else {
            primaryBtn.visibility = View.GONE
        }

        val canErase = s.kind == Kind.MULTI && n > keep
        val a = ArrayList<Act>()
        if (canErase || prevIndex() >= 0) a.add(Act("↩ Назад", cGray) { back() })
        if (canErase) a.add(Act("🗑 Всё", cGray) { clearAll() })
        if (s.skip != null) a.add(Act(s.skip, cGray) { onSkip() })
        fillRow(rowA, a)

        val b = ArrayList<Act>()
        if (r == T.AREA) {
            b.add(Act("➖ чаще", cGray) { adjustGap(-5) })
            b.add(Act("➕ реже", cGray) { adjustGap(5) })
        }
        fillRow(rowB, b)
        fillRow(rowC, emptyList())
        fillRow(rowD, emptyList())

        cap?.swipeMode = s.kind == Kind.SWIPE
        setArmed(s.kind == Kind.TAP || s.kind == Kind.MULTI || s.kind == Kind.SWIPE)
        if (s.kind == Kind.WAIT) ui.post(ticker)
    }

    private fun say(m: String) {
        ui.post {
            note = m
            if (botMode) {
                val pre = if (paused) "⏸ " else ""
                titleTv.text = "🤖 $pre$m"
                pill?.text = pre + m + "\n" + counters()
            }
            subTv.text = m
        }
    }

    // ---------- переходы ----------

    private fun enterMenu(msg: String = "") {
        mode = Mode.MENU
        menuPage = 0
        note = msg
        updateUi()
    }

    private fun startSetup() {
        go(nextIndex(0))
    }

    private fun skipped(i: Int): Boolean {
        val s = FLOW[i]
        if (s.role == T.ANCHOR && (Build.VERSION.SDK_INT < 30 || !cfg.useRec)) return true
        if (cfg.cur > 0 && (s.kind == Kind.INFO || s.role == T.ANCHOR || i >= I_ASK)) return true
        return false
    }

    private fun nextIndex(from: Int): Int {
        var k = from
        while (k < FLOW.size && skipped(k)) k++
        return k
    }

    private fun prevIndex(): Int {
        var k = step - 1
        while (k >= 0 && skipped(k)) k--
        return k
    }

    private fun go(n: Int) {
        mode = Mode.SETUP
        step = n.coerceIn(0, FLOW.size - 1)
        note = ""
        val s = FLOW[step]
        val r = s.role
        if (r != null && s.fresh) cfg.clear(r)
        updateUi()
    }

    private fun advance() {
        val n = nextIndex(step + 1)
        if (n >= FLOW.size) {
            if (cfg.cur >= cfg.fieldCount) cfg.fieldCount = cfg.cur + 1
            jlog("Настройка поля " + (cfg.cur + 1) + " завершена")
            enterMenu(
                if (cfg.cur > 0) "✅ Поле " + (cfg.cur + 1) + " настроено."
                else "✅ Настройка завершена. Жми «▶ Запустить»."
            )
        } else {
            go(n)
        }
    }

    private fun back() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role
        if (s.kind == Kind.MULTI && r != null) {
            val keep = if (s.fresh) 0 else 1
            if (cfg.list(r).size > keep) {
                cfg.removeLast(r)
                note = "↩ Последняя точка стёрта"
                updateUi()
                return
            }
        }
        val p = prevIndex()
        if (p >= 0) go(p) else enterMenu()
    }

    private fun clearAll() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role ?: return
        if (s.kind == Kind.MULTI) {
            cfg.truncate(r, if (s.fresh) 0 else 1)
            note = "🗑 Точки стёрты"
            updateUi()
        }
    }

    private fun adjustGap(d: Int) {
        if (busy || botMode) return
        cfg.rowGap = cfg.rowGap + d
        updateUi()
    }

    private fun onPrimary() {
        if (mode == Mode.RUN) {
            togglePause()
            return
        }
        if (busy) return
        if (mode == Mode.REC) {
            saveRec()
            return
        }
        if (mode == Mode.MENU) {
            if (cfg.missingPair() == null) startBot() else {
                cfg.cur = 0
                startSetup()
            }
            return
        }
        val s = FLOW[step]
        when (s.kind) {
            Kind.MULTI -> {
                val r = s.role
                val n = if (r != null) cfg.list(r).size else 0
                if (n < s.min) {
                    note = "⚠ Нужно минимум " + s.min + " точки"
                    updateUi()
                } else {
                    advance()
                }
            }
            Kind.WAIT -> {
                if (plantedAt > 0) {
                    val sec = ((System.currentTimeMillis() - plantedAt) / 1000).toInt() + 3
                    cfg.setGrow(sec)
                    toast("⏱ Время созревания: " + fmt(cfg.grow(cfg.cur)))
                }
                advance()
            }
            Kind.ASK, Kind.INFO -> advance()
            Kind.DO -> doAction(s.act ?: "")
            else -> {}
        }
    }

    private fun onSkip() {
        if (busy || botMode) return
        when (FLOW[step].kind) {
            Kind.ASK -> {
                cfg.clear(T.SHOP)
                enterMenu("✅ Настройка завершена (без продажи). Жми «▶ Запустить».")
            }
            Kind.DO -> {
                val ci = FLOW.indexOfFirst { it.role == T.CLOSE }
                if (ci >= 0) go(ci) else advance()
            }
            else -> advance()
        }
    }

    // ---------- нажатия пользователя ----------

    private fun onTapped(x: Float, y: Float) {
        if (busy || (mode != Mode.SETUP && mode != Mode.REC)) return
        val p = P(x, y)

        if (mode == Mode.REC) {
            val now = System.currentTimeMillis()
            val dt = if (recLast == 0L) 700L else (now - recLast).coerceIn(600L, 8000L)
            recTaps.add(MTap(p, dt))
            recLast = now
            busy = true
            setArmed(false)
            replayTap(p, 700) {
                busy = false
                recLast = System.currentTimeMillis()
                updateUi()
            }
            return
        }

        val s = FLOW[step]
        if (s.kind == Kind.SWIPE) {
            note = "Нужен свайп: проведи пальцем по слотам"
            updateUi()
            return
        }
        if (s.kind != Kind.TAP && s.kind != Kind.MULTI) return
        val r = s.role
        if (r != null) {
            if (s.kind == Kind.MULTI && s.max > 0 && cfg.list(r).size >= s.max) {
                note = "Уже " + s.max + " точки. Жми «Готово» или ↩"
                updateUi()
                return
            }
            cfg.add(r, p)
            if (r == T.AD) lastAd = System.currentTimeMillis()
        }
        if (s.kind == Kind.MULTI) note = "✔ Запомнил"

        if (s.sample && r != null && cfg.useRec && Build.VERSION.SDK_INT >= 30) {
            // сначала убираем жёлтую подсветку, потом снимаем эталон цвета, потом повторяем нажатие
            busy = true
            setArmed(false)
            Thread {
                try { Thread.sleep(200) } catch (_: InterruptedException) {}
                val c = colorAt(p)
                ui.post {
                    if (c != null) {
                        if (r == T.ANCHOR) cfg.addAnchorColor(c) else cfg.setRef(r, c)
                        toast("🎯 Эталон цвета записан")
                    } else {
                        if (r == T.ANCHOR) cfg.removeLast(T.ANCHOR)
                        toast("⚠ Эталон не записался, попробуй ещё раз")
                    }
                    finishTap(s, p)
                }
            }.start()
            return
        }
        finishTap(s, p)
    }

    /** Пользователь провёл пальцем в шаге листания лавки: повторяем свайп в игре по-настоящему и проверяем по картинке. */
    private fun onSwiped(a: P, b: P, ms: Long) {
        if (busy || mode != Mode.SETUP) return
        if (FLOW[step].kind != Kind.SWIPE) return
        cfg.clear(T.SWIPE)
        cfg.add(T.SWIPE, a)
        cfg.add(T.SWIPE, b)
        cfg.swipeMs = ms.toInt()
        var ok = true
        runTask(
            "Листаю лавку…",
            { pause(350); ok = swipePage(a, b) },
            {
                if (ok) {
                    if (cfg.shopPages < 2) cfg.shopPages = 2
                    toast("✅ Лавка пролистнулась. Отметь слоты этой страницы")
                    jlog("↔ Свайп лавки записан, страниц " + cfg.shopPages)
                    advance()
                } else {
                    note = "⚠ Лавка не пролистнулась. Проведи ещё раз: подлиннее и не слишком быстро"
                    jlog("⚠ Свайп лавки не сработал")
                    updateUi()
                }
            }
        )
    }

    private fun finishTap(s: Stp, p: P) {
        if (s.replay) {
            busy = true
            setArmed(false)
            replayTap(p, s.settle) {
                busy = false
                if (s.kind == Kind.TAP) advance() else updateUi()
            }
        } else {
            busy = false
            if (s.kind == Kind.TAP) advance() else updateUi()
        }
    }

    /** Повторяет нажатие пользователя в игре (слой уже стал прозрачным для касаний). */
    private fun replayTap(p: P, settle: Long, then: () -> Unit) {
        ui.postDelayed({
            val path = Path()
            path.moveTo(p.x, p.y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            val cb = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ui.postDelayed({ then() }, settle) }
                override fun onCancelled(d: GestureDescription?) { ui.postDelayed({ then() }, 300) }
            }
            if (!dispatchGesture(g, cb, null)) ui.postDelayed({ then() }, 300)
        }, 180)
    }

    // ---------- задачи бота вне основного цикла ----------

    private fun runTask(msg: String, work: () -> Unit, done: () -> Unit) {
        if (busy || botMode) return
        busy = true
        active = true
        taskAborted = false
        paused = false
        note = msg
        setArmed(false)
        updateUi()
        worker = Thread {
            try {
                work()
            } catch (_: InterruptedException) {
            } catch (e: Throwable) {
                jlog("💥 Ошибка в задаче: " + e)
                toast("Ошибка: " + (e.message ?: e.javaClass.simpleName))
            } finally {
                active = false
                ui.post {
                    busy = false
                    paused = false
                    if (taskAborted) {
                        taskAborted = false
                        enterMenu("⏹ Остановлено")
                    } else {
                        done()
                    }
                }
            }
        }.also { it.start() }
    }

    private fun doAction(act: String) {
        when (act) {
            "plant" -> runTask(
                "Сажаю по области…",
                { plantOnce(cfg.cur); plantedAt = System.currentTimeMillis() },
                { advance() }
            )
            "harvest" -> runTask(
                "Собираю по области…",
                { harvestOnce(cfg.cur); pause(800); if (cfg.cur == 0) captureRef() },
                { advance() }
            )
            "swipe2" -> {
                val sw = cfg.list(T.SWIPE, 0)
                if (sw.size < 2) {
                    advance()
                } else {
                    val a = sw[0]
                    val b = sw[1]
                    var ok = true
                    runTask(
                        "Листаю лавку дальше…",
                        { pause(300); ok = swipePage(a, b) },
                        {
                            if (ok) {
                                if (cfg.shopPages < 3) cfg.shopPages = 3
                                toast("✅ Страница 3. Отметь слоты")
                                advance()
                            } else {
                                note = "⚠ Дальше лавка не листается. Жми «Это последняя страница»"
                                updateUi()
                            }
                        }
                    )
                }
            }
        }
    }

    // ---------- основной цикл ----------

    private fun startBot() {
        val m = cfg.missingPair()
        if (m != null) {
            cfg.cur = m.first
            val i = FLOW.indexOfFirst { it.role == m.second }
            go(if (i >= 0) i else 0)
            note = "⚠ Не хватает: " + m.second.icon + " " + m.second.label + " (поле " + (m.first + 1) + ")"
            updateUi()
            return
        }
        mode = Mode.RUN
        busy = false
        active = true
        paused = false
        gestureFails = 0
        stopReason = null
        sPlants = 0
        sHarv = 0
        sSales = 0
        sFails = 0
        runStart = System.currentTimeMillis()
        for (i in lastMacro.indices) lastMacro[i] = runStart
        stats.add("runs")
        jlog("▶ Запуск: полей " + cfg.fieldCount + ", задач " + cfg.macroCount() + ", посадка: " + modeName(cfg.plantMode))
        showGhost(false)
        note = "Запускаю…"
        expanded = false          // панель сворачивается, чтобы не закрывать игру
        applyFold()
        keepAwake(true)
        setArmed(false)
        updateUi()
        pill?.text = "Запускаю…\n" + counters()
        worker = Thread {
            try {
                loop()
            } catch (_: InterruptedException) {
            } catch (e: Throwable) {
                jlog("💥 Ошибка в цикле: " + e)
                if (stopReason == null) stopReason = "Ошибка: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                active = false
                paused = false
                val why = stopReason ?: "Бот остановлен"
                stopReason = null
                stats.add("runMs", System.currentTimeMillis() - runStart)
                jlog("⏹ $why. " + counters())
                ui.post {
                    keepAwake(false)
                    expanded = true
                    applyFold()
                    enterMenu("⏹ $why")
                }
            }
        }.also { it.start() }
    }

    private fun togglePause() {
        if (!active) return
        paused = !paused
        val msg = if (paused) "⏸ Пауза: остановлюсь после текущего действия" else "▶ Продолжаю"
        jlog(msg)
        note = msg
        pill?.text = msg + "\n" + counters()
        updateUi()
    }

    private fun waitIfPaused() {
        while (paused && active) Thread.sleep(150)
    }

    private fun stopBot(reason: String? = null) {
        if (reason != null) stopReason = reason
        if (mode != Mode.RUN) taskAborted = true
        paused = false
        active = false
        worker?.interrupt()
    }

    private fun plantOnce(f: Int) {
        val fld = cfg.first(T.FIELD, f)!!
        tap(fld)
        pause(1500)   // меню открывается, камера доезжает до места
        holdDrag(cfg.first(T.WHEAT, f)!!, cfg.pathFrom(fld, f), fld)
        pause(900)
    }

    private fun harvestOnce(f: Int) {
        val fld = cfg.first(T.HFIELD, f)!!
        tap(fld)
        pause(1500)
        holdDrag(cfg.first(T.SICKLE, f)!!, cfg.pathFrom(fld, f), fld)
        pause(1500)
    }

    /** Якоря на месте? Если проверить нельзя, не блокируем. */
    private fun anchorsOk(): Boolean {
        val pts = cfg.list(T.ANCHOR, 0)
        val cols = cfg.anchorColors()
        if (!cfg.useRec || Build.VERSION.SDK_INT < 30 || pts.size < 2 || cols.size != pts.size) return true
        val now = shot(pts) ?: return true
        var bad = 0
        for (i in pts.indices) if (!near(now[i], cols[i], 60)) bad++
        return bad <= (if (pts.size >= 3) 1 else 0)
    }

    // ---------- выравнивание камеры по картинке ----------

    private fun toGray(bmp: Bitmap, w: Int): Gray {
        val h = (bmp.height * w.toFloat() / bmp.width).toInt()
        val sc = Bitmap.createScaledBitmap(bmp, w, h, true)
        val px = IntArray(w * h)
        sc.getPixels(px, 0, w, 0, 0, w, h)
        if (sc !== bmp) sc.recycle()
        val d = IntArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            d[i] = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
        }
        return Gray(w, h, d)
    }

    private fun loadRefGray(): Gray? {
        val f = File(filesDir, "ref.png")
        if (!f.exists()) return null
        val b = BitmapFactory.decodeFile(f.path) ?: return null
        val g = toGray(b, b.width)
        b.recycle()
        return g
    }

    private fun variance(g: Gray, cx: Int, cy: Int, half: Int): Int {
        var sum = 0L
        var sq = 0L
        var n = 0
        for (y in -half until half step 4) {
            for (x in -half until half step 4) {
                val v = g.d[(cy + y) * g.w + cx + x]
                sum += v
                sq += (v * v).toLong()
                n++
            }
        }
        val mean = sum / n
        return ((sq / n) - mean * mean).toInt()
    }

    /** Ищет, куда сместился кусочек эталона на текущей картинке. Возвращает сдвиг или null, если пик неуверенный. */
    private fun matchTile(ref: Gray, cur: Gray, cx: Int, cy: Int, half: Int, rad: Int): Pair<Int, Int>? {
        fun ssdAt(ox: Int, oy: Int): Long {
            var ssd = 0L
            for (y in -half until half step 2) {
                val rb = (cy + y) * ref.w + cx
                val cb = (cy + y + oy) * cur.w + cx + ox
                for (x in -half until half step 2) {
                    val d = ref.d[rb + x] - cur.d[cb + x]
                    ssd += (d * d).toLong()
                }
            }
            return ssd
        }
        var best = Long.MAX_VALUE
        var bx = 0
        var by = 0
        var sum = 0L
        var cnt = 0
        for (oy in -rad..rad step 2) {
            for (ox in -rad..rad step 2) {
                val v = ssdAt(ox, oy)
                sum += v
                cnt++
                if (v < best) {
                    best = v
                    bx = ox
                    by = oy
                }
            }
        }
        var rb = best
        var rx = bx
        var ry = by
        for (oy in by - 1..by + 1) {
            for (ox in bx - 1..bx + 1) {
                if (ox < -rad || ox > rad || oy < -rad || oy > rad) continue
                val v = ssdAt(ox, oy)
                if (v < rb) {
                    rb = v
                    rx = ox
                    ry = oy
                }
            }
        }
        val mean = sum / cnt
        if (rb * 100 >= mean * 35) return null
        return Pair(rx, ry)
    }

    private fun median(v: List<Float>): Float {
        val s = v.sorted()
        return s[s.size / 2]
    }

    /** Общий сдвиг картинки относительно эталона (в пикселях эталона) по самым «рельефным» участкам середины экрана. */
    private fun estimateShift(ref: Gray, cur: Gray): Pair<Float, Float>? {
        if (ref.w != cur.w || ref.h != cur.h) return null
        val half = 24
        val rad = 48
        val margin = half + rad
        val x0 = (ref.w * 0.20f).toInt() + margin
        val x1 = (ref.w * 0.80f).toInt() - margin
        val y0 = (ref.h * 0.16f).toInt() + margin
        val y1 = (ref.h * 0.82f).toInt() - margin
        if (x1 < x0 || y1 < y0) return null
        val tiles = ArrayList<IntArray>()
        var cy = y0
        while (cy <= y1) {
            var cx = x0
            while (cx <= x1) {
                tiles.add(intArrayOf(cx, cy, variance(ref, cx, cy, half)))
                cx += half * 2
            }
            cy += half * 2
        }
        tiles.sortByDescending { it[2] }
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        for (t in tiles.take(10)) {
            if (t[2] < 150) continue
            val r = matchTile(ref, cur, t[0], t[1], half, rad) ?: continue
            xs.add(r.first.toFloat())
            ys.add(r.second.toFloat())
        }
        if (xs.size < 3) return null
        val mx = median(xs)
        val my = median(ys)
        var agree = 0
        for (i in xs.indices) if (abs(xs[i] - mx) <= 3f && abs(ys[i] - my) <= 3f) agree++
        if (agree < 3 || agree * 100 / xs.size < 60) return null
        return Pair(mx, my)
    }

    /**
     * Сравнивает экран с эталонным видом и, если карта сместилась, тянет её обратно медленным свайпом.
     * true: камера на месте или проверить нельзя. false: съехала и вернуть не удалось.
     */
    private fun alignCamera(): Boolean {
        if (!cfg.autoAlign || !cfg.useRec || Build.VERSION.SDK_INT < 30) return true
        val ref = loadRefGray() ?: return true
        val b = wm.maximumWindowMetrics.bounds
        val k = b.width().toFloat() / ref.w
        for (attempt in 0..2) {
            if (!active) return true
            val bmp = takeBitmap() ?: return true
            val cur = toGray(bmp, ref.w)
            bmp.recycle()
            val sh = estimateShift(ref, cur) ?: return true   // оценить не удалось, не мешаем
            val dx = sh.first * k
            val dy = sh.second * k
            val mag = hypot(dx, dy)
            if (mag < 8f) return true
            if (attempt == 2) return mag < 25f
            say("📷 Камера сместилась на " + mag.toInt() + " px, возвращаю")
            jlog("📷 Сдвиг камеры " + dx.toInt() + "," + dy.toInt() + " px, подтягиваю обратно")
            // содержимое ушло на (dx, dy), значит палец должен пройти на (-dx, -dy)
            val vx = -dx
            val vy = -dy
            val cx = b.width() / 2f
            val cy = b.height() / 2f
            gentleSwipe(P(cx - vx / 2f, cy - vy / 2f), P(cx + vx / 2f, cy + vy / 2f), (500 + mag * 3).toLong())
            pause(900)
        }
        return true
    }

    private fun afterAction(): Boolean {
        if (!active) return false
        if (alignCamera()) return true
        cameraMismatch()
        return false
    }

    /** Камера не там: показываем призрак эталона и останавливаемся. Двигать камеру автоматически не пытаемся. */
    private fun cameraMismatch() {
        sFails++
        stats.add("fails")
        ui.post { if (hasRef()) showGhost(true) }
        stopBot("Камера не совпала с эталоном. Совмести картинку с 👻 и жми «▶ Запустить»")
    }

    private fun doSale(round: Int): Boolean {
        if (sell(round)) {
            fails = 0
        } else {
            fails++
            sFails++
            stats.add("fails")
        }
        if (fails >= 3) {
            stopBot("3 сбоя продажи подряд")
            return false
        }
        return afterAction()
    }

    private fun loop() {
        if (!anchorsOk()) {
            cameraMismatch()
            return
        }
        val n = cfg.fieldCount
        val tp = LongArray(n)
        val sellOn = cfg.first(T.SHOP, 0) != null
        val every = cfg.sellEvery
        var plants = 0
        fails = 0

        // первая посадка на всех полях
        for (f in 0 until n) {
            if (!active) return
            if (f > 0 && !anchorsOk()) {
                cameraMismatch()
                return
            }
            say("Поле " + (f + 1) + ": посадка 🌾")
            plantOnce(f)
            tp[f] = System.currentTimeMillis()
            if (!afterAction()) return
            sPlants++
            stats.add("plants")
            plants++
            if (sellOn && plants % every == 0 && !doSale(plants)) return
        }

        // дальше по кругу: берём поле, которое созреет раньше всех
        while (active) {
            var nf = 0
            for (f in 1 until n) if (tp[f] + growMs(f) < tp[nf] + growMs(nf)) nf = f
            waitRipe(nf, tp[nf])
            if (!active) return
            if (!anchorsOk()) {
                cameraMismatch()
                return
            }
            say("Поле " + (nf + 1) + ": сбор 🔪")
            harvestOnce(nf)
            sHarv++
            stats.add("harvests")
            if (!afterAction()) return
            pause(Random.nextLong(0, 500))
            say("Поле " + (nf + 1) + ": посадка 🌾")
            plantOnce(nf)
            tp[nf] = System.currentTimeMillis()
            if (!afterAction()) return
            sPlants++
            stats.add("plants")
            plants++
            if (sellOn && plants % every == 0 && !doSale(plants)) return
        }
    }

    /** Ждёт, пока поле f созреет: по цвету грядки, а если не видно — по таймеру. Между делом запускает свои задачи. */
    private fun waitRipe(f: Int, tPlant: Long) {
        val label = "Поле " + (f + 1) + ": растёт ⏳"
        val pt = cfg.first(T.HFIELD, f) ?: return
        val gm = growMs(f)
        val ref = if (cfg.useRec && Build.VERSION.SDK_INT >= 30) cfg.getRef(T.HFIELD, f) else null
        if (ref == null) {
            idleUntil(tPlant + gm + Random.nextLong(0, 6000), label)
            return
        }
        idleUntil(tPlant + gm * 8 / 10, label)   // раньше 80% времени роста смотреть нет смысла
        while (active) {
            val c = colorAt(pt)
            if (c != null && near(c, ref)) {
                say("Поле " + (f + 1) + ": созрела 🌾")
                pause(300 + Random.nextLong(0, 500))
                return
            }
            if (System.currentTimeMillis() - tPlant > gm + 45_000L) {
                say("Спелую не вижу, иду по таймеру")
                return
            }
            idleUntil(System.currentTimeMillis() + 2000, label)
        }
    }

    private fun idleUntil(end: Long, label: String) {
        while (active && System.currentTimeMillis() < end) {
            val left = end - System.currentTimeMillis()
            say(label + " " + fmt((left / 1000).toInt()))
            pause(minOf(left, 1000L))
            if (active && !runMacros()) return
        }
    }

    // ---------- свои задачи ----------

    /** Запускает задачи, у которых подошло время. false — камера сдвинулась, бот остановлен. */
    private fun runMacros(): Boolean {
        val n = cfg.macroCount()
        for (m in 0 until n) {
            val iv = cfg.macroInterval(m)
            if (iv <= 0) continue
            if (System.currentTimeMillis() - lastMacro[m] < iv * 60_000L) continue
            playMacro(m)
            lastMacro[m] = System.currentTimeMillis()
            if (active && !anchorsOk()) {
                cameraMismatch()
                return false
            }
        }
        return true
    }

    private fun playMacro(m: Int) {
        val taps = cfg.macroTaps(m)
        say("🧩 Задача " + (m + 1) + "…")
        jlog("🧩 Задача " + (m + 1) + ": " + taps.size + " нажатий")
        stats.add("macros")
        for (t in taps) {
            if (!active) return
            pause(t.dtMs)
            tap(t.p)
        }
        pause(900)
    }

    // ---------- продажа ----------

    /** Слоты страницы pg: свои, если отмечены, иначе как на предыдущей странице. */
    private fun slotsFor(pg: Int): List<P> {
        val l1 = cfg.list(T.SLOT, 0)
        val l2 = cfg.list(T.SLOT2, 0)
        val l3 = cfg.list(T.SLOT3, 0)
        return when {
            pg == 0 -> l1
            pg == 1 -> if (l2.isNotEmpty()) l2 else l1
            else -> if (l3.isNotEmpty()) l3 else (if (l2.isNotEmpty()) l2 else l1)
        }.toList()
    }

    /** Уменьшенная яркостная картинка экрана для сравнения «до и после». */
    private fun grid(): IntArray? {
        val bmp = takeBitmap() ?: return null
        val gw = 32
        val gh = 18
        val out = IntArray(gw * gh)
        for (y in 0 until gh) {
            for (x in 0 until gw) {
                val px = bmp.getPixel(
                    ((x + 0.5f) * bmp.width / gw).toInt().coerceIn(0, bmp.width - 1),
                    ((y + 0.5f) * bmp.height / gh).toInt().coerceIn(0, bmp.height - 1)
                )
                out[y * gw + x] = (Color.red(px) * 30 + Color.green(px) * 59 + Color.blue(px) * 11) / 100
            }
        }
        bmp.recycle()
        return out
    }

    private fun changedPercent(a: IntArray, b: IntArray): Int {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 28) n++
        return n * 100 / a.size
    }

    /**
     * Листает лавку на следующую страницу и по картинке проверяет, что экран изменился.
     * Если нет, пробует ещё раз подлиннее и помедленнее. Если проверить нельзя, считает, что получилось.
     */
    private fun swipePage(a: P, b: P): Boolean {
        val rec = cfg.useRec && Build.VERSION.SDK_INT >= 30
        val before = if (rec) grid() else null
        gentleSwipe(a, b, cfg.swipeMs.toLong())
        pause(1000)
        if (before == null) return true
        val after = grid() ?: return true
        if (changedPercent(before, after) >= 8) return true
        // ещё раз: на четверть длиннее и в полтора раза медленнее
        val bx = a.x + (b.x - a.x) * 1.25f
        val by = a.y + (b.y - a.y) * 1.25f
        gentleSwipe(a, P(bx, by), (cfg.swipeMs * 1.5).toLong())
        pause(1000)
        val after2 = grid() ?: return true
        return changedPercent(before, after2) >= 8
    }

    private fun sell(round: Int): Boolean {
        val shop = cfg.first(T.SHOP, 0) ?: return true
        val item = cfg.first(T.ITEM, 0) ?: return true
        val extra = cfg.list(T.EXTRA, 0).toList()
        val ad = cfg.first(T.AD, 0)
        val put = cfg.first(T.PUT, 0) ?: return true
        val close = cfg.first(T.CLOSE, 0) ?: return true
        val sw = cfg.list(T.SWIPE, 0).toList()
        val pages = if (sw.size >= 2) cfg.shopPages else 1
        val rec = cfg.useRec && Build.VERSION.SDK_INT >= 30
        val shopRef = if (rec) cfg.getRef(T.CLOSE, 0) else null
        val lotRef = if (rec) cfg.getRef(T.PUT, 0) else null
        val itemRef = if (rec) cfg.getRef(T.ITEM, 0) else null

        say("Продажа $round: открываю лавку 🏪")
        tap(shop)
        pause(1800)
        if (shopRef != null && !waitColor(close, shopRef, 6000)) {
            say("Лавка не открылась, пробую ещё раз")
            tap(shop)
            pause(1800)
            if (!waitColor(close, shopRef, 6000)) {
                say("⚠ Лавка не открылась, продажу пропускаю")
                jlog("⚠ Лавка не открылась")
                return false
            }
        }
        var sold = 0
        var flipped = 0   // сколько раз успешно пролистали вперёд
        for (pg in 0 until pages) {
            if (!active) return true
            if (pg > 0) {
                say("Продажа $round: страница " + (pg + 1) + " ↔")
                if (!swipePage(sw[0], sw[1])) {
                    say("⚠ Лавка не листается, остальные страницы пропускаю")
                    jlog("⚠ Лавка не пролистнулась на странице " + (pg + 1))
                    break
                }
                flipped++
                pause(500)
            }
            val pageSlots = slotsFor(pg)
            for ((i, slot) in pageSlots.withIndex()) {
                if (!active) return true
                say("Продажа $round: стр. " + (pg + 1) + ", слот " + (i + 1) + " из " + pageSlots.size + " 🧺")
                tap(slot); pause(1300 + Random.nextLong(0, 300))   // забрать выручку
                tap(slot); pause(1300 + Random.nextLong(0, 300))   // открыть выбор лота
                if (itemRef != null && !waitColor(item, itemRef, 2500)) {
                    // выбора товара нет: слот занят (лот ещё висит), не жмём зря
                    say("Слот " + (i + 1) + " занят, пропускаю")
                    jlog("Стр. " + (pg + 1) + ", слот " + (i + 1) + " занят, пропущен")
                    if (shopRef != null && !waitColor(close, shopRef, 1500)) {
                        say("⚠ Лавка закрылась, выхожу")
                        return false
                    }
                    continue
                }
                tap(item); pause(900)
                for (e in extra) { tap(e); pause(700) }
                if (lotRef != null && !waitColor(put, lotRef, 4000)) {
                    say("⚠ Окно лота не открылось, закрываю лавку")
                    jlog("⚠ Окно лота не открылось")
                    tap(close)
                    pause(1200)
                    return false
                }
                if (ad != null && System.currentTimeMillis() - lastAd >= adCooldownMs) {
                    tap(ad)
                    lastAd = System.currentTimeMillis()
                    pause(900)
                }
                tap(put); pause(1500)
                sold++
                sSales++
                stats.add("sales")
            }
        }
        // вернуть лавку на первую страницу
        for (k in 0 until flipped) {
            if (!active) break
            gentleSwipe(sw[1], sw[0], cfg.swipeMs.toLong())
            pause(900)
        }
        tap(close)
        pause(1200)
        jlog("🏪 Продажа " + round + ": выставлено " + sold + " (страниц " + (flipped + 1) + ")")
        return true
    }

    // ---------- распознавание экрана и эталон вида (скриншот через службу, Android 11+) ----------

    private fun near(a: Int, b: Int, tol: Int = 48): Boolean {
        val dr = Color.red(a) - Color.red(b)
        val dg = Color.green(a) - Color.green(b)
        val db = Color.blue(a) - Color.blue(b)
        return dr * dr + dg * dg + db * db < tol * tol
    }

    /** true — цвет в точке совпал с эталоном. Если скриншот не удаётся, не блокируем бота. */
    private fun waitColor(p: P, ref: Int, timeoutMs: Long): Boolean {
        val t0 = System.currentTimeMillis()
        while (active) {
            val c = colorAt(p) ?: return true
            if (near(c, ref)) return true
            if (System.currentTimeMillis() - t0 > timeoutMs) return false
            pause(600)
        }
        return false
    }

    private fun colorAt(p: P): Int? = shot(listOf(p))?.firstOrNull()

    private fun toSoft(r: AccessibilityService.ScreenshotResult): Bitmap? {
        val hb = r.hardwareBuffer
        val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
        hw?.recycle()
        hb.close()
        return soft
    }

    /** Скриншот экрана. Вызывать не из главного потока. */
    private fun takeBitmap(): Bitmap? {
        if (Build.VERSION.SDK_INT < 30) return null
        for (attempt in 0..1) {
            val latch = CountDownLatch(1)
            val res = AtomicReference<Bitmap?>(null)
            ui.post {
                try {
                    takeScreenshot(
                        Display.DEFAULT_DISPLAY,
                        shotExec,
                        object : AccessibilityService.TakeScreenshotCallback {
                            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                                try { res.set(toSoft(r)) } catch (_: Exception) {}
                                latch.countDown()
                            }

                            override fun onFailure(errorCode: Int) {
                                latch.countDown()
                            }
                        }
                    )
                } catch (_: Exception) {
                    latch.countDown()
                }
            }
            latch.await(3, TimeUnit.SECONDS)
            val out = res.get()
            if (out != null) return out
            Thread.sleep(450)   // скриншоты можно делать не чаще раза в треть секунды
        }
        return null
    }

    /** Средний цвет небольших участков вокруг точек. */
    private fun shot(points: List<P>): List<Int>? {
        val soft = takeBitmap() ?: return null
        val bounds = wm.maximumWindowMetrics.bounds
        val sx = soft.width.toFloat() / bounds.width()
        val sy = soft.height.toFloat() / bounds.height()
        val out = ArrayList<Int>()
        for (p in points) {
            val cx = (p.x * sx).toInt().coerceIn(3, soft.width - 4)
            val cy = (p.y * sy).toInt().coerceIn(3, soft.height - 4)
            var rr = 0
            var gg = 0
            var bb = 0
            var n = 0
            for (dy in -3..3 step 2) {
                for (dx in -3..3 step 2) {
                    val px = soft.getPixel(cx + dx, cy + dy)
                    rr += Color.red(px)
                    gg += Color.green(px)
                    bb += Color.blue(px)
                    n++
                }
            }
            out.add(Color.rgb(rr / n, gg / n, bb / n))
        }
        soft.recycle()
        return out
    }

    private fun hasRef(): Boolean = File(filesDir, "ref.png").exists()

    /** Призрак: полупрозрачный эталонный вид поверх игры, чтобы совместить камеру руками. */
    private fun showGhost(on: Boolean) {
        val g = ghost ?: return
        if (on) {
            g.reload()
            if (!g.hasImage()) {
                toast("Эталона вида пока нет")
                ghostOn = false
                g.visibility = View.GONE
                return
            }
        }
        ghostOn = on
        g.visibility = if (on && inGame) View.VISIBLE else View.GONE
    }

    /** Запоминает текущий вид как эталон (без нашей панели на снимке). */
    private fun captureRef(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        ui.post {
            root?.visibility = View.INVISIBLE
            cap?.visibility = View.INVISIBLE
            ghost?.visibility = View.GONE
        }
        Thread.sleep(350)
        val bmp = takeBitmap()
        ui.post {
            root?.visibility = View.VISIBLE
            cap?.visibility = View.VISIBLE
            ghost?.visibility = if (ghostOn && inGame) View.VISIBLE else View.GONE
        }
        if (bmp == null) return false
        val w = 800
        val h = (bmp.height * w.toFloat() / bmp.width).toInt()
        val small = Bitmap.createScaledBitmap(bmp, w, h, true)
        bmp.recycle()
        try {
            FileOutputStream(File(filesDir, "ref.png")).use { small.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {
            small.recycle()
            return false
        }
        small.recycle()
        return true
    }

    // ---------- жесты ----------

    private fun pause(ms: Long, label: String? = null) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        var left = ms
        var shown = -1L
        var tick = 0
        while (left > 0 && active) {
            if (paused) {
                waitIfPaused()
                continue
            }
            if (label != null) {
                val s = left / 1000
                if (s != shown) {
                    shown = s
                    say(label + " " + fmt(s.toInt()))
                }
            }
            if (botMode && ++tick % 10 == 0 && !pm.isInteractive) {
                stopBot("Экран погас")
                return
            }
            Thread.sleep(minOf(left, 200L))
            left -= 200L
        }
    }

    private fun jit(a: Float) = (Random.nextFloat() * 2f - 1f) * a
    private fun j(v: Float) = v + jit(5f)

    private fun tap(p: P) {
        waitIfPaused()
        val path = Path()
        path.moveTo(j(p.x), j(p.y))
        play(GestureDescription.StrokeDescription(path, 0, 40L + Random.nextLong(0, 40)))
        // режим «как человек»: совсем крошечная случайная пауза после нажатия
        if (cfg.plantMode == 3) Thread.sleep(Random.nextLong(60, 220))
    }

    private fun drag(start: P, pts: List<P>) {
        val path = Path()
        path.moveTo(j(start.x), j(start.y))
        for (q in pts) path.lineTo(q.x + jit(2f), q.y + jit(2f))
        val len = Geo.length(start, pts)
        val dur = (len / 0.5f).toLong().coerceIn(900L, 50_000L)   // примерно 500 px в секунду
        play(GestureDescription.StrokeDescription(path, 0, dur))
    }

    private fun waypoints(pts: List<P>, stepPx: Float): List<P> {
        val out = ArrayList<P>()
        out.add(pts[0])
        for (i in 1 until pts.size) {
            val a = pts[i - 1]
            val b = pts[i]
            val d = hypot(b.x - a.x, b.y - a.y)
            val n = max(1, ceil(d / stepPx).toInt())
            for (k in 1..n) out.add(P(a.x + (b.x - a.x) * k / n, a.y + (b.y - a.y) * k / n))
        }
        return out
    }

    /** Аккуратный свайп: основная часть быстрее, последние 15% пути медленно, чтобы игра не подхватила инерцию. */
    private fun gentleSwipe(a: P, b: P, ms: Long) {
        waitIfPaused()
        val dur = ms.coerceIn(400L, 2500L)
        val ax = a.x + jit(3f)
        val ay = a.y + jit(3f)
        val bx = b.x + jit(3f)
        val by = b.y + jit(3f)
        if (Build.VERSION.SDK_INT < 26) {
            val p = Path()
            p.moveTo(ax, ay)
            p.lineTo(bx, by)
            play(GestureDescription.StrokeDescription(p, 0, dur))
            return
        }
        val mx = ax + (bx - ax) * 0.85f
        val my = ay + (by - ay) * 0.85f
        val p1 = Path()
        p1.moveTo(ax, ay)
        p1.lineTo(mx, my)
        val s1 = GestureDescription.StrokeDescription(p1, 0, (dur * 0.65).toLong(), true)
        play(s1)
        val p2 = Path()
        p2.moveTo(mx, my)
        p2.lineTo(bx, by)
        val s2 = s1.continueStroke(p2, 0, (dur * 0.35).toLong(), true)
        play(s2)
        val p3 = Path()
        p3.moveTo(bx, by)
        play(s2.continueStroke(p3, 0, 120, false))
    }

    /**
     * Как живой палец: зажимаем иконку (культура или серп) и держим, слегка «вытягиваем» её из меню,
     * несём к выбранной грядке и дальше, не отпуская, ведём по маршруту. В конце, всё так же не отпуская,
     * возвращаем палец в исходную точку (к выбранной грядке): тогда камера не уплывает за местом, где закончили.
     * Режимы: 0 плавно, 1 медленно, 2 по шагам, 3 как человек (палец быстро дёргается
     * из стороны в сторону поперёк строки много раз).
     */
    private fun holdDrag(start: P, pts: List<P>, anchor: P? = null) {
        if (Build.VERSION.SDK_INT < 26 || pts.isEmpty()) {
            drag(start, pts)
            return
        }
        waitIfPaused()
        val mode3 = cfg.plantMode == 3
        var cx = j(start.x)
        var cy = j(start.y)
        val p0 = Path()
        p0.moveTo(cx, cy)
        val hold = cfg.holdMs.toLong() + (if (mode3) Random.nextLong(0, 120) else 0L)
        var prev = GestureDescription.StrokeDescription(p0, 0, hold, true)
        play(prev)

        // вытягиваем иконку из меню: небольшой медленный сдвиг в сторону поля
        val first = anchor ?: pts[0]
        val dx = first.x - cx
        val dy = first.y - cy
        val dl = max(1f, hypot(dx, dy))
        val px = cx + dx / dl * 45f
        val py = cy + dy / dl * 45f
        val pp = Path()
        pp.moveTo(cx, cy)
        pp.lineTo(px, py)
        prev = prev.continueStroke(pp, 0, 300, true)
        play(prev)
        cx = px
        cy = py

        // несём культуру к выбранной грядке и задерживаемся над ней: посадка идёт от неё
        if (anchor != null) {
            val ax = anchor.x + jit(2f)
            val ay = anchor.y + jit(2f)
            val d0 = hypot(ax - cx, ay - cy)
            val durA = (d0 / 0.5f).toLong().coerceIn(200L, 6000L)
            val pa = Path()
            pa.moveTo(cx, cy)
            pa.lineTo(ax, ay)
            prev = prev.continueStroke(pa, 0, durA, true)
            play(prev)
            cx = ax
            cy = ay
            val pd = Path()
            pd.moveTo(cx, cy)
            prev = prev.continueStroke(pd, 0, if (mode3) 200L else 300L, true)
            play(prev)
        }

        if (cfg.plantMode == 2) {
            val wps = waypoints(pts, max(30f, cfg.rowGap * 1.6f))
            for (w in wps) {
                val tx = w.x + jit(2f)
                val ty = w.y + jit(2f)
                val d = hypot(tx - cx, ty - cy)
                val dur = (d / 0.35f).toLong().coerceIn(30L, 4000L)
                val mv = Path()
                mv.moveTo(cx, cy)
                mv.lineTo(tx, ty)
                prev = prev.continueStroke(mv, 0, dur, true)
                play(prev)
                cx = tx
                cy = ty
                val dw = Path()
                dw.moveTo(cx, cy)
                prev = prev.continueStroke(dw, 0, 70, true)
                play(prev)
            }
        } else {
            val route = if (mode3) {
                Geo.scribble(pts, max(10f, cfg.rowGap * 0.45f), max(18f, cfg.rowGap * 0.55f), Random)
            } else {
                pts
            }
            val base = when (cfg.plantMode) {
                1 -> 0.25f
                3 -> 0.8f
                else -> 0.5f
            }
            val path = Path()
            path.moveTo(cx, cy)
            var len = 0f
            var lx = cx
            var ly = cy
            for (q in route) {
                val tx = if (mode3) q.x else q.x + jit(2f)
                val ty = if (mode3) q.y else q.y + jit(2f)
                path.lineTo(tx, ty)
                len += hypot(tx - lx, ty - ly)
                lx = tx
                ly = ty
            }
            val speed = max(base, len / 50_000f)   // не дольше ~50 секунд
            val dur = (len / speed).toLong().coerceIn(900L, 55_000L)
            prev = prev.continueStroke(path, 0, dur, true)
            play(prev)
            cx = lx
            cy = ly
        }

        // по желанию возвращаем палец в исходную точку, не отпуская (медленно, чтобы не толкнуть карту)
        if (cfg.returnHand > 0) {
            val home = anchor ?: start
            val hx = home.x + jit(2f)
            val hy = home.y + jit(2f)
            val dr = hypot(hx - cx, hy - cy)
            val pr = Path()
            pr.moveTo(cx, cy)
            pr.lineTo(hx, hy)
            prev = prev.continueStroke(pr, 0, (dr / 0.2f).toLong().coerceIn(400L, 9000L), true)
            play(prev)
            cx = hx
            cy = hy
        }
        val pe = Path()
        pe.moveTo(cx, cy)
        play(prev.continueStroke(pe, 0, 160, false))
    }

    /** Несколько штрихов в одном жесте = несколько пальцев одновременно. */
    private fun play(vararg strokes: GestureDescription.StrokeDescription) {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val gb = GestureDescription.Builder()
        for (s in strokes) gb.addStroke(s)
        val g = gb.build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                ok.set(true)
                latch.countDown()
            }

            override fun onCancelled(d: GestureDescription?) {
                latch.countDown()
            }
        }
        ui.post { if (!dispatchGesture(g, cb, null)) latch.countDown() }
        latch.await(70, TimeUnit.SECONDS)
        if (ok.get()) {
            gestureFails = 0
        } else {
            gestureFails++
            if (gestureFails >= 6 && botMode) {
                jlog("⚠ Жесты не проходят")
                stopBot("Жесты не проходят. Проверь службу и не трогай экран")
            }
        }
    }
}
