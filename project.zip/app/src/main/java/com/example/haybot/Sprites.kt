package com.example.haybot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Картинки: курсоры, голова и «хвост» змейки, штрихи рамки. Грузятся один раз. */
object Sprites {
    var click: Bitmap? = null
    var hold: Bitmap? = null
    var head: Bitmap? = null
    var poop: Bitmap? = null
    var dashes: Bitmap? = null
    private var ready = false

    fun init(ctx: Context) {
        if (ready) return
        fun bm(id: Int): Bitmap? = try {
            BitmapFactory.decodeResource(ctx.resources, id)
        } catch (_: Throwable) {
            null
        }
        click = bm(R.drawable.cursor_click)
        hold = bm(R.drawable.cursor_hold)
        head = bm(R.drawable.snake_head)
        poop = bm(R.drawable.snake_poop)
        dashes = bm(R.drawable.dashes)
        ready = true
    }
}

/** Рисует значок курсора так, чтобы кончик (hot spot) оказался точно в точке касания. */
object Cursor {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    /** hold = true: значок «зажатие» (мишень), иначе «нажатие» (стрелка с лучиками). */
    fun draw(c: Canvas, x: Float, y: Float, hold: Boolean, size: Float, alpha: Float) {
        val bm = (if (hold) Sprites.hold else Sprites.click) ?: return
        val hx = if (hold) 0.384f else 0.058f
        val hy = if (hold) 0.46f else 0.20f
        val w = size
        val h = size * bm.height / bm.width
        paint.alpha = (255 * alpha.coerceIn(0f, 1f)).toInt()
        c.drawBitmap(bm, null, RectF(x - hx * w, y - hy * h, x - hx * w + w, y - hy * h + h), paint)
    }
}

/**
 * Змейка. Идёт по ломаной: голова на расстоянии headDist от начала, тело тянется за ней, чуть извивается.
 * kind 1 = сеет (просто змейка), kind 2 = собирает (позади остаётся «какашка»).
 */
object Snake {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val m = Matrix()
    private const val N = 9

    private fun lerp(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun bodyColor(u: Float): Int = when {
        u < 0.35f -> lerp(0xB04BFF, 0x4F5BFF, u / 0.35f)
        u < 0.7f -> lerp(0x4F5BFF, 0x2F8BFF, (u - 0.35f) / 0.35f)
        else -> lerp(0x2F8BFF, 0x18E6FF, (u - 0.7f) / 0.3f)
    }

    fun length(poly: List<P>): Float {
        var s = 0f
        for (i in 1 until poly.size) s += hypot(poly[i].x - poly[i - 1].x, poly[i].y - poly[i - 1].y)
        return s
    }

    /** Точка на ломаной на расстоянии d от начала и угол движения. */
    private fun at(poly: List<P>, cum: FloatArray, d: Float, out: FloatArray) {
        val total = cum[cum.size - 1]
        val dd = d.coerceIn(0f, total)
        var i = 1
        while (i < cum.size - 1 && cum[i] < dd) i++
        val a = poly[i - 1]
        val b = poly[i]
        val seg = max(cum[i] - cum[i - 1], 0.0001f)
        val t = ((dd - cum[i - 1]) / seg).coerceIn(0f, 1f)
        out[0] = a.x + (b.x - a.x) * t
        out[1] = a.y + (b.y - a.y) * t
        out[2] = atan2(b.y - a.y, b.x - a.x)
    }

    fun draw(c: Canvas, poly: List<P>, headDist: Float, kind: Int, now: Long, sc: Float, alpha: Float = 1f) {
        if (poly.size < 2) return
        val cum = FloatArray(poly.size)
        for (i in 1 until poly.size) cum[i] = cum[i - 1] + hypot(poly[i].x - poly[i - 1].x, poly[i].y - poly[i - 1].y)
        if (cum[cum.size - 1] < 1f) return
        val r = 21f * sc
        val sp = 29f * sc
        val a255 = (255 * alpha.coerceIn(0f, 1f)).toInt()
        val p = FloatArray(3)
        // «какашка» остаётся за хвостом
        if (kind == 2) {
            val pm = Sprites.poop
            if (pm != null) {
                at(poly, cum, max(0f, headDist - (N + 1.3f) * sp), p)
                val w = 3.2f * r
                val h = w * pm.height / pm.width
                bmp.alpha = a255
                val bob = sin(now / 130f) * 2f * sc
                c.drawBitmap(pm, null, RectF(p[0] - w * 0.55f, p[1] - h * 0.7f + bob, p[0] + w * 0.45f, p[1] + h * 0.3f + bob), bmp)
            }
        }
        // тело от хвоста к голове
        for (k in N - 1 downTo 0) {
            val d = headDist - (k + 1) * sp
            if (d < 0f) continue
            at(poly, cum, d, p)
            val wave = sin(now / 150f - k * 0.85f) * 5f * sc * min(1f, k / 2f)
            val x = p[0] - sin(p[2]) * wave
            val y = p[1] + cos(p[2]) * wave
            val col = bodyColor(k / (N - 1f))
            fill.style = Paint.Style.FILL
            fill.color = Color.argb((a255 * 0.95f).toInt(), 8, 10, 70)
            c.drawCircle(x, y, r + 4.5f * sc, fill)
            fill.color = Color.argb(a255, Color.red(col), Color.green(col), Color.blue(col))
            c.drawCircle(x, y, r, fill)
            fill.color = Color.argb((a255 * 0.28f).toInt(), 255, 255, 255)
            c.drawCircle(x - r * 0.28f, y - r * 0.32f, r * 0.55f, fill)
        }
        // голова смотрит по ходу движения, глаз всегда сверху
        val hb = Sprites.head ?: return
        at(poly, cum, headDist, p)
        val ang = p[2]
        val w = 3.1f * r
        val k = w / hb.width
        m.reset()
        m.postTranslate(-hb.width * 0.40f, -hb.height * 0.5f)
        m.postScale(k, if (cos(ang) < 0f) -k else k)
        m.postRotate(Math.toDegrees(ang.toDouble()).toFloat())
        m.postTranslate(p[0], p[1])
        bmp.alpha = a255
        c.drawBitmap(hb, m, bmp)
    }
}

/** Рамка из бегущих штрихов (картинки капсул из набора), цвета переливаются от голубого к розовому. */
object Dashes {
    private val bmp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private const val CELL_W = 150
    private const val CELL_H = 70

    fun drawPoly(c: Canvas, poly: List<P>, now: Long, sc: Float, closed: Boolean = true) {
        val sheet = Sprites.dashes ?: return
        val pts = if (closed) poly + poly[0] else poly
        if (pts.size < 2) return
        val cum = FloatArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        val total = cum[cum.size - 1]
        if (total < 10f) return
        val dashLen = 40f * sc
        val step = dashLen + 16f * sc
        val offset = (now / 16f * sc) % step      // штрихи плывут вдоль рамки
        val cells = sheet.width / CELL_W
        val scale = dashLen * 1.45f / CELL_W
        var s = offset - step
        while (s < total) {
            val mid = s + dashLen / 2f
            if (mid in 0f..total) {
                var i = 1
                while (i < cum.size - 1 && cum[i] < mid) i++
                val a = pts[i - 1]
                val b = pts[i]
                val seg = max(cum[i] - cum[i - 1], 0.0001f)
                val t = ((mid - cum[i - 1]) / seg).coerceIn(0f, 1f)
                val x = a.x + (b.x - a.x) * t
                val y = a.y + (b.y - a.y) * t
                val ang = Math.toDegrees(atan2(b.y - a.y, b.x - a.x).toDouble()).toFloat()
                val u = ((mid / total + now / 9000f) % 1f)
                val tri = 1f - abs(2f * u - 1f)
                val idx = (tri * (cells - 1)).toInt().coerceIn(0, cells - 1)
                c.save()
                c.translate(x, y)
                c.rotate(ang)
                c.scale(scale, scale)
                c.drawBitmap(sheet, Rect(idx * CELL_W, 0, idx * CELL_W + CELL_W, CELL_H), RectF(-CELL_W / 2f, -CELL_H / 2f, CELL_W / 2f, CELL_H / 2f), bmp)
                c.restore()
            }
            s += step
        }
    }
}
