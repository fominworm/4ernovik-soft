package com.example.haybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class BotService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private lateinit var cfg: Cfg

    private var step = 0
    private var expanded = true
    private var note = ""
    @Volatile private var busy = false      // идёт повтор нажатия или проверка (посадка/сбор)
    @Volatile private var active = false    // работает фоновый поток
    private var botMode = false             // крутится основной цикл
    private var plantedAt = 0L
    @Volatile private var lastAd = 0L
    private var worker: Thread? = null

    private var root: LinearLayout? = null
    private var body: LinearLayout? = null
    private var cap: MarkView? = null
    private lateinit var capLp: WindowManager.LayoutParams
    private lateinit var titleTv: TextView
    private lateinit var promptTv: TextView
    private lateinit var subTv: TextView
    private lateinit var primaryBtn: TextView
    private lateinit var foldBtn: TextView
    private lateinit var undoBtn: TextView
    private lateinit var clearBtn: TextView
    private lateinit var minusBtn: TextView
    private lateinit var plusBtn: TextView
    private lateinit var skipBtn: TextView

    private val growMs = 121_000L          // пшеница растёт 2 мин + запас
    private val adCooldownMs = 305_000L    // реклама не чаще раза в 5 минут

    private val cGray = 0xFF4A4F57.toInt()
    private val cGreen = 0xFF2E9E4F.toInt()
    private val cRed = 0xFFD64545.toInt()
    private val cBlue = 0xFF2F6FDE.toInt()

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private val ticker = object : Runnable {
        override fun run() {
            if (botMode || FLOW[step].kind != Kind.WAIT) return
            val left = ((plantedAt + growMs - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
            note = if (left > 0) {
                "⏳ Осталось " + (left / 60) + ":" + (left % 60).toString().padStart(2, '0')
            } else {
                "✅ Должна быть готова"
            }
            subTv.text = note
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- жизненный цикл ----------

    override fun onServiceConnected() {
        cfg = Cfg(this)
        val mv = MarkView(this, cfg)
        mv.onTap = { x, y -> onTapped(x, y) }
        capLp = overlayParams()
        wm.addView(mv, capLp)
        cap = mv
        showPanel()   // панель добавляется после слоя, значит лежит выше него
        go(if (cfg.missing() == null) I_FINISH else 0)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        active = false
        worker?.interrupt()
        ui.removeCallbacks(ticker)
        removeView(cap)
        removeView(root)
        super.onDestroy()
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun overlayParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    /** armed = слой ловит касание пользователя; иначе касания проходят в игру. */
    private fun setArmed(on: Boolean) {
        val mv = cap ?: return
        if (mv.armed == on) return
        mv.armed = on
        capLp.flags = if (on) baseFlags else (baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        try { wm.updateViewLayout(mv, capLp) } catch (_: Exception) {}
        mv.invalidate()
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun vis(show: Boolean): Int = if (show) View.VISIBLE else View.GONE

    private fun btn(t: String, color: Int, weight: Float = 0f, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.WHITE)
        v.textSize = 13f
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(8), dp(8), dp(8), dp(8))
        v.background = bg(color, 10)
        v.setOnClickListener { onClick() }
        val w = if (weight > 0f) 0 else ViewGroup.LayoutParams.WRAP_CONTENT
        val lp = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        v.layoutParams = lp
        return v
    }

    private fun big(t: String, color: Int, onClick: () -> Unit): TextView {
        val v = btn(t, color, 0f, onClick)
        v.textSize = 16f
        v.setPadding(dp(10), dp(12), dp(10), dp(12))
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(dp(2), dp(6), dp(2), dp(4))
        v.layoutParams = lp
        return v
    }

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(4), dp(3), dp(4), dp(3))
        return v
    }

    private fun showPanel() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = bg(0xEE101820.toInt(), 14)
        box.setPadding(dp(6), dp(6), dp(6), dp(6))

        // шапка: перетащить, заголовок, показать точки, свернуть
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val drag = btn("≡", cGray) {}
        titleTv = label(12f, 0xFFB0BEC5.toInt())
        titleTv.maxWidth = dp(190)
        titleTv.maxLines = 1
        val eye = btn("👁", cGray) { toggleMarks() }
        foldBtn = btn("⌄", cGray) { expanded = !expanded; applyFold() }
        head.addView(drag)
        head.addView(titleTv)
        head.addView(eye)
        head.addView(foldBtn)

        // тело: текущее задание, одна главная кнопка, мелкие кнопки
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        promptTv = label(16f, Color.WHITE, true)
        subTv = label(12.5f, 0xFFCFD8DC.toInt())
        primaryBtn = big("", cGreen) { onPrimary() }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        undoBtn = btn("↩ Назад", cGray, 1.3f) { back() }
        clearBtn = btn("🗑 Всё", cGray, 1f) { clearAll() }
        minusBtn = btn("➖", cGray, 0.6f) { changeEvery(-1) }
        plusBtn = btn("➕", cGray, 0.6f) { changeEvery(1) }
        skipBtn = btn("", cGray, 1.5f) { onSkip() }
        row.addView(undoBtn)
        row.addView(clearBtn)
        row.addView(minusBtn)
        row.addView(plusBtn)
        row.addView(skipBtn)

        b.addView(promptTv)
        b.addView(subTv)
        b.addView(primaryBtn)
        b.addView(row)

        box.addView(head)
        box.addView(b, LinearLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(8)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }

        wm.addView(box, lp)
        root = box
        body = b
        applyFold()
    }

    private fun applyFold() {
        body?.visibility = if (expanded) View.VISIBLE else View.GONE
        foldBtn.text = if (expanded) "⌄" else "⌃"
    }

    private fun toggleMarks() {
        val mv = cap ?: return
        mv.showAll = !mv.showAll
        mv.invalidate()
    }

    private fun updateUi() {
        val s = FLOW[step]
        val r = s.role
        val n = if (r != null) cfg.list(r).size else 0
        val keep = if (s.fresh) 0 else 1
        ui.removeCallbacks(ticker)

        if (botMode) {
            titleTv.text = "🤖 Бот работает"
            promptTv.text = "Бот работает. Не трогай экран."
            subTv.text = note
            primaryBtn.visibility = View.VISIBLE
            primaryBtn.text = "■ Стоп"
            primaryBtn.background = bg(cRed, 10)
            primaryBtn.alpha = 1f
            undoBtn.visibility = View.GONE
            clearBtn.visibility = View.GONE
            minusBtn.visibility = View.GONE
            plusBtn.visibility = View.GONE
            skipBtn.visibility = View.GONE
            setArmed(false)
            return
        }

        titleTv.text = "HayBot · шаг ${step + 1} из ${FLOW.size}"

        if (busy) {
            promptTv.text = "⏳ Выполняю…"
            subTv.text = note
            primaryBtn.visibility = View.GONE
            undoBtn.visibility = View.GONE
            clearBtn.visibility = View.GONE
            minusBtn.visibility = View.GONE
            plusBtn.visibility = View.GONE
            skipBtn.visibility = View.GONE
            setArmed(false)
            return
        }

        promptTv.text = s.text
        val base = if (note.isNotEmpty()) note else s.hint
        subTv.text = when (s.kind) {
            Kind.MULTI -> "Точек: $n\n$base"
            Kind.FINISH -> {
                val sale = if (cfg.first(T.SHOP) != null) {
                    "🏪 Продажа после посадки в каждом " + cfg.sellEvery + "-м круге (➖ ➕)"
                } else {
                    "Без продажи"
                }
                (if (note.isNotEmpty()) note + "\n" else "") + s.hint + "\n" + sale
            }
            else -> base
        }

        if (s.btn != null) {
            primaryBtn.visibility = View.VISIBLE
            primaryBtn.text = s.btn
            primaryBtn.background = bg(if (s.kind == Kind.DO) cBlue else cGreen, 10)
            primaryBtn.alpha = if (s.kind == Kind.MULTI && n < s.min) 0.45f else 1f
        } else {
            primaryBtn.visibility = View.GONE
        }

        val canErase = s.kind == Kind.MULTI && n > keep
        undoBtn.visibility = vis(step > 0 || canErase)
        clearBtn.visibility = vis(canErase)
        val sellOn = s.kind == Kind.FINISH && cfg.first(T.SHOP) != null
        minusBtn.visibility = vis(sellOn)
        plusBtn.visibility = vis(sellOn)
        if (s.skip != null) {
            skipBtn.visibility = View.VISIBLE
            skipBtn.text = s.skip
        } else {
            skipBtn.visibility = View.GONE
        }

        setArmed(s.kind == Kind.TAP || s.kind == Kind.MULTI)
        if (s.kind == Kind.WAIT) ui.post(ticker)
        cap?.invalidate()
    }

    private fun say(m: String) {
        ui.post {
            note = m
            if (botMode) titleTv.text = "🤖 $m"
            subTv.text = m
        }
    }

    // ---------- мастер: переходы ----------

    private fun go(n: Int) {
        step = n.coerceIn(0, FLOW.size - 1)
        note = ""
        val s = FLOW[step]
        val r = s.role
        if (r != null && s.fresh) cfg.clear(r)
        updateUi()
    }

    private fun advance() = go(step + 1)

    private fun prevIndex(): Int =
        if (step == I_FINISH && cfg.first(T.SHOP) == null) I_ASK else step - 1

    private fun back() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role
        if (s.kind == Kind.MULTI && r != null) {
            val keep = if (s.fresh) 0 else 1
            if (cfg.list(r).size > keep) {
                cfg.removeLast(r)
                note = "↩ Последняя точка стёрта"
                updateUi()
                return
            }
        }
        if (step > 0) go(prevIndex())
    }

    private fun clearAll() {
        if (busy || botMode) return
        val s = FLOW[step]
        val r = s.role ?: return
        if (s.kind == Kind.MULTI) {
            cfg.truncate(r, if (s.fresh) 0 else 1)
            note = "🗑 Точки стёрты"
            updateUi()
        }
    }

    private fun changeEvery(d: Int) {
        cfg.sellEvery = cfg.sellEvery + d
        updateUi()
    }

    private fun onPrimary() {
        if (botMode) {
            stopBot()
            return
        }
        if (busy) return
        val s = FLOW[step]
        when (s.kind) {
            Kind.MULTI -> {
                val r = s.role
                val n = if (r != null) cfg.list(r).size else 0
                if (n < s.min) {
                    note = "⚠ Нужно минимум " + s.min + " точки"
                    updateUi()
                } else {
                    advance()
                }
            }
            Kind.WAIT, Kind.ASK -> advance()
            Kind.DO -> doAction(s.act ?: "")
            Kind.FINISH -> startBot()
            else -> {}
        }
    }

    private fun onSkip() {
        if (busy || botMode) return
        when (FLOW[step].kind) {
            Kind.ASK -> {
                cfg.clear(T.SHOP)
                go(I_FINISH)
            }
            Kind.FINISH -> go(0)
            else -> advance()
        }
    }

    // ---------- мастер: нажатия пользователя ----------

    private fun onTapped(x: Float, y: Float) {
        if (busy || botMode) return
        val s = FLOW[step]
        if (s.kind != Kind.TAP && s.kind != Kind.MULTI) return
        val p = P(x, y)
        val r = s.role
        if (r != null) {
            cfg.add(r, p)
            if (r == T.AD) lastAd = System.currentTimeMillis()
        }
        if (s.kind == Kind.MULTI) {
            note = "✔ Запомнил"
        }
        if (s.replay) {
            busy = true
            setArmed(false)
            replayTap(p) {
                busy = false
                if (s.kind == Kind.TAP) advance() else updateUi()
            }
        } else {
            if (s.kind == Kind.TAP) advance() else updateUi()
        }
    }

    /** Повторяет нажатие пользователя в игре (слой уже стал прозрачным для касаний). */
    private fun replayTap(p: P, then: () -> Unit) {
        ui.postDelayed({
            val path = Path()
            path.moveTo(p.x, p.y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            val cb = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ui.postDelayed({ then() }, 800) }
                override fun onCancelled(d: GestureDescription?) { ui.postDelayed({ then() }, 300) }
            }
            if (!dispatchGesture(g, cb, null)) ui.postDelayed({ then() }, 300)
        }, 180)
    }

    private fun doAction(act: String) {
        if (busy || botMode) return
        busy = true
        active = true
        note = if (act == "plant") "Сажаю пшеницу по маршруту…" else "Собираю урожай по маршруту…"
        setArmed(false)
        updateUi()
        worker = Thread {
            try {
                if (act == "plant") {
                    plantOnce()
                    plantedAt = System.currentTimeMillis()
                } else {
                    harvestOnce()
                }
            } catch (_: InterruptedException) {
            } finally {
                active = false
                ui.post { busy = false; advance() }
            }
        }.also { it.start() }
    }

    // ---------- основной цикл ----------

    private fun startBot() {
        val m = cfg.missing()
        if (m != null) {
            val i = FLOW.indexOfFirst { it.role == m }
            go(if (i >= 0) i else 0)
            note = "⚠ Не хватает: " + m.icon + " " + m.label
            updateUi()
            return
        }
        botMode = true
        busy = false
        active = true
        note = "Запускаю…"
        expanded = true
        applyFold()
        setArmed(false)
        updateUi()
        worker = Thread {
            try {
                loop()
            } catch (_: InterruptedException) {
            } finally {
                active = false
                ui.post {
                    botMode = false
                    go(I_FINISH)
                    note = "⏹ Бот остановлен"
                    updateUi()
                }
            }
        }.also { it.start() }
    }

    private fun stopBot() {
        active = false
        worker?.interrupt()
    }

    private fun plantOnce() {
        tap(cfg.first(T.FIELD)!!)
        pause(900)
        drag(cfg.first(T.WHEAT)!!, cfg.list(T.PATH).toList())
        pause(900)
    }

    private fun harvestOnce() {
        tap(cfg.first(T.HFIELD)!!)
        pause(900)
        drag(cfg.first(T.SICKLE)!!, cfg.list(T.PATH).toList())
        pause(1500)
    }

    private fun loop() {
        val sellOn = cfg.first(T.SHOP) != null
        val every = cfg.sellEvery
        var round = 0
        while (active) {
            if (round > 0) {
                say("Круг $round: сбор 🔪")
                harvestOnce()
                pause(Random.nextLong(0, 1000))
            }
            round++
            say("Круг $round: посадка 🌾")
            plantOnce()
            val t0 = System.currentTimeMillis()
            if (sellOn && round % every == 0) sell(round)
            val wait = growMs + Random.nextLong(0, 8000) - (System.currentTimeMillis() - t0)
            pause(wait, "Круг $round: растёт ⏳")
        }
    }

    private fun sell(round: Int) {
        val shop = cfg.first(T.SHOP) ?: return
        val slots = cfg.list(T.SLOT).toList()
        val item = cfg.first(T.ITEM) ?: return
        val extra = cfg.list(T.EXTRA).toList()
        val ad = cfg.first(T.AD)
        val put = cfg.first(T.PUT) ?: return
        val close = cfg.first(T.CLOSE) ?: return

        say("Круг $round: открываю лавку 🏪")
        tap(shop)
        pause(2200)
        for ((i, slot) in slots.withIndex()) {
            say("Круг $round: слот ${i + 1} из ${slots.size} 🧺")
            tap(slot); pause(1300 + Random.nextLong(0, 300))   // забрать выручку
            tap(slot); pause(1300 + Random.nextLong(0, 300))   // открыть выбор лота
            tap(item); pause(900)
            for (e in extra) { tap(e); pause(700) }
            if (ad != null && System.currentTimeMillis() - lastAd >= adCooldownMs) {
                tap(ad)
                lastAd = System.currentTimeMillis()
                pause(900)
            }
            tap(put); pause(1500)
        }
        tap(close)
        pause(1200)
    }

    // ---------- жесты ----------

    private fun pause(ms: Long, label: String? = null) {
        var left = ms
        var shown = -1L
        while (left > 0 && active) {
            if (label != null) {
                val s = left / 1000
                if (s != shown) {
                    shown = s
                    say(label + " " + (s / 60) + ":" + (s % 60).toString().padStart(2, '0'))
                }
            }
            Thread.sleep(minOf(left, 200L))
            left -= 200L
        }
    }

    private fun j(v: Float) = v + (Random.nextFloat() * 2f - 1f) * 5f

    private fun tap(p: P) {
        val path = Path()
        path.moveTo(j(p.x), j(p.y))
        play(GestureDescription.StrokeDescription(path, 0, 40L + Random.nextLong(0, 40)))
    }

    private fun drag(start: P, pts: List<P>) {
        val path = Path()
        path.moveTo(j(start.x), j(start.y))
        for (q in pts) path.lineTo(j(q.x), j(q.y))
        play(GestureDescription.StrokeDescription(path, 0, 500L + 350L * pts.size))
    }

    private fun play(s: GestureDescription.StrokeDescription) {
        val latch = CountDownLatch(1)
        val g = GestureDescription.Builder().addStroke(s).build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }
        ui.post { dispatchGesture(g, cb, null) }
        latch.await(70, TimeUnit.SECONDS)
    }
}
