package com.example.haybot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View

/**
 * Слой на весь экран. Когда armed=true — ловит одно нажатие (onTap сработает при отпускании пальца)
 * и рисует записанные точки. Когда armed=false — окно прозрачно для касаний (задаётся флагами окна).
 */
class MarkView(ctx: Context, private val cfg: Cfg) : View(ctx) {
    var armed = false
    var showAll = false
    var onTap: ((Float, Float) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var down = false
    private var dx = 0f
    private var dy = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!armed) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                dx = e.rawX
                dy = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                if (down) {
                    down = false
                    onTap?.invoke(dx, dy)
                }
            }
            MotionEvent.ACTION_CANCEL -> down = false
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        if (!armed && !showAll) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        if (armed) c.drawColor(0x30FFEB3B)

        // область поля и предпросмотр змейки
        val area = cfg.list(T.AREA)
        if (area.size >= 3) {
            val q = Geo.order(area)
            val poly = Path()
            poly.moveTo(q[0].x - ox, q[0].y - oy)
            for (i in 1 until q.size) poly.lineTo(q[i].x - ox, q[i].y - oy)
            poly.close()
            p.style = Paint.Style.FILL
            p.color = 0x3329B6F6
            c.drawPath(poly, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f
            p.color = T.AREA.color
            c.drawPath(poly, p)
        }
        if (area.size >= 4) {
            val f = cfg.first(T.FIELD)
            val z = if (f != null) Geo.zigzagFrom(area, cfg.rowGap.toFloat(), f) else Geo.zigzag(area, cfg.rowGap.toFloat())
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = 0xCCFFFFFF.toInt()
            for (i in 1 until z.size) {
                c.drawLine(z[i - 1].x - ox, z[i - 1].y - oy, z[i].x - ox, z[i].y - oy, p)
            }
        }

        p.style = Paint.Style.FILL
        for (t in T.values()) {
            for ((i, pt) in cfg.list(t).withIndex()) {
                p.color = t.color
                c.drawCircle(pt.x - ox, pt.y - oy, 20f, p)
                p.color = Color.WHITE
                p.textSize = 30f
                p.textAlign = Paint.Align.LEFT
                val label = t.icon + (if (t.multi) (i + 1).toString() else "")
                c.drawText(label, pt.x - ox + 24f, pt.y - oy + 10f, p)
            }
        }
    }
}
