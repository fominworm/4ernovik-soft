package com.example.haybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class BotService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private lateinit var cfg: Cfg
    private var root: LinearLayout? = null
    private var status: TextView? = null
    private var goBtn: TextView? = null
    private var cap: View? = null
    private var target = T.FIELD
    @Volatile private var running = false
    private var worker: Thread? = null

    // время роста пшеницы (2 мин) + запас
    private val growMs = 121_000L

    override fun onServiceConnected() {
        cfg = Cfg(this)
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        removeCap()
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setBackgroundColor(0xCC333333.toInt())
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val st = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
        }
        status = st
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val drag = btn("≡") {}
        val go = btn("▶") { toggle() }
        goBtn = go
        row.addView(drag)
        row.addView(btn("Цель") { nextTarget() })
        row.addView(btn("Метка") { startCapture() })
        row.addView(btn("Сброс") { if (!running) { cfg.clear(target); refresh() } })
        row.addView(go)
        box.addView(st)
        box.addView(row)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(8)
        }
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }
        wm.addView(box, lp)
        root = box
        refresh()
    }

    private fun refresh(msg: String = "") {
        status?.text = msg + target.title + " [" + cfg.list(target).size + "]"
    }

    private fun nextTarget() {
        if (running) return
        target = T.values()[(target.ordinal + 1) % T.values().size]
        refresh()
    }

    private fun startCapture() {
        if (running || cap != null) return
        val v = View(this).apply { setBackgroundColor(0x55FFFF00) }
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                cfg.add(target, P(e.rawX, e.rawY))
                removeCap()
                refresh("Записано (" + e.rawX.toInt() + "," + e.rawY.toInt() + ") ")
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, lp)
        cap = v
        refresh("Тапни точку: ")
    }

    private fun removeCap() {
        cap?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cap = null
    }

    private fun toggle() {
        if (running) {
            running = false
            worker?.interrupt()
            return
        }
        if (cfg.first(T.FIELD) == null || cfg.first(T.WHEAT) == null ||
            cfg.first(T.SICKLE) == null || cfg.list(T.PATH).isEmpty()
        ) {
            refresh("Не хватает точек 1-4! ")
            return
        }
        running = true
        goBtn?.text = "■"
        worker = Thread {
            try {
                loop()
            } catch (_: InterruptedException) {
            } finally {
                running = false
                ui.post { goBtn?.text = "▶"; refresh("Стоп. ") }
            }
        }.also { it.start() }
    }

    private fun say(m: String) {
        ui.post { status?.text = m }
    }

    private fun loop() {
        val field = cfg.first(T.FIELD)!!
        val wheat = cfg.first(T.WHEAT)!!
        val sickle = cfg.first(T.SICKLE)!!
        val path = cfg.list(T.PATH).toList()
        val sell = cfg.list(T.SELL).toList()
        var round = 0
        while (running) {
            round++
            say("Круг $round: посадка")
            tap(field); pause(900)
            drag(wheat, path); pause(800)
            val t0 = System.currentTimeMillis()
            if (sell.isNotEmpty()) {
                say("Круг $round: продажа")
                for (p in sell) { tap(p); pause(1100 + Random.nextLong(0, 400)) }
            }
            val wait = growMs + Random.nextLong(0, 8000) - (System.currentTimeMillis() - t0)
            say("Круг $round: ждём урожай")
            pause(wait)
            say("Круг $round: сбор")
            tap(field); pause(900)
            drag(sickle, path); pause(1500 + Random.nextLong(0, 1000))
        }
    }

    private fun pause(ms: Long) {
        var left = ms
        while (left > 0 && running) {
            Thread.sleep(minOf(left, 200L))
            left -= 200L
        }
    }

    private fun j(v: Float) = v + (Random.nextFloat() * 2f - 1f) * 5f

    private fun tap(p: P) {
        val path = Path().apply { moveTo(j(p.x), j(p.y)) }
        play(GestureDescription.StrokeDescription(path, 0, 40L + Random.nextLong(0, 40)))
    }

    private fun drag(start: P, pts: List<P>) {
        val path = Path()
        path.moveTo(j(start.x), j(start.y))
        for (q in pts) path.lineTo(j(q.x), j(q.y))
        play(GestureDescription.StrokeDescription(path, 0, 500L + 350L * pts.size))
    }

    private fun play(s: GestureDescription.StrokeDescription) {
        val latch = CountDownLatch(1)
        val g = GestureDescription.Builder().addStroke(s).build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }
        ui.post { dispatchGesture(g, cb, null) }
        latch.await(70, TimeUnit.SECONDS)
    }
}
