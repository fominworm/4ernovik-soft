package com.example.haybot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        l.addView(TextView(this).apply {
            textSize = 16f
            text = "HayBot 🌾 автопосадка, сбор и продажа пшеницы.\n\n" +
                "1) Нажми «Включить службу», найди HayBot и включи.\n" +
                "Если пункт серый (Android 13+): «Настройки приложения» → ⋮ → «Разрешить ограниченные настройки», потом снова включи.\n\n" +
                "2) Открой Hay Day. Поверх игры появится панель. Она сама ведёт по шагам: пишет, на что нажать, ты нажимаешь, и она переходит дальше.\n\n" +
                "Использование ботов нарушает правила Supercell, аккаунт могут заблокировать."
        })
        l.addView(Button(this).apply {
            text = "Включить службу"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        l.addView(Button(this).apply {
            text = "Настройки приложения"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        })
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
