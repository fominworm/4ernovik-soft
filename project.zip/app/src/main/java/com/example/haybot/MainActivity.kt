package com.example.haybot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        l.addView(TextView(this).apply {
            textSize = 15f
            text = "HayBot: автопосадка пшеницы, продажа и сбор.\n\n" +
                "1) Нажми «Включить службу», найди HayBot и включи.\n" +
                "Если пункт серый (Android 13+): «Настройки приложения» → ⋮ → «Разрешить ограниченные настройки», потом снова включи.\n\n" +
                "2) Открой Hay Day, появится панель.\n\n" +
                "Кнопки панели:\n" +
                "≡ перетащить панель\n" +
                "Цель — что сейчас отмечаем\n" +
                "Метка — следующий тап по экрану запишет точку\n" +
                "Сброс — стереть точки выбранной цели\n" +
                "▶ / ■ — старт и стоп\n\n" +
                "Порядок: 1 поле, 2 пшеница, 3 серп, 4 путь по грядкам, 5 тапы продажи.\n" +
                "Для пунктов 2 и 3 сначала сам тапни грядку, чтобы меню появилось, потом жми «Метка».\n" +
                "Не ставь панель туда, куда бот будет тапать.\n\n" +
                "Использование ботов нарушает правила Supercell, аккаунт могут заблокировать."
        })
        l.addView(Button(this).apply {
            text = "Включить службу"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        l.addView(Button(this).apply {
            text = "Настройки приложения"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        })
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
