package com.example.haybot

import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max

object Geo {
    private fun lerp(a: P, b: P, t: Float) = P(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)
    private fun dist(a: P, b: P) = hypot(b.x - a.x, b.y - a.y)

    /** Углы по часовой стрелке, первый — самый верхний (потом правый, нижний, левый). */
    fun order(c: List<P>): List<P> {
        if (c.size < 3) return c
        val cx = c.map { it.x }.average().toFloat()
        val cy = c.map { it.y }.average().toFloat()
        val sorted = c.sortedBy { atan2((it.y - cy).toDouble(), (it.x - cx).toDouble()) }
        var top = 0
        for (i in sorted.indices) if (sorted[i].y < sorted[top].y) top = i
        return sorted.subList(top, sorted.size) + sorted.subList(0, top)
    }

    /** Змейка строками. q — четыре угла по кругу. Строки идут от ребра q0-q3 к ребру q1-q2. */
    private fun zigzagRaw(q: List<P>, gap: Float): List<P> {
        val p0 = q[0]
        val p1 = q[1]
        val p2 = q[2]
        val p3 = q[3]
        val n = max(1, ceil(dist(p0, p3) / gap).toInt())
        val out = ArrayList<P>()
        for (k in 0..n) {
            val t = k.toFloat() / n
            val s = lerp(p0, p3, t)
            val e = lerp(p1, p2, t)
            if (k % 2 == 0) {
                out.add(s)
                out.add(e)
            } else {
                out.add(e)
                out.add(s)
            }
        }
        return out
    }

    /** Змейка строками внутри четырёхугольника. gap — расстояние между строками в пикселях. */
    fun zigzag(c: List<P>, gap: Float): List<P> {
        if (c.size < 4) return c
        return zigzagRaw(order(c), gap)
    }

    /**
     * Та же змейка, но начинается с угла, ближайшего к точке near (выбранная грядка),
     * и расходится от неё. Перебираем 4 поворота углов и обратный порядок.
     */
    fun zigzagFrom(c: List<P>, gap: Float, near: P): List<P> {
        if (c.size < 4) return c
        val q = order(c)
        var best: List<P>? = null
        var bd = Float.MAX_VALUE
        for (k in 0..3) {
            val rot = listOf(q[k], q[(k + 1) % 4], q[(k + 2) % 4], q[(k + 3) % 4])
            val z = zigzagRaw(rot, gap)
            for (cand in listOf(z, z.reversed())) {
                val d = dist(cand.first(), near)
                if (d < bd) {
                    bd = d
                    best = cand
                }
            }
        }
        return best ?: zigzag(c, gap)
    }

    /**
     * Движение «как у человека»: палец быстро дёргается из стороны в сторону поперёк строки,
     * пока продвигается вдоль неё. amp — размах в пикселях, half — шаг вдоль строки между рывками.
     */
    fun scribble(pts: List<P>, amp: Float, half: Float, rnd: kotlin.random.Random): List<P> {
        if (pts.size < 2) return pts
        val out = ArrayList<P>()
        out.add(pts[0])
        var sign = 1f
        for (i in 1 until pts.size) {
            val a = pts[i - 1]
            val b = pts[i]
            val dx = b.x - a.x
            val dy = b.y - a.y
            val d = hypot(dx, dy)
            if (d < 1f) continue
            val ux = dx / d
            val uy = dy / d
            val nx = -uy
            val ny = ux
            var s = half
            while (s < d) {
                val k = amp * (0.6f + 0.8f * rnd.nextFloat()) * sign
                out.add(P(a.x + ux * s + nx * k, a.y + uy * s + ny * k))
                sign = -sign
                s += half * (0.7f + 0.6f * rnd.nextFloat())
            }
            out.add(b)
        }
        return out
    }

    fun length(start: P, pts: List<P>): Float {
        var len = 0f
        var prev = start
        for (q in pts) {
            len += dist(prev, q)
            prev = q
        }
        return len
    }
}
