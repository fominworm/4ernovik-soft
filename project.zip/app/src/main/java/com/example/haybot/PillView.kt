package com.example.haybot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Единый HUD бота в стиле плавающей панели: тёмно-синее стекло, неоновая рамка от циана к фиолетовому, робот слева,
 * статус со временем и строка цифр (круги, монеты, пшеница, силос), справа круглые кнопки: пауза, стоп, отладка, метки.
 * Тянется пальцем за любое место, кроме кнопок.
 */
class PillView(
    ctx: Context,
    private val onPause: () -> Unit,
    private val onStop: () -> Unit,
    private val onDebug: () -> Unit,
    private val onEye: () -> Unit
) : LinearLayout(ctx) {
    private val robot = ImageView(ctx)
    private val status = TextView(ctx)
    private val stats = TextView(ctx)
    private val pauseB = TextView(ctx)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    /** Текст до первого перевода строки идёт в статус (со временем), остальное в строку цифр. */
    var text: CharSequence
        get() = status.text
        set(v) {
            val s = v.toString()
            val i = s.indexOf('\n')
            if (i < 0) {
                status.text = s.trim()
                stats.text = ""
                stats.visibility = View.GONE
            } else {
                status.text = s.substring(0, i).trim()
                stats.text = s.substring(i + 1)
                stats.visibility = View.VISIBLE
            }
        }

    fun setPaused(p: Boolean) {
        pauseB.text = if (p) "▶" else "⏸"
        pauseB.background = chip(if (p) 0xFF22D68A.toInt() else 0xFF35D6FF.toInt())
    }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), dp(6), dp(10), dp(6))
        background = frame()

        robot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFF0B1A4A.toInt())
            setStroke(dp(1).coerceAtLeast(1), 0xFF35D6FF.toInt())
        }
        robot.clipToOutline = true
        robot.outlineProvider = ViewOutlineProvider.BACKGROUND
        robot.scaleType = ImageView.ScaleType.CENTER_CROP
        val rb = robotBitmap()
        if (rb != null) robot.setImageBitmap(rb)
        addView(robot, LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) })

        // ширина текста ограничена шириной экрана, чтобы кнопки не уезжали за край
        val room = (resources.displayMetrics.widthPixels * 0.94f).toInt() - dp(10 + 34 + 8 + 10 + 4 * 34 + 4 * 4 + 12)
        val textMax = room.coerceIn(dp(140), dp(330))

        val col = LinearLayout(ctx)
        col.orientation = VERTICAL
        status.setTextColor(Color.WHITE)
        status.textSize = 13f
        status.setTypeface(status.typeface, android.graphics.Typeface.BOLD)
        status.maxLines = 1
        status.ellipsize = TextUtils.TruncateAt.END
        status.maxWidth = textMax
        status.setShadowLayer(dp(3).toFloat(), 0f, 0f, 0xFF35D6FF.toInt())
        col.addView(status)
        stats.setTextColor(0xFFBFE6FF.toInt())
        stats.textSize = 11.5f
        stats.maxLines = 1
        stats.ellipsize = TextUtils.TruncateAt.END
        stats.maxWidth = textMax
        col.addView(stats)
        addView(col)

        val sep = View(ctx)
        sep.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x0035D6FF, 0xCC35D6FF.toInt(), 0x0035D6FF))
        addView(sep, LayoutParams(dp(1), dp(30)).apply { leftMargin = dp(10); rightMargin = dp(8) })

        fun button(label: String, color: Int, action: () -> Unit): TextView {
            val b = TextView(ctx)
            b.text = label
            b.textSize = 14f
            b.setTextColor(Color.WHITE)
            b.gravity = Gravity.CENTER
            b.background = chip(color)
            b.isClickable = true
            b.setOnClickListener { action() }
            addView(b, LayoutParams(dp(34), dp(34)).apply { leftMargin = dp(4) })
            return b
        }
        pauseB.text = "⏸"
        pauseB.textSize = 14f
        pauseB.setTextColor(Color.WHITE)
        pauseB.gravity = Gravity.CENTER
        pauseB.background = chip(0xFF35D6FF.toInt())
        pauseB.isClickable = true
        pauseB.setOnClickListener { onPause() }
        addView(pauseB, LayoutParams(dp(34), dp(34)).apply { leftMargin = dp(4) })
        button("■", 0xFFFF4D8D.toInt()) { onStop() }
        button("🐞", 0xFF8A6BFF.toInt()) { onDebug() }
        button("👁", 0xFF6C7BFF.toInt()) { onEye() }
    }

    /** Круглая стеклянная кнопка с цветным кольцом. */
    private fun chip(ring: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(0xFF10224F.toInt())
        setStroke(dp(1).coerceAtLeast(1) + 1, ring)
    }

    private fun frame(): LayerDrawable {
        val r = dp(26).toFloat()
        val glow = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0x4435D6FF, 0x44D13BFF)).apply { cornerRadius = r }
        val border = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF2BD4FF.toInt(), 0xFF6C5CFF.toInt(), 0xFFD13BFF.toInt())).apply { cornerRadius = r - dp(2) }
        val inner = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xF2091438.toInt(), 0xF2140F44.toInt())).apply { cornerRadius = r - dp(4) }
        return LayerDrawable(arrayOf(glow, border, inner)).apply {
            setLayerInset(1, dp(2), dp(2), dp(2), dp(2))
            setLayerInset(2, dp(4), dp(4), dp(4), dp(4))
        }
    }

    /** Робот с плавающей панели (вырезаем из картинки панели). */
    private fun robotBitmap(): Bitmap? = try {
        val src = BitmapFactory.decodeResource(resources, R.drawable.hud)
        if (src != null && src.width >= 414 && src.height >= 168) Bitmap.createBitmap(src, 290, 44, 124, 124) else null
    } catch (_: Throwable) {
        null
    }
}

/**
 * Маленький значок робота в углу экрана: виден, пока основная панель спрятана на время действий бота.
 * Показывает, что бот жив. Нажатие на него ненадолго возвращает панель (например, чтобы нажать «Стоп»).
 */
class RobotBadge(ctx: Context, private val onPeek: () -> Unit) : ImageView(ctx) {
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    init {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xDD0B1A4A.toInt())
            setStroke(dp(1).coerceAtLeast(1), 0xFF35D6FF.toInt())
        }
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND
        scaleType = ScaleType.CENTER_CROP
        try {
            val src = BitmapFactory.decodeResource(resources, R.drawable.hud)
            if (src != null && src.width >= 414 && src.height >= 168) setImageBitmap(Bitmap.createBitmap(src, 290, 44, 124, 124))
        } catch (_: Throwable) {
        }
        alpha = 0.85f
        setOnClickListener { onPeek() }
    }
}
