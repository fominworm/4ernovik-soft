package com.example.haybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class BotService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private lateinit var cfg: Cfg
    private val steps = T.values()
    private var step = 0
    private var expanded = true

    private var root: LinearLayout? = null
    private var body: LinearLayout? = null
    private lateinit var statusTv: TextView
    private lateinit var titleTv: TextView
    private lateinit var helpTv: TextView
    private lateinit var countTv: TextView
    private lateinit var goBtn: TextView
    private lateinit var foldBtn: TextView
    private lateinit var backBtn: TextView
    private lateinit var minusBtn: TextView
    private lateinit var plusBtn: TextView
    private lateinit var resetBtn: TextView
    private lateinit var markBtn: TextView
    private lateinit var nextBtn: TextView

    private var cap: MarkView? = null
    private var marks: MarkView? = null

    @Volatile private var running = false
    private var worker: Thread? = null
    @Volatile private var lastAd = 0L

    private val growMs = 121_000L          // пшеница растёт 2 мин + запас
    private val adCooldownMs = 305_000L    // реклама не чаще раза в 5 минут

    private val cGray = 0xFF4A4F57.toInt()
    private val cGreen = 0xFF2E9E4F.toInt()
    private val cRed = 0xFFD64545.toInt()
    private val cBlue = 0xFF2F6FDE.toInt()

    override fun onServiceConnected() {
        cfg = Cfg(this)
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        removeView(cap)
        removeView(marks)
        removeView(root)
        super.onDestroy()
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun btn(t: String, color: Int, weight: Float = 0f, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.WHITE)
        v.textSize = 13f
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(8), dp(8), dp(8), dp(8))
        v.background = bg(color, 10)
        v.setOnClickListener { onClick() }
        val w = if (weight > 0f) 0 else ViewGroup.LayoutParams.WRAP_CONTENT
        val lp = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        v.layoutParams = lp
        return v
    }

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(4), dp(3), dp(4), dp(3))
        return v
    }

    private fun showPanel() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = bg(0xEE101820.toInt(), 14)
        box.setPadding(dp(6), dp(6), dp(6), dp(6))

        // шапка: перетащить, старт, показать точки, свернуть
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val drag = btn("≡", cGray) {}
        goBtn = btn("▶ Старт", cGreen) { toggleRun() }
        val eye = btn("👁", cGray) { toggleMarks() }
        foldBtn = btn("⌄", cGray) { expanded = !expanded; applyFold() }
        head.addView(drag)
        head.addView(goBtn)
        head.addView(eye)
        head.addView(foldBtn)

        statusTv = label(12f, Color.WHITE)
        statusTv.maxWidth = dp(300)
        statusTv.text = "Иди по шагам ниже 👇"

        // тело: инструкция и кнопки шага
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        titleTv = label(14f, 0xFFFFD54F.toInt(), true)
        helpTv = label(12.5f, Color.WHITE)
        countTv = label(12f, 0xFF9EE493.toInt())

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        backBtn = btn("◀", cGray, 1f) { back() }
        minusBtn = btn("➖", cGray, 1f) { changeEvery(-1) }
        plusBtn = btn("➕", cGray, 1f) { changeEvery(1) }
        resetBtn = btn("🗑", cGray, 1f) { resetStep() }
        markBtn = btn("📍 Метка", cBlue, 2.2f) { startCapture() }
        nextBtn = btn("Далее ▶", cGreen, 2f) { next() }
        row.addView(backBtn)
        row.addView(minusBtn)
        row.addView(plusBtn)
        row.addView(resetBtn)
        row.addView(markBtn)
        row.addView(nextBtn)

        b.addView(titleTv)
        b.addView(helpTv)
        b.addView(countTv)
        b.addView(row)

        box.addView(head)
        box.addView(statusTv)
        box.addView(b, LinearLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(8)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }

        wm.addView(box, lp)
        root = box
        body = b
        applyFold()
        updateUi()
    }

    private fun applyFold() {
        body?.visibility = if (expanded) View.VISIBLE else View.GONE
        foldBtn.text = if (expanded) "⌄" else "⌃"
    }

    private fun vis(show: Boolean): Int = if (show) View.VISIBLE else View.GONE

    private fun updateUi() {
        val finish = step >= steps.size
        val total = steps.size + 1
        if (finish) {
            titleTv.text = "Шаг $total из $total  🚀 Запуск"
            helpTv.text = "Всё отмечено! Нажми «▶ Старт» вверху.\n" +
                "Порядок: посадка → ожидание → сбор → посадка… Продажа в лавке идёт после посадки, не в каждом круге, а в каждом N-м. Выбери N кнопками ➖ ➕. Проверить точки: 👁."
            countTv.text = "Продажа в каждом " + cfg.sellEvery + "-м круге"
        } else {
            val t = steps[step]
            titleTv.text = "Шаг ${step + 1} из $total  ${t.icon} ${t.label}"
            helpTv.text = t.help
            val n = cfg.list(t).size
            countTv.text = "Записано точек: $n" + (if (t.min == 0) "  (можно пропустить)" else "")
        }
        backBtn.visibility = vis(step > 0)
        resetBtn.visibility = vis(!finish)
        markBtn.visibility = vis(!finish)
        nextBtn.visibility = vis(!finish)
        minusBtn.visibility = vis(finish)
        plusBtn.visibility = vis(finish)
        marks?.invalidate()
    }

    private fun status(m: String) {
        statusTv.text = m
    }

    private fun say(m: String) {
        ui.post { status(m) }
    }

    private fun back() {
        if (running) return
        if (step > 0) step--
        updateUi()
    }

    private fun next() {
        if (running) return
        val t = steps[step]
        if (cfg.list(t).size < t.min) {
            status("⚠ Сначала нажми «📍 Метка»: " + t.icon + " " + t.label)
            return
        }
        step = if (t == T.SHOP && cfg.list(t).isEmpty()) steps.size else step + 1
        status("Иди по шагам ниже 👇")
        updateUi()
    }

    private fun resetStep() {
        if (running || step >= steps.size) return
        cfg.clear(steps[step])
        status("🗑 Точки шага стёрты")
        updateUi()
    }

    private fun changeEvery(d: Int) {
        cfg.sellEvery = cfg.sellEvery + d
        updateUi()
    }

    private fun fullParams(touchable: Boolean): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            f,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun startCapture() {
        if (running || cap != null || step >= steps.size) return
        val t = steps[step]
        val v = MarkView(this, cfg, "Тапни: " + t.icon + " " + t.label)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                cfg.add(t, P(e.rawX, e.rawY))
                removeView(cap)
                cap = null
                updateUi()
                status("✔ Записано (" + e.rawX.toInt() + ", " + e.rawY.toInt() + ")")
            }
            true
        }
        wm.addView(v, fullParams(true))
        cap = v
    }

    private fun toggleMarks() {
        if (marks != null) {
            removeView(marks)
            marks = null
            return
        }
        val v = MarkView(this, cfg, null)
        wm.addView(v, fullParams(false))
        marks = v
    }

    private fun setGo(on: Boolean) {
        goBtn.text = if (on) "■ Стоп" else "▶ Старт"
        goBtn.background = bg(if (on) cRed else cGreen, 10)
    }

    private fun toggleRun() {
        if (running) {
            running = false
            worker?.interrupt()
            return
        }
        val m = cfg.missing()
        if (m != null) {
            step = steps.indexOf(m)
            expanded = true
            applyFold()
            updateUi()
            status("⚠ Не хватает: " + m.icon + " " + m.label)
            return
        }
        running = true
        expanded = false
        applyFold()
        setGo(true)
        worker = Thread {
            try {
                loop()
            } catch (_: InterruptedException) {
            } finally {
                running = false
                ui.post { setGo(false); status("⏹ Остановлено") }
            }
        }.also { it.start() }
    }

    // ---------- логика бота ----------

    private fun loop() {
        val field = cfg.first(T.FIELD)!!
        val wheat = cfg.first(T.WHEAT)!!
        val sickle = cfg.first(T.SICKLE)!!
        val path = cfg.list(T.PATH).toList()
        val sellOn = cfg.first(T.SHOP) != null
        val every = cfg.sellEvery
        var round = 0
        while (running) {
            if (round > 0) {
                say("Круг $round: сбор 🔪")
                tap(field); pause(900)
                drag(sickle, path); pause(1500 + Random.nextLong(0, 1000))
            }
            round++
            say("Круг $round: посадка 🌾")
            tap(field); pause(900)
            drag(wheat, path); pause(800)
            val t0 = System.currentTimeMillis()
            if (sellOn && round % every == 0) sell(round)
            val wait = growMs + Random.nextLong(0, 8000) - (System.currentTimeMillis() - t0)
            pause(wait, "Круг $round: растёт ⏳")
        }
    }

    private fun sell(round: Int) {
        val shop = cfg.first(T.SHOP) ?: return
        val slots = cfg.list(T.SLOTS).toList()
        val item = cfg.first(T.ITEM) ?: return
        val extra = cfg.list(T.EXTRA).toList()
        val ad = cfg.first(T.AD)
        val put = cfg.first(T.PUT) ?: return
        val close = cfg.first(T.CLOSE) ?: return

        say("Круг $round: открываю лавку 🏪")
        tap(shop); pause(2200)
        for ((i, slot) in slots.withIndex()) {
            say("Круг $round: слот ${i + 1} из ${slots.size} 🧺")
            tap(slot); pause(1300 + Random.nextLong(0, 300))   // забрать выручку
            tap(slot); pause(1300 + Random.nextLong(0, 300))   // открыть выбор лота
            tap(item); pause(900)
            for (e in extra) { tap(e); pause(700) }
            if (ad != null && System.currentTimeMillis() - lastAd >= adCooldownMs) {
                tap(ad); lastAd = System.currentTimeMillis(); pause(900)
            }
            tap(put); pause(1500)
        }
        tap(close); pause(1200)
    }

    private fun pause(ms: Long, label: String? = null) {
        var left = ms
        var shown = -1L
        while (left > 0 && running) {
            if (label != null) {
                val s = left / 1000
                if (s != shown) {
                    shown = s
                    say(label + " " + (s / 60) + ":" + (s % 60).toString().padStart(2, '0'))
                }
            }
            Thread.sleep(minOf(left, 200L))
            left -= 200L
        }
    }

    private fun j(v: Float) = v + (Random.nextFloat() * 2f - 1f) * 5f

    private fun tap(p: P) {
        val path = Path()
        path.moveTo(j(p.x), j(p.y))
        play(GestureDescription.StrokeDescription(path, 0, 40L + Random.nextLong(0, 40)))
    }

    private fun drag(start: P, pts: List<P>) {
        val path = Path()
        path.moveTo(j(start.x), j(start.y))
        for (q in pts) path.lineTo(j(q.x), j(q.y))
        play(GestureDescription.StrokeDescription(path, 0, 500L + 350L * pts.size))
    }

    private fun play(s: GestureDescription.StrokeDescription) {
        val latch = CountDownLatch(1)
        val g = GestureDescription.Builder().addStroke(s).build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }
        ui.post { dispatchGesture(g, cb, null) }
        latch.await(70, TimeUnit.SECONDS)
    }
}
