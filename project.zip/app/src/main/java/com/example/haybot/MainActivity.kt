package com.example.haybot

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var stats: Stats
    private lateinit var content: LinearLayout
    private val backStack = ArrayList<String>()
    private var screen = "home"

    private lateinit var nameEt: EditText
    private lateinit var importEt: EditText
    private lateinit var keyEt: EditText

    private val cBg1 = 0xFF0B1020.toInt()
    private val cBg2 = 0xFF1A1245.toInt()
    private val cCard = 0xCC0E1236.toInt()
    private val cLine = 0xFF3D6BFF.toInt()
    private val cText = 0xFFEAF0FF.toInt()
    private val cMuted = 0xFF9AA6C7.toInt()
    private val cAccent = 0xFF7C5CFF.toInt()
    private val cBlue = 0xFF4F8CFF.toInt()
    private val cGreen = 0xFF2ECC71.toInt()
    private val cRed = 0xFFFF5C7A.toInt()

    private val tgUrl = LicenseConfig.SUPPORT_URL
    private val gamePkg = "com.supercell.hayday"

    // ---------- каркас ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        stats = Stats(this)
        window.statusBarColor = cBg1
        val frame = FrameLayout(this)
        frame.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(cBg1, cBg2, cBg1))
        val bgIv = ImageView(this)
        bgIv.setImageResource(R.drawable.bg)
        bgIv.scaleType = ImageView.ScaleType.CENTER_CROP
        frame.addView(bgIv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18), dp(30), dp(18), dp(30))
        scroll.addView(content)
        frame.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(frame)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        content.removeAllViews()
        if (welcome) {
            welcomeScreen()
            return
        }
        when (screen) {
            "game" -> gameScreen()
            "log" -> logScreen()
            "profiles" -> profilesScreen()
            "tasks" -> tasksScreen()
            "key" -> keyScreen()
            "help" -> helpScreen()
            "barn" -> barnScreen()
            else -> homeScreen()
        }
    }

    private fun go(s: String) {
        backStack.add(screen)
        screen = s
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (backStack.isNotEmpty()) {
            screen = backStack.removeAt(backStack.size - 1)
            render()
        } else {
            super.onBackPressed()
        }
    }

    // ---------- элементы интерфейса ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun text(t: String, size: Float, color: Int = cText, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(0, dp(2), 0, dp(2))
        return v
    }

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
        return v
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = shape(cCard, 18, cLine)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        c.layoutParams = lp
        return c
    }

    /** kind: 0 обычная, 1 главная (градиент), 2 опасная. */
    private fun button(t: String, kind: Int = 0, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = t
        b.textSize = 15f
        b.gravity = Gravity.CENTER
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.setTextColor(cText)
        b.setPadding(dp(14), dp(14), dp(14), dp(14))
        b.background = when (kind) {
            1 -> {
                val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF2F6BFF.toInt(), 0xFFC13DFF.toInt()))
                g.cornerRadius = dp(14).toFloat()
                g
            }
            2 -> shape(0xFF3A1F2B.toInt(), 14, cRed)
            else -> shape(0xCC141B52.toInt(), 14, 0xFF35D6FF.toInt())
        }
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        b.layoutParams = lp
        return b
    }

    private fun smallButton(t: String, onClick: () -> Unit): TextView {
        val b = button(t, 0, onClick)
        b.textSize = 13f
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        b.layoutParams = lp
        return b
    }

    private fun inputBox(hint: String, lines: Int = 1): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setTextColor(cText)
        e.setHintTextColor(cMuted)
        e.background = shape(0xFF111833.toInt(), 12, cLine)
        e.setPadding(dp(12), dp(12), dp(12), dp(12))
        e.minLines = lines
        if (lines == 1) e.setSingleLine()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        e.layoutParams = lp
        return e
    }

    private fun backBar(title: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val back = text("‹", 34f, cText, true)
        back.setPadding(0, 0, dp(16), dp(4))
        back.setOnClickListener { onBackPressed() }
        row.addView(back)
        row.addView(text(title, 24f, cText, true))
        content.addView(row)
        content.addView(space(10))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun openLink(url: String) {
        if (url.isBlank()) {
            toast("Ссылка появится позже")
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            toast("Не удалось открыть ссылку")
        }
    }

    private fun openTg() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(tgUrl)))
        } catch (_: Exception) {
            toast("Не удалось открыть Telegram")
        }
    }

    private fun openGame() {
        val i = packageManager.getLaunchIntentForPackage(gamePkg)
        if (i != null) startActivity(i) else toast("Hay Day не найден на телефоне")
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName + "/" + BotService::class.java.name) || s.contains(packageName + "/.BotService")
    }

    private fun keyPrefs() = getSharedPreferences("license", MODE_PRIVATE)

    // ---------- приветствие при входе ----------

    private var welcome = true

    private fun colored(vararg parts: Pair<String, Int>): CharSequence {
        val sb = SpannableStringBuilder()
        for ((t, col) in parts) {
            val st = sb.length
            sb.append(t)
            sb.setSpan(ForegroundColorSpan(col), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    private fun neonBox(r: Int): LayerDrawable {
        val outer = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF35D6FF.toInt(), 0xFF7B3DFF.toInt(), 0xFFFF3DD6.toInt()))
        outer.cornerRadius = dp(r).toFloat()
        val inner = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xF2070A26.toInt(), 0xF2120A36.toInt()))
        inner.cornerRadius = dp(r - 2).toFloat()
        val ld = LayerDrawable(arrayOf(outer, inner))
        ld.setLayerInset(1, dp(2), dp(2), dp(2), dp(2))
        return ld
    }

    private fun welcomeScreen() {
        content.addView(space(24))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.background = neonBox(22)
        box.setPadding(dp(20), dp(14), dp(20), dp(22))

        val x = text("✕", 20f, cText, true)
        x.setPadding(dp(10), dp(4), dp(10), dp(4))
        x.setOnClickListener {
            welcome = false
            render()
        }
        val xl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        xl.gravity = Gravity.END
        box.addView(x, xl)

        val i = text("i", 34f, cText, true)
        i.gravity = Gravity.CENTER
        val ring = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF1B2A8A.toInt(), 0xFF7B3DFF.toInt()))
        ring.shape = GradientDrawable.OVAL
        ring.setStroke(dp(2), 0xFF35D6FF.toInt())
        i.background = ring
        box.addView(i, LinearLayout.LayoutParams(dp(64), dp(64)).also { it.setMargins(0, 0, 0, dp(10)) })

        val title = TextView(this)
        title.text = colored(
            Pair("Здравствуйте,\n", cText),
            Pair("дорогой ", 0xFF35D6FF.toInt()),
            Pair("пользователь!", 0xFFFF6BE0.toInt())
        )
        title.textSize = 24f
        title.gravity = Gravity.CENTER
        title.setTypeface(title.typeface, Typeface.BOLD)
        box.addView(title)

        val line = View(this)
        line.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0x0035D6FF, 0xFF35D6FF.toInt(), 0xFFC13DFF.toInt(), 0x00C13DFF))
        box.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)).also { it.setMargins(0, dp(14), 0, dp(14)) })

        val body = TextView(this)
        body.text = colored(
            Pair("Данное приложение находится на ", cText),
            Pair("этапе разработки.\n\n", 0xFF35D6FF.toInt()),
            Pair("Могут присутствовать ", cText),
            Pair("ошибки ", 0xFFC13DFF.toInt()),
            Pair("и недоработки, но мы стараемся ", cText),
            Pair("улучшать ", 0xFF35D6FF.toInt()),
            Pair("его как можно чаще.", cText)
        )
        body.textSize = 16f
        body.gravity = Gravity.CENTER
        box.addView(body)

        val thanks = text("🚀   Спасибо за понимание и поддержку! 💜", 14f, cText)
        thanks.gravity = Gravity.CENTER
        thanks.background = shape(0x66141B52, 16, 0xFF7B3DFF.toInt())
        thanks.setPadding(dp(12), dp(14), dp(12), dp(14))
        box.addView(thanks, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, dp(16), 0, dp(6)) })

        box.addView(button("Понятно  ›", 1) {
            welcome = false
            render()
        })
        content.addView(box)
    }

    // ---------- главная: выбор бота ----------

    private fun homeScreen() {
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        content.addView(logo, LinearLayout.LayoutParams(dp(150), dp(150)).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        val sub = text("Автоматизация мобильных игр", 14f, cMuted)
        sub.gravity = Gravity.CENTER_HORIZONTAL
        content.addView(sub)
        content.addView(space(20))
        content.addView(text("Выбери бота", 18f, cText, true))
        content.addView(space(8))

        val hay = card()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(text("🌾", 40f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, 0, 0)
        col.addView(text("Hay Day", 21f, cText, true))
        col.addView(text("Посадка · сбор · продажа · свои задачи", 13f, cMuted))
        col.addView(text("● Доступен", 12f, cGreen, true))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(text("›", 30f, cMuted))
        hay.addView(row)
        hay.setOnClickListener { go("game") }
        content.addView(hay)

        content.addView(soonCard("🧱", "Новая игра"))
        content.addView(soonCard("🎯", "Ещё одна игра"))

        val key = card()
        val li = License.info(this)
        key.addView(text("🔑 Активация", 18f, cText, true))
        val kc = when (li.state) {
            LicState.ACTIVE -> cGreen
            LicState.NONE -> cMuted
            LicState.PENDING -> 0xFFFFC107.toInt()
            else -> cRed
        }
        key.addView(text(License.shortStatus(this).replaceFirstChar { it.uppercase() }, 13f, kc))
        key.setOnClickListener { go("key") }
        content.addView(key)

        val dev = card()
        dev.addView(text("Разработчик", 12f, cMuted))
        dev.addView(text("4ernovik", 20f, cText, true))
        dev.addView(text("Telegram: @flomaster6", 14f, cText))
        dev.addView(button("💬 Купить бота / написать в Telegram", 1) { openTg() })
        content.addView(dev)

        content.addView(text(
            "Использование ботов нарушает правила игр. Риск блокировки аккаунта лежит на пользователе.",
            11f, cMuted
        ))
    }

    private fun soonCard(icon: String, name: String): LinearLayout {
        val c = card()
        c.alpha = 0.45f
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(text(icon, 32f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, 0, 0)
        col.addView(text(name, 17f, cText, true))
        col.addView(text("Скоро", 12f, cMuted))
        row.addView(col)
        c.addView(row)
        return c
    }

    // ---------- Hay Day ----------

    private fun fmtMs(ms: Long): String {
        val m = ms / 60_000
        return (m / 60).toString() + " ч " + (m % 60) + " мин"
    }

    private fun gameScreen() {
        backBar("🌾 Hay Day")

        val on = serviceOn()
        val st = card()
        st.addView(text(if (on) "✅ Служба включена" else "⛔ Служба выключена", 18f, if (on) cGreen else cRed, true))
        st.addView(text(
            if (on) "Открой игру: панель появится сама и ничего не запустит без твоей кнопки."
            else "Включи службу в специальных возможностях. Если пункт серый (Android 13+): «Настройки приложения» → ⋮ → «Разрешить ограниченные настройки».",
            13f, cMuted
        ))
        if (!on) st.addView(button("Включить службу", 1) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        st.addView(button("Настройки приложения") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        content.addView(st)

        content.addView(button("▶ Открыть Hay Day", 1) { openGame() })

        val sc = card()
        sc.addView(text("Статистика", 16f, cText, true))
        sc.addView(text("🌾 Посадок: " + stats.get("plants") + "    🔪 Сборов: " + stats.get("harvests"), 14f, cText))
        sc.addView(text("💰 Продаж: " + stats.get("sales") + "    🧩 Задач: " + stats.get("macros"), 14f, cText))
        sc.addView(text("▶ Запусков: " + stats.get("runs") + "    ⚠ Сбоев: " + stats.get("fails"), 14f, cText))
        sc.addView(text("⏱ В работе: " + fmtMs(stats.get("runMs")), 14f, cText))
        content.addView(sc)

        content.addView(button("📖 Как пользоваться") { go("help") })
        content.addView(button("📜 Журнал") { go("log") })
        content.addView(button("👤 Профили настроек") { go("profiles") })
        content.addView(button("🧩 Свои задачи") { go("tasks") })
        content.addView(button("📦 Силосная башня и расчёт места") { go("barn") })
        content.addView(button("🗑 Сбросить статистику", 2) {
            stats.reset()
            render()
        })
    }

    // ---------- журнал ----------

    private fun logScreen() {
        backBar("📜 Журнал")
        val full = Journal.read(this)
        val c = card()
        val tv = text(if (full.isBlank()) "Журнал пока пуст. Он наполнится, когда бот поработает." else full.takeLast(12_000), 11f, cText)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextIsSelectable(true)
        c.addView(tv)
        content.addView(c)
        content.addView(button("📋 Скопировать debug", 1) {
            val txt = Debug.build(this, cfg, resources.displayMetrics.widthPixels.toString() + "x" + resources.displayMetrics.heightPixels)
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TapTapBot debug", txt))
            toast("Debug скопирован: вставь его в чат")
        })
        content.addView(button("Поделиться журналом") {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, full)
            startActivity(Intent.createChooser(i, "Поделиться журналом"))
        })
        content.addView(button("Очистить журнал", 2) {
            Journal.clear(this)
            render()
        })
    }

    // ---------- профили ----------

    private fun profilesScreen() {
        backBar("👤 Профили")
        val info = card()
        info.addView(text("Профиль хранит поля, точки, шаг строк, время созревания, свои задачи и эталоны цвета. Удобно для разных экранов и аккаунтов.", 13f, cMuted))
        info.addView(space(6))
        nameEt = inputBox("Название профиля")
        info.addView(nameEt)
        info.addView(button("💾 Сохранить текущие настройки", 1) {
            val n = nameEt.text.toString().trim()
            if (n.isEmpty()) {
                toast("Впиши название профиля")
            } else {
                cfg.saveProfile(n)
                toast("Профиль «$n» сохранён")
                render()
            }
        })
        content.addView(info)

        val names = cfg.profileNames()
        if (names.isEmpty()) content.addView(text("Профилей пока нет", 13f, cMuted))
        for (name in names) {
            val c = card()
            c.addView(text(name, 16f, cText, true))
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(smallButton("Загрузить") {
                toast(if (cfg.loadProfile(name)) "Профиль «$name» загружен" else "Не удалось загрузить")
            })
            row.addView(smallButton("Поделиться") {
                val json = cfg.profileJson(name)
                if (json != null) {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_TEXT, json)
                    startActivity(Intent.createChooser(i, "Поделиться профилем"))
                }
            })
            row.addView(smallButton("🗑") {
                cfg.deleteProfile(name)
                render()
            })
            c.addView(row)
            content.addView(c)
        }

        val imp = card()
        imp.addView(text("Импорт", 16f, cText, true))
        importEt = inputBox("Вставь сюда текст профиля", 3)
        imp.addView(importEt)
        imp.addView(button("📥 Импортировать как текущие настройки") {
            if (cfg.importJson(importEt.text.toString())) {
                importEt.setText("")
                toast("Импортировано. Можно сохранить как профиль")
            } else {
                toast("Не получилось: текст профиля повреждён")
            }
        })
        content.addView(imp)
    }

    // ---------- свои задачи ----------

    private fun tasksScreen() {
        backBar("🧩 Свои задачи")
        val info = card()
        info.addView(text(
            "Запиши любую последовательность нажатий в игре (яйца, молоко, пекарня), и бот будет повторять её по таймеру между делами. " +
                "Запись: панель в игре → ⋯ Ещё → 🧩 Задачи → 🔴 Записать. В конце верни игру в исходный вид: закрой окна и меню.",
            13f, cMuted
        ))
        content.addView(info)

        val n = cfg.macroCount()
        if (n == 0) content.addView(text("Задач пока нет", 13f, cMuted))
        for (m in 0 until n) {
            val iv = cfg.macroInterval(m)
            val c = card()
            c.addView(text("🧩 Задача " + (m + 1), 17f, cText, true))
            c.addView(text(
                cfg.macroTaps(m).size.toString() + " нажатий · " + (if (iv <= 0) "выключена" else "каждые $iv мин"),
                13f, cMuted
            ))
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(smallButton("− 5 мин") {
                cfg.setMacroInterval(m, cfg.macroInterval(m) - 5)
                render()
            })
            row.addView(smallButton("+ 5 мин") {
                cfg.setMacroInterval(m, cfg.macroInterval(m) + 5)
                render()
            })
            row.addView(smallButton("🗑") {
                cfg.deleteMacro(m)
                render()
            })
            c.addView(row)
            content.addView(c)
        }
    }

    // ---------- активация ----------

    private fun keyScreen() {
        backBar("🔑 Активация")
        val i = License.info(this)
        val c = card()
        val badge: String
        val col: Int
        when (i.state) {
            LicState.ACTIVE -> { badge = "✅ Ключ активен"; col = cGreen }
            LicState.EXPIRED -> { badge = "⌛ Срок действия истёк"; col = cRed }
            LicState.PENDING -> { badge = "⏳ Ключ ждёт проверки"; col = 0xFFFFC107.toInt() }
            LicState.INVALID -> { badge = "⛔ Ключ не подошёл"; col = cRed }
            LicState.NONE -> { badge = "⛔ Ключ не активирован"; col = cMuted }
        }
        c.addView(text(badge, 19f, col, true))
        if (i.state == LicState.ACTIVE) {
            c.addView(text("Осталось: " + License.left(i.expiresAt - System.currentTimeMillis()), 15f, cText, true))
            c.addView(text("Действует до " + License.expiresText(i.expiresAt), 13f, cMuted))
        }
        if (i.state == LicState.EXPIRED) c.addView(text("Истёк " + License.expiresText(i.expiresAt), 13f, cMuted))
        if (i.msg.isNotEmpty() && i.state != LicState.ACTIVE) c.addView(text(i.msg, 13f, cMuted))
        if (i.key.isNotEmpty()) c.addView(text("Ключ: " + i.key.take(8) + "••••", 13f, cMuted))
        c.addView(text("Устройство: " + License.deviceId(this), 12f, cMuted))
        keyEt = inputBox("Введи ключ: TTB-XXXX-XXXX-XXXX-XXXX")
        c.addView(keyEt)
        c.addView(button("Активировать", 1) {
            License.activate(this, keyEt.text.toString()) { r ->
                runOnUiThread {
                    toast(r.msg)
                    render()
                }
            }
        })
        if (i.key.isNotEmpty()) {
            c.addView(button("Удалить ключ", 2) {
                License.clear(this)
                render()
            })
        }
        if (!LicenseConfig.ENFORCE) c.addView(text("Сейчас бот работает и без ключа: проверка включится позже.", 12f, cMuted))
        content.addView(c)

        // ссылки: позже сюда подставим бота с ключами, канал и инструкцию
        val buy = card()
        buy.addView(text("Получить ключ", 16f, cText, true))
        buy.addView(text("Ключи будет выдавать бот в Telegram после покупки. Пока пиши разработчику.", 13f, cMuted))
        buy.addView(button("🤖 Бот с ключами в Telegram") { openLink(LicenseConfig.BOT_URL) })
        buy.addView(button("🛒 FunPay") { openLink(LicenseConfig.FUNPAY_URL) })
        buy.addView(button("💬 Написать разработчику", 1) { openLink(LicenseConfig.SUPPORT_URL) })
        buy.addView(button("📣 Канал обновлений") { openLink(LicenseConfig.CHANNEL_URL) })
        buy.addView(button("📖 Инструкция") { openLink(LicenseConfig.GUIDE_URL) })
        content.addView(buy)
    }

    // ---------- амбар ----------

    private fun numField(c: LinearLayout, label: String, value: Int): EditText {
        c.addView(text(label, 13f, cMuted))
        val e = inputBox(label)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(value.toString())
        c.addView(e)
        return e
    }

    private fun barnScreen() {
        backBar("📦 Силосная башня")
        val c = card()
        c.addView(text(
            "Бот считает урожай: после каждого сбора прибавляет «клеток × урожай с клетки» к занятому месту. " +
                "Когда места на следующий сбор не хватает, он идёт в лавку, выкладывает пшеницу (реклама на последнем слоте) " +
                "и вычитает проданное. Вместимость 0 = расчёт выключен, продажа идёт раз в N посадок.",
            13f, cMuted
        ))
        c.addView(text("Сейчас по расчёту бота занято: " + cfg.barnUsed, 15f, cText, true))
        val e1 = numField(c, "Клеток на первом поле", cfg.cellsOf(0))
        val e2 = numField(c, "Урожай с одной клетки", cfg.perCell)
        val e3 = numField(c, "Вместимость силосной башни (всего)", cfg.barnCap)
        val e4 = numField(c, "Занято сейчас", cfg.barnUsed)
        val e5 = numField(c, "Пшеницы в одном слоте лавки", cfg.perSlot)
        c.addView(button("Сохранить", 1) {
            cfg.setCells(0, e1.text.toString().toIntOrNull() ?: 0)
            cfg.perCell = e2.text.toString().toIntOrNull() ?: 2
            cfg.barnCap = e3.text.toString().toIntOrNull() ?: 0
            cfg.barnUsed = e4.text.toString().toIntOrNull() ?: 0
            cfg.perSlot = e5.text.toString().toIntOrNull() ?: 10
            toast("Сохранено")
            render()
        })
        content.addView(c)
    }

    // ---------- справка ----------

    private fun helpScreen() {
        backBar("📖 Как пользоваться")
        val c = card()
        c.addView(text(
            "1. Включи службу: Главная → Hay Day → «Включить службу». Если пункт серый (Android 13+): «Настройки приложения» → ⋮ → «Разрешить ограниченные настройки».\n\n" +
                "2. Открой Hay Day. Поверх игры появится панель TapTapBot's. Панель сама ничего не запускает.\n\n" +
                "3. Нажми «⚙ Настроить» и пройди шаги: камера, грядка, культура, область поля (растяни рамку), пустая земля, проверка посадки и сбора, продажа. На каждом шаге написано, что нажать.\n\n" +
                "4. «▶ Запустить»: бот работает сам. Статус виден сверху в игре, остановка кнопкой ■.\n\n" +
                "5. Несколько полей: панель → ⋯ Ещё → ➕ Поле. Поля должны быть рядом, чтобы камера не ехала при нажатии. Если камера съезжает, включи выравнивание 📷 в ⋯ Ещё: бот сам подтянет карту по эталону (👻 показывает эталон).\n\n" +
                "6. Свои задачи: ⋯ Ещё → 🧩 Задачи → 🔴 Записать.\n\n" +
                "7. Пауза и стоп: пока бот работает или идёт проверка (посадка, сбор, листание), в шапке панели есть ⏸ и ■, а в раскрытой панели большая кнопка. Пауза срабатывает после текущего действия.\n\n" +
                "8. Лавка со страницами слотов: на шаге «Пролистай лавку» проведи пальцем, лавка прокрутится по-настоящему, бот проверит это по картинке, а ты отметишь слоты на каждой странице. Число страниц меняется в ⋯ Ещё → 📄.\n\n" +
                "9. Скорость посева, сбора и лавки: панель → ⚡. В лавке бот сам находит пшеницу в списке по картинке, даже если другая культура заняла её место.\n\n" +
                "10. Силосная башня: числа (занято, вместимость, клетки) вводятся в самом начале мастера, их можно поправить на экране «📦 Силосная башня и расчёт места». Бот сам считает урожай и продаёт, когда места не хватает.\n\n" +
                "11. Если что-то идёт не так, загляни в журнал и отправь его разработчику.",
            14f, cText
        ))
        content.addView(c)
    }
}
