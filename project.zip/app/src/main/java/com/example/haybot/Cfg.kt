package com.example.haybot

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

data class P(val x: Float, val y: Float)

/** Роли точек. multi — можно несколько точек, min — сколько нужно минимум. */
enum class T(
    val icon: String,
    val label: String,
    val multi: Boolean,
    val min: Int,
    val color: Int
) {
    FIELD("🌱", "Грядка", false, 1, 0xFF4CAF50.toInt()),
    WHEAT("🌾", "Пшеница", false, 1, 0xFFFFC107.toInt()),
    ANCHOR("⚓", "Якорь", true, 0, 0xFF90A4AE.toInt()),
    AREA("🧭", "Поле", true, 4, 0xFF29B6F6.toInt()),
    HFIELD("🌿", "Грядка (сбор)", false, 1, 0xFF8BC34A.toInt()),
    SICKLE("🔪", "Серп", false, 1, 0xFFEF5350.toInt()),
    SHOP("🏪", "Лавка", false, 0, 0xFFAB47BC.toInt()),
    SLOT("🧺", "Слот", true, 1, 0xFFFF7043.toInt()),
    ITEM("📦", "Товар", false, 1, 0xFFFFCA28.toInt()),
    EXTRA("➕", "Доп. кнопка", true, 0, 0xFF26A69A.toInt()),
    AD("📢", "Реклама", false, 0, 0xFFEC407A.toInt()),
    PUT("✅", "Выставить", false, 1, 0xFF66BB6A.toInt()),
    CLOSE("❌", "Закрыть", false, 1, 0xFFE53935.toInt())
}

class Cfg(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private val prof = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)
    private val pts = HashMap<T, MutableList<P>>()
    private val acol = ArrayList<Int>()

    /** Вызывается, когда настройки заменили снаружи (загрузка профиля, импорт). */
    var onExternalChange: (() -> Unit)? = null

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "rev") {
            reload()
            onExternalChange?.invoke()
        }
    }

    init {
        reload()
        sp.registerOnSharedPreferenceChangeListener(listener)
    }

    fun reload() {
        for (t in T.values()) pts[t] = dec(sp.getString(t.name, null))
        acol.clear()
        val raw = sp.getString("acol", "") ?: ""
        for (x in raw.split(",")) if (x.isNotBlank()) acol.add(x.toInt())
    }

    var sellEvery: Int
        get() = sp.getInt("every", 3)
        set(v) {
            sp.edit().putInt("every", v.coerceIn(1, 9)).apply()
        }

    var rowGap: Int
        get() = sp.getInt("gap", 45)
        set(v) {
            sp.edit().putInt("gap", v.coerceIn(15, 150)).apply()
        }

    var useRec: Boolean
        get() = sp.getBoolean("rec", true)
        set(v) {
            sp.edit().putBoolean("rec", v).apply()
        }

    var growSec: Int
        get() = sp.getInt("grow", 121)
        set(v) {
            sp.edit().putInt("grow", v.coerceIn(20, 3600)).apply()
        }

    /** Сколько миллисекунд держим палец на иконке (пшеница, серп) перед тем, как вести по грядкам. */
    var holdMs: Int
        get() = sp.getInt("hold", 600)
        set(v) {
            sp.edit().putInt("hold", v.coerceIn(100, 2000)).apply()
        }

    fun anchorColors(): List<Int> = acol

    fun addAnchorColor(c: Int) {
        acol.add(c)
        saveAcol()
    }

    private fun saveAcol() {
        sp.edit().putString("acol", acol.joinToString(",")).apply()
    }

    fun getRef(t: T): Int? = if (sp.contains("ref_" + t.name)) sp.getInt("ref_" + t.name, 0) else null

    fun setRef(t: T, c: Int) {
        sp.edit().putInt("ref_" + t.name, c).apply()
    }

    fun add(t: T, p: P) {
        val l = pts[t]!!
        if (!t.multi) l.clear()
        l.add(p)
        save()
    }

    fun clear(t: T) {
        pts[t]!!.clear()
        if (t == T.ANCHOR) {
            acol.clear()
            saveAcol()
        }
        save()
        sp.edit().remove("ref_" + t.name).apply()
    }

    fun removeLast(t: T) {
        val l = pts[t]!!
        if (l.isNotEmpty()) {
            l.removeAt(l.size - 1)
            if (t == T.ANCHOR && acol.isNotEmpty()) {
                acol.removeAt(acol.size - 1)
                saveAcol()
            }
            save()
        }
    }

    fun truncate(t: T, keep: Int) {
        val l = pts[t]!!
        while (l.size > keep) l.removeAt(l.size - 1)
        if (t == T.ANCHOR) {
            while (acol.size > keep) acol.removeAt(acol.size - 1)
            saveAcol()
        }
        save()
    }

    fun list(t: T): List<P> = pts[t]!!
    fun first(t: T): P? = pts[t]!!.firstOrNull()

    /** Маршрут пальца по полю: змейка внутри выделенной области. */
    fun path(): List<P> = Geo.zigzag(list(T.AREA), rowGap.toFloat())

    /** Первая роль, которой не хватает точек, либо null если всё готово к запуску. */
    fun missing(): T? {
        for (t in listOf(T.FIELD, T.WHEAT, T.AREA, T.HFIELD, T.SICKLE)) {
            if (list(t).size < t.min) return t
        }
        if (first(T.SHOP) != null) {
            for (t in listOf(T.SLOT, T.ITEM, T.PUT, T.CLOSE)) {
                if (list(t).size < t.min) return t
            }
        }
        return null
    }

    // ---------- профили и экспорт ----------

    fun exportJson(): String {
        val o = JSONObject()
        o.put("v", 1)
        o.put("every", sellEvery)
        o.put("gap", rowGap)
        o.put("rec", useRec)
        o.put("grow", growSec)
        o.put("hold", holdMs)
        o.put("acol", acol.joinToString(","))
        val p = JSONObject()
        val r = JSONObject()
        for (t in T.values()) {
            p.put(t.name, enc(pts[t]!!))
            val ref = getRef(t)
            if (ref != null) r.put(t.name, ref)
        }
        o.put("pts", p)
        o.put("ref", r)
        return o.toString()
    }

    fun importJson(s: String): Boolean {
        try {
            val o = JSONObject(s.trim())
            val p = o.optJSONObject("pts") ?: return false
            val r = o.optJSONObject("ref")
            val e = sp.edit()
            e.putInt("every", o.optInt("every", 3).coerceIn(1, 9))
            e.putInt("gap", o.optInt("gap", 45).coerceIn(15, 150))
            e.putBoolean("rec", o.optBoolean("rec", true))
            e.putInt("grow", o.optInt("grow", 121).coerceIn(20, 3600))
            e.putInt("hold", o.optInt("hold", 600).coerceIn(100, 2000))
            e.putString("acol", o.optString("acol", ""))
            for (t in T.values()) {
                e.putString(t.name, p.optString(t.name, ""))
                if (r != null && r.has(t.name)) e.putInt("ref_" + t.name, r.getInt(t.name))
                else e.remove("ref_" + t.name)
            }
            e.putInt("rev", sp.getInt("rev", 0) + 1)
            e.apply()
            reload()
            return true
        } catch (_: Exception) {
            return false
        }
    }

    fun profileNames(): List<String> = prof.all.keys.sorted()

    fun saveProfile(name: String) {
        prof.edit().putString(name, exportJson()).apply()
    }

    fun deleteProfile(name: String) {
        prof.edit().remove(name).apply()
    }

    fun profileJson(name: String): String? = prof.getString(name, null)

    fun loadProfile(name: String): Boolean {
        val s = prof.getString(name, null) ?: return false
        return importJson(s)
    }

    private fun save() {
        val e = sp.edit()
        for ((t, l) in pts) e.putString(t.name, enc(l))
        e.apply()
    }

    private fun enc(l: List<P>) = l.joinToString(";") { "${it.x},${it.y}" }

    private fun dec(s: String?): MutableList<P> {
        if (s.isNullOrBlank()) return mutableListOf()
        return s.split(";").mapNotNull {
            val a = it.split(",")
            if (a.size == 2) P(a[0].toFloat(), a[1].toFloat()) else null
        }.toMutableList()
    }
}
