#!/usr/bin/env python3
"""Проверка защиты эталонной механики посева (WHEAT-SYNC).

Берёт тексты между маркерами `// ===== WHEAT-SYNC BEGIN <имя> =====` и `END <имя>`
в BotService.kt, считает SHA-256 и сравнивает с reference/wheat_sync.sha256.
  python3 tools/wheat_sync_check.py            проверка (код возврата 1 при расхождении)
  python3 tools/wheat_sync_check.py --update   переписать эталон (ТОЛЬКО с разрешения владельца)
"""
import difflib, hashlib, re, sys, pathlib

root = pathlib.Path(__file__).resolve().parent.parent
src = root / "app/src/main/java/com/example/haybot/BotService.kt"
ref_txt = root / "reference/wheat_sync_reference.kt.txt"
ref_hash = root / "reference/wheat_sync.sha256"

NAMES = ["actField", "endHold", "pause", "jit_j", "trailPath", "tap", "holdDrag", "play"]


def extract() -> str:
    text = src.read_text(encoding="utf-8").replace("\r\n", "\n")
    out = []
    for n in NAMES:
        m = re.search(r"^[ \t]*// ===== WHEAT-SYNC BEGIN " + re.escape(n) + r" =====\n(.*?)^[ \t]*// ===== WHEAT-SYNC END " + re.escape(n) + r" =====$",
                      text, re.S | re.M)
        if not m:
            print("ОШИБКА: нет маркеров блока", n)
            sys.exit(1)
        out.append("//// " + n + "\n" + m.group(1))
    return "\n".join(out)


def digest(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


cur = extract()
if "--update" in sys.argv:
    ref_txt.write_text(cur, encoding="utf-8")
    ref_hash.write_text(digest(cur) + "\n", encoding="utf-8")
    print("эталон обновлён:", digest(cur))
    sys.exit(0)

want = ref_hash.read_text().strip()
got = digest(cur)
if got == want:
    print("WHEAT-SYNC: OK", got)
    sys.exit(0)
print("WHEAT-SYNC: РАСХОЖДЕНИЕ с эталоном!\n ожидалось", want, "\n получено ", got)
old = ref_txt.read_text(encoding="utf-8").split("\n")
for line in list(difflib.unified_diff(old, cur.split("\n"), "эталон", "сейчас", lineterm=""))[:80]:
    print(line)
sys.exit(1)
