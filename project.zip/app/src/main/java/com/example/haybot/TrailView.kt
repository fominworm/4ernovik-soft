package com.example.haybot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Неоновый переливающийся след от нажатий и свайпов бота, как «показ касаний» в записи экрана. */
class TrailView(ctx: Context) : View(ctx) {
    private class Tr(val pts: List<P>, val born: Long, val ms: Long)

    private val trails = ArrayList<Tr>()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val life = 1000L
    private val hsv = FloatArray(3)

    /** Пока true, след не рисуется: иначе он попадает на скриншоты и сбивает распознавание. */
    @Volatile var quiet = false

    init {
        line.style = Paint.Style.STROKE
        line.strokeCap = Paint.Cap.ROUND
    }

    fun add(pts: List<P>, ms: Long) {
        if (pts.isEmpty()) return
        trails.add(Tr(pts, System.currentTimeMillis(), ms.coerceAtLeast(60L)))
        if (trails.size > 60) trails.removeAt(0)
        invalidate()
    }

    private fun neon(hue: Float, alpha: Int): Int {
        hsv[0] = ((hue % 360f) + 360f) % 360f
        hsv[1] = 0.85f
        hsv[2] = 1f
        return Color.HSVToColor(alpha.coerceIn(0, 255), hsv)
    }

    override fun onDraw(c: Canvas) {
        if (quiet) return
        val now = System.currentTimeMillis()
        trails.removeAll { now - it.born > it.ms + life }
        if (trails.isEmpty()) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        for (t in trails) {
            val n = t.pts.size
            val age = now - t.born
            if (n == 1) {
                val f = (age.toFloat() / life).coerceIn(0f, 1f)
                val a = (255 * (1f - f)).toInt()
                val r = 18f + 70f * f
                line.strokeWidth = 14f
                line.color = neon(now / 3f, a)
                c.drawCircle(t.pts[0].x - ox, t.pts[0].y - oy, r, line)
                line.strokeWidth = 5f
                line.color = neon(now / 3f + 120f, a)
                c.drawCircle(t.pts[0].x - ox, t.pts[0].y - oy, r * 0.55f, line)
                continue
            }
            val head = ((age.toFloat() / t.ms) * (n - 1)).coerceIn(0f, (n - 1).toFloat())
            for (i in 1 until n) {
                if (i - 1 > head) break
                val segAge = age - t.ms * i / (n - 1)
                if (segAge > life) continue
                val f = (segAge.toFloat() / life).coerceIn(0f, 1f)
                val a = (255 * (1f - f)).toInt()
                val hue = now / 3f + i * 9f
                val x0 = t.pts[i - 1].x - ox
                val y0 = t.pts[i - 1].y - oy
                val x1 = t.pts[i].x - ox
                val y1 = t.pts[i].y - oy
                line.strokeWidth = 26f
                line.color = neon(hue, a / 4)
                c.drawLine(x0, y0, x1, y1, line)
                line.strokeWidth = 11f
                line.color = neon(hue, a)
                c.drawLine(x0, y0, x1, y1, line)
                line.strokeWidth = 3f
                line.color = Color.argb(a, 255, 255, 255)
                c.drawLine(x0, y0, x1, y1, line)
            }
        }
        postInvalidateOnAnimation()
    }
}
