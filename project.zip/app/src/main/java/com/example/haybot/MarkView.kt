package com.example.haybot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Слой на весь экран. Когда armed=true — ловит одно нажатие (onTap сработает при отпускании пальца)
 * и рисует записанные точки. Когда armed=false — окно прозрачно для касаний (задаётся флагами окна).
 */
class MarkView(ctx: Context, private val cfg: Cfg) : View(ctx) {
    var armed = false
    var showAll = false
    var onTap: ((Float, Float) -> Unit)? = null

    /** Режим свайпа: длинное движение пальца сообщается через onSwipe (начало, конец, длительность). */
    var swipeMode = false
    var onSwipe: ((P, P, Long) -> Unit)? = null
    private var downT = 0L

    /** Редактор рамки поля: 4 угла, которые можно тянуть, и сама рамка, которую можно двигать. */
    var editMode = false

    /** Роль текущего шага: рисуем только её точки, чтобы разметка не закрывала экран. showAll рисует всё. */
    var focus: T? = null
    var editPts: MutableList<P>? = null

    /** true — обычный прямоугольник (силос, лавка): без змейки и маршрута, только углы и перенос. false — рамка поля. */
    var rectOnly = false
    private var rMode = 0   // 0 — мимо, 1 — тянем угол, 2 — двигаем всю рамку
    private var fixX = 0f
    private var fixY = 0f
    private var dragIdx = -1
    private var lastX = 0f
    private var lastY = 0f

    private fun inside(pts: List<P>, x: Float, y: Float): Boolean {
        val q = Geo.order(pts)
        var res = false
        var j = q.size - 1
        for (i in q.indices) {
            if ((q[i].y > y) != (q[j].y > y) &&
                x < (q[j].x - q[i].x) * (y - q[i].y) / (q[j].y - q[i].y) + q[i].x
            ) res = !res
            j = i
        }
        return res
    }

    /** Приводит 4 точки к порядку: левый верх, правый верх, правый низ, левый низ. */
    private fun setRect(pts: MutableList<P>, x0: Float, y0: Float, x1: Float, y1: Float) {
        var ax = x0
        var ay = y0
        var bx = x1
        var by = y1
        if (bx - ax < 60f) bx = ax + 60f
        if (by - ay < 40f) by = ay + 40f
        while (pts.size < 4) pts.add(P(0f, 0f))
        pts[0] = P(ax, ay)
        pts[1] = P(bx, ay)
        pts[2] = P(bx, by)
        pts[3] = P(ax, by)
    }

    private fun handleRect(e: MotionEvent, pts: MutableList<P>): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                rMode = 0
                if (pts.size >= 4) {
                    val x0 = pts.minOf { it.x }
                    val x1 = pts.maxOf { it.x }
                    val y0 = pts.minOf { it.y }
                    val y1 = pts.maxOf { it.y }
                    setRect(pts, x0, y0, x1, y1)
                    var best = 120f
                    for (i in 0 until 4) {
                        val d = hypot(pts[i].x - e.rawX, pts[i].y - e.rawY)
                        if (d < best) {
                            best = d
                            rMode = 1
                            fixX = pts[(i + 2) % 4].x
                            fixY = pts[(i + 2) % 4].y
                        }
                    }
                    if (rMode == 0 && e.rawX in x0..x1 && e.rawY in y0..y1) rMode = 2
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (rMode == 1) {
                    setRect(pts, minOf(fixX, e.rawX), minOf(fixY, e.rawY), maxOf(fixX, e.rawX), maxOf(fixY, e.rawY))
                } else if (rMode == 2) {
                    val mx = e.rawX - lastX
                    val my = e.rawY - lastY
                    for (i in pts.indices) pts[i] = P(pts[i].x + mx, pts[i].y + my)
                }
                lastX = e.rawX
                lastY = e.rawY
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> rMode = 0
        }
        return true
    }

    private fun handleEdit(e: MotionEvent, pts: MutableList<P>): Boolean {
        if (rectOnly) return handleRect(e, pts)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                dragIdx = -1
                var best = 110f
                for (i in pts.indices) {
                    val d = hypot(pts[i].x - e.rawX, pts[i].y - e.rawY)
                    if (d < best) {
                        best = d
                        dragIdx = i
                    }
                }
                if (dragIdx == -1 && inside(pts, e.rawX, e.rawY)) dragIdx = -2
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - lastX
                val dy = e.rawY - lastY
                if (dragIdx >= 0) {
                    pts[dragIdx] = P(e.rawX, e.rawY)
                } else if (dragIdx == -2) {
                    for (i in pts.indices) pts[i] = P(pts[i].x + dx, pts[i].y + dy)
                }
                lastX = e.rawX
                lastY = e.rawY
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragIdx = -1
        }
        return true
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        Sprites.init(context)
    }

    private var down = false
    private var dx = 0f
    private var dy = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!armed) return false
        val ep = editPts
        if (editMode && ep != null) return handleEdit(e, ep)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                dx = e.rawX
                dy = e.rawY
                downT = System.currentTimeMillis()
            }
            MotionEvent.ACTION_UP -> {
                if (down) {
                    down = false
                    val ux = e.rawX
                    val uy = e.rawY
                    if (swipeMode && hypot(ux - dx, uy - dy) >= 80f) {
                        onSwipe?.invoke(P(dx, dy), P(ux, uy), System.currentTimeMillis() - downT)
                    } else {
                        onTap?.invoke(dx, dy)
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> down = false
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        if (!armed && !showAll) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        if (armed) c.drawColor(0x18FFEB3B)

        val now = System.currentTimeMillis()
        val sc = (width / 2400f).coerceIn(0.6f, 1.6f)
        var animate = false
        // область поля и предпросмотр змейки
        // змейка и маршрут только для поля; рамки силоса и лавки — обычные прямоугольники без них
        val area: List<P> = if (editMode && !rectOnly) (editPts ?: cfg.list(T.AREA)) else cfg.list(T.AREA)
        val drawArea = (editMode && !rectOnly) || showAll || focus == T.AREA
        if (drawArea && area.size >= 3) {
            val q = Geo.order(area)
            val poly = Path()
            poly.moveTo(q[0].x - ox, q[0].y - oy)
            for (i in 1 until q.size) poly.lineTo(q[i].x - ox, q[i].y - oy)
            poly.close()
            p.style = Paint.Style.FILL
            p.color = 0x3329B6F6
            c.drawPath(poly, p)
            // рамка из бегущих цветных штрихов
            Dashes.drawPoly(c, q.map { P(it.x - ox, it.y - oy) }, now, sc)
            animate = true
        }
        if (drawArea && area.size >= 4) {
            val f = cfg.first(T.FIELD)
            val z = if (f != null) Geo.zigzagFrom(area, cfg.rowGap.toFloat(), f) else Geo.zigzag(area, cfg.rowGap.toFloat())
            // маршрут бота тонкой линией, а по нему ползёт змейка: сеет или собирает
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * sc
            p.color = 0x55FFFFFF
            for (i in 1 until z.size) {
                c.drawLine(z[i - 1].x - ox, z[i - 1].y - oy, z[i].x - ox, z[i].y - oy, p)
            }
            if (z.size >= 2) {
                val zp = z.map { P(it.x - ox, it.y - oy) }
                val total = Snake.length(zp)
                val cycle = total + 12f * 29f * sc
                val hd = (now * 0.52f * sc) % cycle   // примерно 520 пикселей в секунду
                val harvest = focus == T.HFIELD || focus == T.SICKLE
                if (showAll) {
                    Snake.draw(c, zp, hd, 1, now, sc)
                    Snake.draw(c, zp, (hd + cycle / 2f) % cycle, 2, now, sc)
                } else {
                    Snake.draw(c, zp, hd, if (harvest) 2 else 1, now, sc)
                }
                animate = true
            }
        }

        val ep = editPts
        if (editMode && rectOnly && ep != null && ep.size >= 4) {
            val rc = focus?.color ?: T.AREA.color
            val l = ep.minOf { it.x } - ox
            val tp = ep.minOf { it.y } - oy
            val r = ep.maxOf { it.x } - ox
            val b = ep.maxOf { it.y } - oy
            p.style = Paint.Style.FILL
            p.color = (rc and 0x00FFFFFF) or 0x33000000
            c.drawRect(l, tp, r, b, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f * sc
            p.color = rc
            c.drawRect(l, tp, r, b, p)
            p.style = Paint.Style.FILL
            for (q in ep) {
                p.color = Color.WHITE
                c.drawCircle(q.x - ox, q.y - oy, 30f, p)
                p.color = rc
                c.drawCircle(q.x - ox, q.y - oy, 20f, p)
            }
        }
        if (editMode && !rectOnly) {
            for (q in area) {
                p.style = Paint.Style.FILL
                p.color = Color.WHITE
                c.drawCircle(q.x - ox, q.y - oy, 34f, p)
                p.color = T.AREA.color
                c.drawCircle(q.x - ox, q.y - oy, 24f, p)
            }
        }
        p.style = Paint.Style.FILL
        for (t in T.values()) {
            if (editMode && rectOnly) break
            if (!showAll && !editMode && t != focus) continue
            for ((i, pt) in cfg.list(t).withIndex()) {
                p.color = t.color
                c.drawCircle(pt.x - ox, pt.y - oy, 20f, p)
                p.color = Color.WHITE
                p.textSize = 30f
                p.textAlign = Paint.Align.LEFT
                val label = t.icon + (if (t.multi) (i + 1).toString() else "")
                c.drawText(label, pt.x - ox + 24f, pt.y - oy + 10f, p)
            }
        }
        if (animate) postInvalidateOnAnimation()
    }
}