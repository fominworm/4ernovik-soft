package com.example.haybot

import android.content.Context

data class P(val x: Float, val y: Float)

enum class T(
    val icon: String,
    val label: String,
    val multi: Boolean,
    val min: Int,
    val color: Int,
    val help: String
) {
    FIELD(
        "🌱", "Поле", false, 1, 0xFF4CAF50.toInt(),
        "Нажми «📍 Метка»: экран станет жёлтым.\nТапни по центру любой грядки. Точка запишется, игра при этом не нажмётся."
    ),
    WHEAT(
        "🌾", "Пшеница в меню", false, 1, 0xFFFFC107.toInt(),
        "1) В игре тапни пустую грядку — откроется меню с культурами.\n2) Нажми «📍 Метка» и тапни иконку пшеницы.\nПанель мешает? Перетащи её за ≡."
    ),
    PATH(
        "🧭", "Путь по полю", true, 2, 0xFF29B6F6.toInt(),
        "Это путь пальца по всем грядкам.\n«📍 Метка» → тапни первую грядку. Снова «📍 Метка» → следующая точка… Последняя точка — последняя грядка. Если рядов несколько, иди зигзагом. Минимум 2 точки. Проверить: кнопка 👁."
    ),
    SICKLE(
        "🔪", "Серп", false, 1, 0xFFEF5350.toInt(),
        "Дождись, пока пшеница созреет (около 2 минут).\nТапни спелую грядку в игре — рядом появится серп.\n«📍 Метка» → тапни серп."
    ),
    SHOP(
        "🏪", "Лавка на ферме", false, 0, 0xFFAB47BC.toInt(),
        "Лавка и поле должны быть на экране вместе.\n«📍 Метка» → тапни лавку.\nНе нужна продажа? Просто жми «Далее ▶», шаги про лавку пропустятся."
    ),
    SLOTS(
        "🧺", "Слоты лавки", true, 1, 0xFFFF7043.toInt(),
        "Тапни лавку в игре — откроется окно со слотами.\nДля каждого слота: «📍 Метка» → тапни слот, по порядку.\nБот нажмёт каждый слот 2 раза: первый собирает выручку, второй открывает выбор товара."
    ),
    ITEM(
        "📦", "Пшеница в списке", false, 1, 0xFFFFCA28.toInt(),
        "Тапни пустой слот в игре — откроется выбор товара.\n«📍 Метка» → тапни пшеницу в списке."
    ),
    EXTRA(
        "➕", "Доп. кнопки лота", true, 0, 0xFF26A69A.toInt(),
        "Необязательно. Кнопки в окне лота, которые надо нажать перед продажей (например «максимум количества», «максимум цены»).\nКаждая «📍 Метка» — один тап по порядку. Не нужно — «Далее ▶»."
    ),
    AD(
        "📢", "Реклама", false, 0, 0xFFEC407A.toInt(),
        "Необязательно. Кнопка рекламы в окне лота. Бот жмёт её не чаще раза в 5 минут.\n«📍 Метка» → тапни её. Не нужна — «Далее ▶»."
    ),
    PUT(
        "✅", "Выставить на продажу", false, 1, 0xFF66BB6A.toInt(),
        "«📍 Метка» → тапни кнопку, которая выставляет лот на продажу (в окне лота)."
    ),
    CLOSE(
        "❌", "Закрыть лавку", false, 1, 0xFFE53935.toInt(),
        "Закрой окно лота, затем «📍 Метка» → тапни крестик закрытия лавки."
    )
}

class Cfg(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private val pts = HashMap<T, MutableList<P>>()

    init {
        for (t in T.values()) pts[t] = dec(sp.getString(t.name, null))
    }

    var sellEvery: Int
        get() = sp.getInt("every", 3)
        set(v) {
            sp.edit().putInt("every", v.coerceIn(1, 9)).apply()
        }

    fun add(t: T, p: P) {
        val l = pts[t]!!
        if (!t.multi) l.clear()
        l.add(p)
        save()
    }

    fun clear(t: T) {
        pts[t]!!.clear()
        save()
    }

    fun list(t: T): List<P> = pts[t]!!
    fun first(t: T): P? = pts[t]!!.firstOrNull()

    /** Первая цель, которой не хватает точек, либо null если всё готово. */
    fun missing(): T? {
        for (t in listOf(T.FIELD, T.WHEAT, T.PATH, T.SICKLE)) {
            if (list(t).size < t.min) return t
        }
        if (first(T.SHOP) != null) {
            for (t in listOf(T.SLOTS, T.ITEM, T.PUT, T.CLOSE)) {
                if (list(t).size < t.min) return t
            }
        }
        return null
    }

    private fun save() {
        val e = sp.edit()
        for ((t, l) in pts) e.putString(t.name, l.joinToString(";") { "${it.x},${it.y}" })
        e.apply()
    }

    private fun dec(s: String?): MutableList<P> {
        if (s.isNullOrBlank()) return mutableListOf()
        return s.split(";").mapNotNull {
            val a = it.split(",")
            if (a.size == 2) P(a[0].toFloat(), a[1].toFloat()) else null
        }.toMutableList()
    }
}
