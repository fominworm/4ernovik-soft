package com.example.haybot

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class P(val x: Float, val y: Float)

/** Одно нажатие в записанной задаче: куда нажать и сколько ждать перед ним. */
data class MTap(val p: P, val dtMs: Long)

/** Роли точек. multi — можно несколько точек, min — сколько нужно минимум, perField — своя у каждого поля. */
enum class T(
    val icon: String,
    val label: String,
    val multi: Boolean,
    val min: Int,
    val color: Int,
    val perField: Boolean = false
) {
    FIELD("🌱", "Грядка", false, 1, 0xFF4CAF50.toInt(), true),
    WHEAT("🌾", "Культура", false, 1, 0xFFFFC107.toInt(), true),
    ANCHOR("⚓", "Якорь", true, 0, 0xFF90A4AE.toInt()),
    AREA("🧭", "Поле", true, 4, 0xFF29B6F6.toInt(), true),
    HFIELD("🌿", "Грядка (сбор)", false, 1, 0xFF8BC34A.toInt(), true),
    SICKLE("🔪", "Серп", false, 1, 0xFFEF5350.toInt(), true),
    SHOP("🏪", "Лавка", false, 0, 0xFFAB47BC.toInt()),
    SLOT("🧺", "Слот", true, 1, 0xFFFF7043.toInt()),
    ITEM("📦", "Товар", false, 1, 0xFFFFCA28.toInt()),
    EXTRA("➕", "Доп. кнопка", true, 0, 0xFF26A69A.toInt()),
    AD("📢", "Реклама", false, 0, 0xFFEC407A.toInt()),
    PUT("✅", "Выставить", false, 1, 0xFF66BB6A.toInt()),
    CLOSE("❌", "Закрыть", false, 1, 0xFFE53935.toInt())
}

class Cfg(ctx: Context) {
    companion object {
        const val MAXF = 4   // максимум полей
        const val MAXM = 5   // максимум своих задач
    }

    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private val prof = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)
    private val pts = HashMap<String, MutableList<P>>()
    private val acol = ArrayList<Int>()

    /** Какое поле сейчас настраиваем или показываем. */
    var cur = 0

    /** Вызывается, когда настройки заменили снаружи (загрузка профиля, импорт). */
    var onExternalChange: (() -> Unit)? = null

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "rev") {
            reload()
            onExternalChange?.invoke()
        }
    }

    init {
        reload()
        sp.registerOnSharedPreferenceChangeListener(listener)
    }

    private fun key(t: T, f: Int) = if (t.perField && f > 0) t.name + "#" + f else t.name

    fun reload() {
        pts.clear()
        for (f in 0 until MAXF) {
            for (t in T.values()) {
                if (f > 0 && !t.perField) continue
                val k = key(t, f)
                pts[k] = dec(sp.getString(k, null))
            }
        }
        acol.clear()
        val raw = sp.getString("acol", "") ?: ""
        for (x in raw.split(",")) if (x.isNotBlank()) acol.add(x.toInt())
    }

    // ---------- настройки ----------

    var sellEvery: Int
        get() = sp.getInt("every", 3)
        set(v) {
            sp.edit().putInt("every", v.coerceIn(1, 9)).apply()
        }

    var rowGap: Int
        get() = sp.getInt("gap", 45)
        set(v) {
            sp.edit().putInt("gap", v.coerceIn(15, 150)).apply()
        }

    var useRec: Boolean
        get() = sp.getBoolean("rec", true)
        set(v) {
            sp.edit().putBoolean("rec", v).apply()
        }

    /** Сколько миллисекунд держим палец на иконке (культура, серп) перед тем, как вести по грядкам. */
    var holdMs: Int
        get() = sp.getInt("hold", 600)
        set(v) {
            sp.edit().putInt("hold", v.coerceIn(100, 2000)).apply()
        }

    /** Как вести палец: 0 плавно, 1 медленно, 2 по шагам, 3 как человек (быстро туда-сюда). */
    var plantMode: Int
        get() = sp.getInt("pmode", 3)
        set(v) {
            sp.edit().putInt("pmode", ((v % 4) + 4) % 4).apply()
        }

    var fieldCount: Int
        get() = sp.getInt("fcount", 1).coerceIn(1, MAXF)
        set(v) {
            sp.edit().putInt("fcount", v.coerceIn(1, MAXF)).apply()
        }

    /** Время созревания в секундах для поля f. */
    fun grow(f: Int = cur): Int = sp.getInt(if (f > 0) "grow#$f" else "grow", 121)

    fun setGrow(v: Int, f: Int = cur) {
        sp.edit().putInt(if (f > 0) "grow#$f" else "grow", v.coerceIn(20, 3600)).apply()
    }

    // ---------- эталоны цвета ----------

    fun getRef(t: T, f: Int = cur): Int? {
        val k = "ref_" + key(t, f)
        return if (sp.contains(k)) sp.getInt(k, 0) else null
    }

    fun setRef(t: T, c: Int, f: Int = cur) {
        sp.edit().putInt("ref_" + key(t, f), c).apply()
    }

    fun anchorColors(): List<Int> = acol

    fun addAnchorColor(c: Int) {
        acol.add(c)
        saveAcol()
    }

    private fun saveAcol() {
        sp.edit().putString("acol", acol.joinToString(",")).apply()
    }

    // ---------- точки ----------

    private fun mlist(t: T, f: Int): MutableList<P> = pts.getOrPut(key(t, f)) { mutableListOf() }

    fun list(t: T, f: Int = cur): List<P> = mlist(t, f)
    fun first(t: T, f: Int = cur): P? = mlist(t, f).firstOrNull()

    fun add(t: T, p: P) {
        val l = mlist(t, cur)
        if (!t.multi) l.clear()
        l.add(p)
        save()
    }

    fun clear(t: T) {
        mlist(t, cur).clear()
        if (t == T.ANCHOR) {
            acol.clear()
            saveAcol()
        }
        save()
        sp.edit().remove("ref_" + key(t, cur)).apply()
    }

    fun removeLast(t: T) {
        val l = mlist(t, cur)
        if (l.isNotEmpty()) {
            l.removeAt(l.size - 1)
            if (t == T.ANCHOR && acol.isNotEmpty()) {
                acol.removeAt(acol.size - 1)
                saveAcol()
            }
            save()
        }
    }

    fun truncate(t: T, keep: Int) {
        val l = mlist(t, cur)
        while (l.size > keep) l.removeAt(l.size - 1)
        if (t == T.ANCHOR) {
            while (acol.size > keep) acol.removeAt(acol.size - 1)
            saveAcol()
        }
        save()
    }

    /** Маршрут пальца по полю f: змейка внутри выделенной области. */
    fun path(f: Int = cur): List<P> = Geo.zigzag(list(T.AREA, f), rowGap.toFloat())

    /** Маршрут, который начинается рядом с выбранной грядкой и расходится от неё. */
    fun pathFrom(near: P, f: Int = cur): List<P> = Geo.zigzagFrom(list(T.AREA, f), rowGap.toFloat(), near)

    /** Первое поле и роль, которым не хватает точек, либо null если всё готово к запуску. */
    fun missingPair(): Pair<Int, T>? {
        for (f in 0 until fieldCount) {
            for (t in listOf(T.FIELD, T.WHEAT, T.AREA, T.HFIELD, T.SICKLE)) {
                if (list(t, f).size < t.min) return Pair(f, t)
            }
        }
        if (first(T.SHOP, 0) != null) {
            for (t in listOf(T.SLOT, T.ITEM, T.PUT, T.CLOSE)) {
                if (list(t, 0).size < t.min) return Pair(0, t)
            }
        }
        return null
    }

    fun missing(): T? = missingPair()?.second

    /** Убирает последнее добавленное поле (кроме первого). */
    fun removeField() {
        val last = fieldCount - 1
        if (last < 1) return
        val e = sp.edit()
        for (t in T.values()) {
            if (!t.perField) continue
            mlist(t, last).clear()
            e.remove("ref_" + key(t, last))
        }
        e.remove("grow#$last")
        e.apply()
        save()
        fieldCount = last
        if (cur >= last) cur = last - 1
    }

    // ---------- свои задачи (макросы) ----------

    fun macroCount(): Int = sp.getInt("mcount", 0).coerceIn(0, MAXM)

    fun macroTaps(m: Int): List<MTap> {
        val s = sp.getString("mac$m", "") ?: ""
        if (s.isBlank()) return emptyList()
        return s.split(";").mapNotNull {
            val a = it.split(",")
            if (a.size == 3) MTap(P(a[0].toFloat(), a[1].toFloat()), a[2].toLong()) else null
        }
    }

    /** Сохраняет новую задачу, возвращает её номер или -1 если места нет. */
    fun saveMacro(taps: List<MTap>): Int {
        val n = macroCount()
        if (n >= MAXM) return -1
        sp.edit()
            .putString("mac$n", taps.joinToString(";") { "${it.p.x},${it.p.y},${it.dtMs}" })
            .putInt("mint$n", 10)
            .putInt("mcount", n + 1)
            .apply()
        return n
    }

    /** Интервал запуска в минутах, 0 — задача выключена. */
    fun macroInterval(m: Int): Int = sp.getInt("mint$m", 10)

    fun setMacroInterval(m: Int, v: Int) {
        sp.edit().putInt("mint$m", v.coerceIn(0, 720)).apply()
    }

    fun deleteMacro(m: Int) {
        val n = macroCount()
        if (m < 0 || m >= n) return
        val e = sp.edit()
        for (i in m until n - 1) {
            e.putString("mac$i", sp.getString("mac${i + 1}", "") ?: "")
            e.putInt("mint$i", sp.getInt("mint${i + 1}", 10))
        }
        e.remove("mac${n - 1}")
        e.remove("mint${n - 1}")
        e.putInt("mcount", n - 1)
        e.apply()
    }

    // ---------- профили и экспорт ----------

    fun exportJson(): String {
        val o = JSONObject()
        o.put("v", 2)
        o.put("every", sellEvery)
        o.put("gap", rowGap)
        o.put("rec", useRec)
        o.put("hold", holdMs)
        o.put("pmode", plantMode)
        o.put("fcount", fieldCount)
        o.put("acol", acol.joinToString(","))
        val g = JSONObject()
        for (f in 0 until MAXF) g.put("g$f", grow(f))
        o.put("grow", g)
        val p = JSONObject()
        for ((k, l) in pts) p.put(k, enc(l))
        o.put("pts", p)
        val r = JSONObject()
        for (f in 0 until MAXF) {
            for (t in T.values()) {
                if (f > 0 && !t.perField) continue
                val ref = getRef(t, f)
                if (ref != null) r.put(key(t, f), ref)
            }
        }
        o.put("ref", r)
        val m = JSONArray()
        for (i in 0 until macroCount()) {
            val mo = JSONObject()
            mo.put("taps", sp.getString("mac$i", "") ?: "")
            mo.put("int", macroInterval(i))
            m.put(mo)
        }
        o.put("mac", m)
        return o.toString()
    }

    fun importJson(s: String): Boolean {
        try {
            val o = JSONObject(s.trim())
            val p = o.optJSONObject("pts") ?: return false
            val r = o.optJSONObject("ref")
            val e = sp.edit()
            e.putInt("every", o.optInt("every", 3).coerceIn(1, 9))
            e.putInt("gap", o.optInt("gap", 45).coerceIn(15, 150))
            e.putBoolean("rec", o.optBoolean("rec", true))
            e.putInt("hold", o.optInt("hold", 600).coerceIn(100, 2000))
            e.putInt("pmode", o.optInt("pmode", 3))
            e.putInt("fcount", o.optInt("fcount", 1).coerceIn(1, MAXF))
            e.putString("acol", o.optString("acol", ""))
            val g = o.optJSONObject("grow")
            for (f in 0 until MAXF) {
                val v = if (g != null) g.optInt("g$f", 121) else (if (f == 0) o.optInt("grow", 121) else 121)
                e.putInt(if (f > 0) "grow#$f" else "grow", v.coerceIn(20, 3600))
            }
            for (f in 0 until MAXF) {
                for (t in T.values()) {
                    if (f > 0 && !t.perField) continue
                    val k = key(t, f)
                    e.putString(k, p.optString(k, ""))
                    if (r != null && r.has(k)) e.putInt("ref_$k", r.getInt(k)) else e.remove("ref_$k")
                }
            }
            for (i in 0 until MAXM) {
                e.remove("mac$i")
                e.remove("mint$i")
            }
            val m = o.optJSONArray("mac")
            var cnt = 0
            if (m != null) {
                for (i in 0 until minOf(m.length(), MAXM)) {
                    val mo = m.getJSONObject(i)
                    e.putString("mac$i", mo.optString("taps", ""))
                    e.putInt("mint$i", mo.optInt("int", 10))
                    cnt++
                }
            }
            e.putInt("mcount", cnt)
            e.putInt("rev", sp.getInt("rev", 0) + 1)
            e.apply()
            reload()
            return true
        } catch (_: Exception) {
            return false
        }
    }

    fun profileNames(): List<String> = prof.all.keys.sorted()

    fun saveProfile(name: String) {
        prof.edit().putString(name, exportJson()).apply()
    }

    fun deleteProfile(name: String) {
        prof.edit().remove(name).apply()
    }

    fun profileJson(name: String): String? = prof.getString(name, null)

    fun loadProfile(name: String): Boolean {
        val s = prof.getString(name, null) ?: return false
        return importJson(s)
    }

    private fun save() {
        val e = sp.edit()
        for ((k, l) in pts) e.putString(k, enc(l))
        e.apply()
    }

    private fun enc(l: List<P>) = l.joinToString(";") { "${it.x},${it.y}" }

    private fun dec(s: String?): MutableList<P> {
        if (s.isNullOrBlank()) return mutableListOf()
        return s.split(";").mapNotNull {
            val a = it.split(",")
            if (a.size == 2) P(a[0].toFloat(), a[1].toFloat()) else null
        }.toMutableList()
    }
}
