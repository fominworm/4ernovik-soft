#!/usr/bin/env python3
"""Генератор ключей TapTapBot's.

Примеры:
  python3 keygen.py --count 50 --days 30 --channel funpay --batch FP-001
  python3 keygen.py --count 100 --days 30 --channel tg --batch TG-001
  python3 keygen.py --verify TTB-XXXX-XXXX-XXXX-XXXX

Каждая партия живёт в своём канале (tg / funpay / manual), поэтому один ключ не продаётся дважды.
Файлы:
  <batch>.csv         полные записи для базы сервера (key,days,channel,batch,status,created)
  <batch>_keys.txt    только ключи, по одному в строке (для загрузки в автовыдачу FunPay или в бота)
"""
import argparse
import csv
import datetime
import secrets
import sys

ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # без I и O


def checksum(body):
    s = 0
    for i, ch in enumerate(body):
        s += (i + 1) * ALPHA.index(ch)
    return ALPHA[s % 32]


def make_key():
    body = "".join(secrets.choice(ALPHA) for _ in range(15))
    full = body + checksum(body)
    return "TTB-" + "-".join(full[i:i + 4] for i in range(0, 16, 4))


def verify(key):
    k = key.strip().upper()
    if not (k.startswith("TTB-") and len(k) == 23):
        return False
    body = k[4:].replace("-", "")
    if len(body) != 16 or any(c not in ALPHA for c in body):
        return False
    return checksum(body[:-1]) == body[-1]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--count", type=int, default=10)
    p.add_argument("--days", type=int, default=30, help="сколько дней работает ключ после активации")
    p.add_argument("--channel", default="manual", choices=["tg", "funpay", "manual"])
    p.add_argument("--batch", default="BATCH-001")
    p.add_argument("--verify")
    a = p.parse_args()
    if a.verify:
        print("OK" if verify(a.verify) else "НЕВЕРНЫЙ КЛЮЧ")
        return
    keys = set()
    while len(keys) < a.count:
        keys.add(make_key())
    now = datetime.datetime.now().isoformat(timespec="seconds")
    with open(a.batch + ".csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["key", "days", "channel", "batch", "status", "created"])
        for k in sorted(keys):
            w.writerow([k, a.days, a.channel, a.batch, "unused", now])
    with open(a.batch + "_keys.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(sorted(keys)) + "\n")
    print("Готово: %d ключей, файлы %s.csv и %s_keys.txt" % (len(keys), a.batch, a.batch))


if __name__ == "__main__":
    sys.exit(main())
