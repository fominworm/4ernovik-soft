package com.example.haybot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Рисует записанные точки. Если задан hint — это режим записи (жёлтый экран с подсказкой). */
class MarkView(ctx: Context, private val cfg: Cfg, private val hint: String?) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        if (hint != null) c.drawColor(0x44FFEB3B)

        val path = cfg.list(T.PATH)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = T.PATH.color
        for (i in 1 until path.size) {
            c.drawLine(path[i - 1].x - ox, path[i - 1].y - oy, path[i].x - ox, path[i].y - oy, p)
        }

        p.style = Paint.Style.FILL
        for (t in T.values()) {
            for ((i, pt) in cfg.list(t).withIndex()) {
                p.color = t.color
                c.drawCircle(pt.x - ox, pt.y - oy, 20f, p)
                p.color = Color.WHITE
                p.textSize = 30f
                p.textAlign = Paint.Align.LEFT
                val label = t.icon + (if (t.multi) (i + 1).toString() else "")
                c.drawText(label, pt.x - ox + 24f, pt.y - oy + 10f, p)
            }
        }

        if (hint != null) {
            p.color = 0xCC000000.toInt()
            c.drawRect(0f, 0f, width.toFloat(), 80f, p)
            p.color = Color.WHITE
            p.textSize = 34f
            p.textAlign = Paint.Align.CENTER
            c.drawText(hint, width / 2f, 52f, p)
        }
    }
}
