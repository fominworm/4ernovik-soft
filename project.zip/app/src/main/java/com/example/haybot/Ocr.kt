package com.example.haybot

import android.graphics.Bitmap
import android.graphics.Color
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit

/** Чтение текста с картинки (ML Kit, модель внутри приложения). Вызывать не с главного потока. */
object Ocr {
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    fun read(bmp: Bitmap): String? = try {
        Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)), 8, TimeUnit.SECONDS).text
    } catch (e: Exception) {
        null
    }

    /**
     * Чтение белого текста игры: светлые пиксели становятся чёрными буквами на белом фоне. Так ML Kit читает цифры
     * надёжнее, чем с цветной картинки с обводкой.
     */
    fun readMask(bmp: Bitmap): String? = try {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val mn = minOf(Color.red(c), Color.green(c), Color.blue(c))
            px[i] = if (mn > 185) Color.BLACK else Color.WHITE
        }
        val m = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        try {
            read(m)
        } finally {
            m.recycle()
        }
    } catch (e: Throwable) {
        null
    }
}
