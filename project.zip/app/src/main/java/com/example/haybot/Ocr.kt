package com.example.haybot

import android.graphics.Bitmap
import android.graphics.Color
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit

/** Чтение текста с картинки (ML Kit, модель внутри приложения). Вызывать не с главного потока. */
object Ocr {
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    fun read(bmp: Bitmap): String? = try {
        Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)), 8, TimeUnit.SECONDS).text
    } catch (e: Exception) {
        null
    }

    /**
     * Чтение белого текста игры: светлые пиксели становятся чёрными буквами на белом фоне. Так ML Kit читает цифры
     * надёжнее, чем с цветной картинки с обводкой.
     */
    fun readMask(bmp: Bitmap): String? = try {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val mn = minOf(Color.red(c), Color.green(c), Color.blue(c))
            px[i] = if (mn > 185) Color.BLACK else Color.WHITE
        }
        val m = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        try {
            read(m)
        } finally {
            m.recycle()
        }
    } catch (e: Throwable) {
        null
    }

    /**
     * Цифры игры нарисованы светлой заливкой с тёмной обводкой, поэтому обычное чтение их теряет или обрезает первую.
     * Берём тёмную обводку, заливаем «снаружи» и оставляем только то, что внутри обводки (тела цифр): это чёрные
     * цифры на белом, их OCR читает уверенно. Мелкие пятна отбрасываются.
     */
    fun readInterior(src: Bitmap): String? = try {
        val w0 = src.width
        val h0 = src.height
        val w = w0 + 6
        val h = h0 + 6
        val dark = BooleanArray(w * h)
        val px = IntArray(w0 * h0)
        src.getPixels(px, 0, w0, 0, 0, w0, h0)
        for (y in 0 until h0) {
            for (x in 0 until w0) {
                val c = px[y * w0 + x]
                dark[(y + 3) * w + x + 3] = Color.red(c) < 150 && Color.green(c) < 145 && Color.blue(c) < 110
            }
        }
        // «снаружи»: все не тёмные пиксели, достижимые из угла
        val outside = BooleanArray(w * h)
        val q = IntArray(w * h)
        var qh = 0
        var qt = 0
        q[qt++] = 0
        outside[0] = true
        while (qh < qt) {
            val p = q[qh++]
            val x = p % w
            val y = p / w
            if (x > 0 && !dark[p - 1] && !outside[p - 1]) { outside[p - 1] = true; q[qt++] = p - 1 }
            if (x < w - 1 && !dark[p + 1] && !outside[p + 1]) { outside[p + 1] = true; q[qt++] = p + 1 }
            if (y > 0 && !dark[p - w] && !outside[p - w]) { outside[p - w] = true; q[qt++] = p - w }
            if (y < h - 1 && !dark[p + w] && !outside[p + w]) { outside[p + w] = true; q[qt++] = p + w }
        }
        // внутренность: не тёмное и не «снаружи»; отбрасываем мелкие связные пятна
        val inner = BooleanArray(w * h) { !dark[it] && !outside[it] }
        val seen = BooleanArray(w * h)
        val minArea = maxOf(10, (w0 * h0 * 0.0015f).toInt())
        val keep = BooleanArray(w * h)
        for (s in 0 until w * h) {
            if (!inner[s] || seen[s]) continue
            var head = 0
            var tail = 0
            q[tail++] = s
            seen[s] = true
            while (head < tail) {
                val p = q[head++]
                val x = p % w
                val y = p / w
                if (x > 0 && inner[p - 1] && !seen[p - 1]) { seen[p - 1] = true; q[tail++] = p - 1 }
                if (x < w - 1 && inner[p + 1] && !seen[p + 1]) { seen[p + 1] = true; q[tail++] = p + 1 }
                if (y > 0 && inner[p - w] && !seen[p - w]) { seen[p - w] = true; q[tail++] = p - w }
                if (y < h - 1 && inner[p + w] && !seen[p + w]) { seen[p + w] = true; q[tail++] = p + w }
            }
            if (tail >= minArea) for (k in 0 until tail) keep[q[k]] = true
        }
        val out = IntArray(w0 * h0)
        for (y in 0 until h0) for (x in 0 until w0) out[y * w0 + x] = if (keep[(y + 3) * w + x + 3]) Color.BLACK else Color.WHITE
        var m = Bitmap.createBitmap(out, w0, h0, Bitmap.Config.ARGB_8888)
        if (h0 < 120) {
            val k = (120 + h0 - 1) / h0
            val up = Bitmap.createScaledBitmap(m, w0 * k, h0 * k, true)
            m.recycle()
            m = up
        }
        try {
            read(m)
        } finally {
            m.recycle()
        }
    } catch (e: Throwable) {
        null
    }
}
